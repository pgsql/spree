# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
StyckrParty::Application.config.secret_token = '65992ed0206f56dd04c9e511d0f5625f5a579c174d23a386e68b2ac105fef1659f0119a82fe87c616bb9db822cf6cfc374163c48e47fb6be0dc9afe4ea8d724f'
