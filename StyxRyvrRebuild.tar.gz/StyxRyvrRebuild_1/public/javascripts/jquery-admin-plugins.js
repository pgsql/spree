/*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 * Copyright 2010, The Dojo Foundation
 * Released under the MIT, BSD, and GPL Licenses.
 *
 * Date: Sat Feb 13 22:33:48 2010 -0500
 */
(function(A, w) {
    function ma() {
        if (!c.isReady) {
            try {
                s.documentElement.doScroll("left")
            } catch(a) {
                setTimeout(ma, 1);
                return
            }
            c.ready()
        }
    }

    function Qa(a, b) {
        b.src ? c.ajax({url:b.src,async:false,dataType:"script"}) : c.globalEval(b.text || b.textContent || b.innerHTML || "");
        b.parentNode && b.parentNode.removeChild(b)
    }

    function X(a, b, d, f, e, j) {
        var i = a.length;
        if (typeof b === "object") {
            for (var o in b)X(a, o, b[o], f, e, d);
            return a
        }
        if (d !== w) {
            f = !j && f && c.isFunction(d);
            for (o = 0; o < i; o++)e(a[o], b, f ? d.call(a[o], o, e(a[o], b)) : d, j);
            return a
        }
        return i ?
                e(a[0], b) : w
    }

    function J() {
        return(new Date).getTime()
    }

    function Y() {
        return false
    }

    function Z() {
        return true
    }

    function na(a, b, d) {
        d[0].type = a;
        return c.event.handle.apply(b, d)
    }

    function oa(a) {
        var b,d = [],f = [],e = arguments,j,i,o,k,n,r;
        i = c.data(this, "events");
        if (!(a.liveFired === this || !i || !i.live || a.button && a.type === "click")) {
            a.liveFired = this;
            var u = i.live.slice(0);
            for (k = 0; k < u.length; k++) {
                i = u[k];
                i.origType.replace(O, "") === a.type ? f.push(i.selector) : u.splice(k--, 1)
            }
            j = c(a.target).closest(f, a.currentTarget);
            n = 0;
            for (r =
                         j.length; n < r; n++)for (k = 0; k < u.length; k++) {
                i = u[k];
                if (j[n].selector === i.selector) {
                    o = j[n].elem;
                    f = null;
                    if (i.preType === "mouseenter" || i.preType === "mouseleave")f = c(a.relatedTarget).closest(i.selector)[0];
                    if (!f || f !== o)d.push({elem:o,handleObj:i})
                }
            }
            n = 0;
            for (r = d.length; n < r; n++) {
                j = d[n];
                a.currentTarget = j.elem;
                a.data = j.handleObj.data;
                a.handleObj = j.handleObj;
                if (j.handleObj.origHandler.apply(j.elem, e) === false) {
                    b = false;
                    break
                }
            }
            return b
        }
    }

    function pa(a, b) {
        return"live." + (a && a !== "*" ? a + "." : "") + b.replace(/\./g, "`").replace(/ /g,
                "&")
    }

    function qa(a) {
        return!a || !a.parentNode || a.parentNode.nodeType === 11
    }

    function ra(a, b) {
        var d = 0;
        b.each(function() {
            if (this.nodeName === (a[d] && a[d].nodeName)) {
                var f = c.data(a[d++]),e = c.data(this, f);
                if (f = f && f.events) {
                    delete e.handle;
                    e.events = {};
                    for (var j in f)for (var i in f[j])c.event.add(this, j, f[j][i], f[j][i].data)
                }
            }
        })
    }

    function sa(a, b, d) {
        var f,e,j;
        b = b && b[0] ? b[0].ownerDocument || b[0] : s;
        if (a.length === 1 && typeof a[0] === "string" && a[0].length < 512 && b === s && !ta.test(a[0]) && (c.support.checkClone || !ua.test(a[0]))) {
            e =
                    true;
            if (j = c.fragments[a[0]])if (j !== 1)f = j
        }
        if (!f) {
            f = b.createDocumentFragment();
            c.clean(a, b, f, d)
        }
        if (e)c.fragments[a[0]] = j ? f : 1;
        return{fragment:f,cacheable:e}
    }

    function K(a, b) {
        var d = {};
        c.each(va.concat.apply([], va.slice(0, b)), function() {
            d[this] = a
        });
        return d
    }

    function wa(a) {
        return"scrollTo"in a && a.document ? a : a.nodeType === 9 ? a.defaultView || a.parentWindow : false
    }

    var c = function(a, b) {
        return new c.fn.init(a, b)
    },Ra = A.jQuery,Sa = A.$,s = A.document,T,Ta = /^[^<]*(<[\w\W]+>)[^>]*$|^#([\w-]+)$/,Ua = /^.[^:#\[\.,]*$/,Va = /\S/,
            Wa = /^(\s|\u00A0)+|(\s|\u00A0)+$/g,Xa = /^<(\w+)\s*\/?>(?:<\/\1>)?$/,P = navigator.userAgent,xa = false,Q = [],L,$ = Object.prototype.toString,aa = Object.prototype.hasOwnProperty,ba = Array.prototype.push,R = Array.prototype.slice,ya = Array.prototype.indexOf;
    c.fn = c.prototype = {init:function(a, b) {
        var d,f;
        if (!a)return this;
        if (a.nodeType) {
            this.context = this[0] = a;
            this.length = 1;
            return this
        }
        if (a === "body" && !b) {
            this.context = s;
            this[0] = s.body;
            this.selector = "body";
            this.length = 1;
            return this
        }
        if (typeof a === "string")if ((d = Ta.exec(a)) &&
                (d[1] || !b))if (d[1]) {
            f = b ? b.ownerDocument || b : s;
            if (a = Xa.exec(a))if (c.isPlainObject(b)) {
                a = [s.createElement(a[1])];
                c.fn.attr.call(a, b, true)
            } else a = [f.createElement(a[1])]; else {
                a = sa([d[1]], [f]);
                a = (a.cacheable ? a.fragment.cloneNode(true) : a.fragment).childNodes
            }
            return c.merge(this, a)
        } else {
            if (b = s.getElementById(d[2])) {
                if (b.id !== d[2])return T.find(a);
                this.length = 1;
                this[0] = b
            }
            this.context = s;
            this.selector = a;
            return this
        } else if (!b && /^\w+$/.test(a)) {
            this.selector = a;
            this.context = s;
            a = s.getElementsByTagName(a);
            return c.merge(this,
                    a)
        } else return!b || b.jquery ? (b || T).find(a) : c(b).find(a); else if (c.isFunction(a))return T.ready(a);
        if (a.selector !== w) {
            this.selector = a.selector;
            this.context = a.context
        }
        return c.makeArray(a, this)
    },selector:"",jquery:"1.4.2",length:0,size:function() {
        return this.length
    },toArray:function() {
        return R.call(this, 0)
    },get:function(a) {
        return a == null ? this.toArray() : a < 0 ? this.slice(a)[0] : this[a]
    },pushStack:function(a, b, d) {
        var f = c();
        c.isArray(a) ? ba.apply(f, a) : c.merge(f, a);
        f.prevObject = this;
        f.context = this.context;
        if (b ===
                "find")f.selector = this.selector + (this.selector ? " " : "") + d; else if (b)f.selector = this.selector + "." + b + "(" + d + ")";
        return f
    },each:function(a, b) {
        return c.each(this, a, b)
    },ready:function(a) {
        c.bindReady();
        if (c.isReady)a.call(s, c); else Q && Q.push(a);
        return this
    },eq:function(a) {
        return a === -1 ? this.slice(a) : this.slice(a, +a + 1)
    },first:function() {
        return this.eq(0)
    },last:function() {
        return this.eq(-1)
    },slice:function() {
        return this.pushStack(R.apply(this, arguments), "slice", R.call(arguments).join(","))
    },map:function(a) {
        return this.pushStack(c.map(this,
                function(b, d) {
                    return a.call(b, d, b)
                }))
    },end:function() {
        return this.prevObject || c(null)
    },push:ba,sort:[].sort,splice:[].splice};
    c.fn.init.prototype = c.fn;
    c.extend = c.fn.extend = function() {
        var a = arguments[0] || {},b = 1,d = arguments.length,f = false,e,j,i,o;
        if (typeof a === "boolean") {
            f = a;
            a = arguments[1] || {};
            b = 2
        }
        if (typeof a !== "object" && !c.isFunction(a))a = {};
        if (d === b) {
            a = this;
            --b
        }
        for (; b < d; b++)if ((e = arguments[b]) != null)for (j in e) {
            i = a[j];
            o = e[j];
            if (a !== o)if (f && o && (c.isPlainObject(o) || c.isArray(o))) {
                i = i && (c.isPlainObject(i) ||
                        c.isArray(i)) ? i : c.isArray(o) ? [] : {};
                a[j] = c.extend(f, i, o)
            } else if (o !== w)a[j] = o
        }
        return a
    };
    c.extend({noConflict:function(a) {
        A.$ = Sa;
        if (a)A.jQuery = Ra;
        return c
    },isReady:false,ready:function() {
        if (!c.isReady) {
            if (!s.body)return setTimeout(c.ready, 13);
            c.isReady = true;
            if (Q) {
                for (var a,b = 0; a = Q[b++];)a.call(s, c);
                Q = null
            }
            c.fn.triggerHandler && c(s).triggerHandler("ready")
        }
    },bindReady:function() {
        if (!xa) {
            xa = true;
            if (s.readyState === "complete")return c.ready();
            if (s.addEventListener) {
                s.addEventListener("DOMContentLoaded",
                        L, false);
                A.addEventListener("load", c.ready, false)
            } else if (s.attachEvent) {
                s.attachEvent("onreadystatechange", L);
                A.attachEvent("onload", c.ready);
                var a = false;
                try {
                    a = A.frameElement == null
                } catch(b) {
                }
                s.documentElement.doScroll && a && ma()
            }
        }
    },isFunction:function(a) {
        return $.call(a) === "[object Function]"
    },isArray:function(a) {
        return $.call(a) === "[object Array]"
    },isPlainObject:function(a) {
        if (!a || $.call(a) !== "[object Object]" || a.nodeType || a.setInterval)return false;
        if (a.constructor && !aa.call(a, "constructor") && !aa.call(a.constructor.prototype,
                "isPrototypeOf"))return false;
        var b;
        for (b in a);
        return b === w || aa.call(a, b)
    },isEmptyObject:function(a) {
        for (var b in a)return false;
        return true
    },error:function(a) {
        throw a;
    },parseJSON:function(a) {
        if (typeof a !== "string" || !a)return null;
        a = c.trim(a);
        if (/^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")))return A.JSON && A.JSON.parse ? A.JSON.parse(a) : (new Function("return " +
                a))(); else c.error("Invalid JSON: " + a)
    },noop:function() {
    },globalEval:function(a) {
        if (a && Va.test(a)) {
            var b = s.getElementsByTagName("head")[0] || s.documentElement,d = s.createElement("script");
            d.type = "text/javascript";
            if (c.support.scriptEval)d.appendChild(s.createTextNode(a)); else d.text = a;
            b.insertBefore(d, b.firstChild);
            b.removeChild(d)
        }
    },nodeName:function(a, b) {
        return a.nodeName && a.nodeName.toUpperCase() === b.toUpperCase()
    },each:function(a, b, d) {
        var f,e = 0,j = a.length,i = j === w || c.isFunction(a);
        if (d)if (i)for (f in a) {
            if (b.apply(a[f],
                    d) === false)break
        } else for (; e < j;) {
            if (b.apply(a[e++], d) === false)break
        } else if (i)for (f in a) {
            if (b.call(a[f], f, a[f]) === false)break
        } else for (d = a[0]; e < j && b.call(d, e, d) !== false; d = a[++e]);
        return a
    },trim:function(a) {
        return(a || "").replace(Wa, "")
    },makeArray:function(a, b) {
        b = b || [];
        if (a != null)a.length == null || typeof a === "string" || c.isFunction(a) || typeof a !== "function" && a.setInterval ? ba.call(b, a) : c.merge(b, a);
        return b
    },inArray:function(a, b) {
        if (b.indexOf)return b.indexOf(a);
        for (var d = 0,f = b.length; d < f; d++)if (b[d] ===
                a)return d;
        return-1
    },merge:function(a, b) {
        var d = a.length,f = 0;
        if (typeof b.length === "number")for (var e = b.length; f < e; f++)a[d++] = b[f]; else for (; b[f] !== w;)a[d++] = b[f++];
        a.length = d;
        return a
    },grep:function(a, b, d) {
        for (var f = [],e = 0,j = a.length; e < j; e++)!d !== !b(a[e], e) && f.push(a[e]);
        return f
    },map:function(a, b, d) {
        for (var f = [],e,j = 0,i = a.length; j < i; j++) {
            e = b(a[j], j, d);
            if (e != null)f[f.length] = e
        }
        return f.concat.apply([], f)
    },guid:1,proxy:function(a, b, d) {
        if (arguments.length === 2)if (typeof b === "string") {
            d = a;
            a = d[b];
            b = w
        } else if (b &&
                !c.isFunction(b)) {
            d = b;
            b = w
        }
        if (!b && a)b = function() {
            return a.apply(d || this, arguments)
        };
        if (a)b.guid = a.guid = a.guid || b.guid || c.guid++;
        return b
    },uaMatch:function(a) {
        a = a.toLowerCase();
        a = /(webkit)[ \/]([\w.]+)/.exec(a) || /(opera)(?:.*version)?[ \/]([\w.]+)/.exec(a) || /(msie) ([\w.]+)/.exec(a) || !/compatible/.test(a) && /(mozilla)(?:.*? rv:([\w.]+))?/.exec(a) || [];
        return{browser:a[1] || "",version:a[2] || "0"}
    },browser:{}});
    P = c.uaMatch(P);
    if (P.browser) {
        c.browser[P.browser] = true;
        c.browser.version = P.version
    }
    if (c.browser.webkit)c.browser.safari =
            true;
    if (ya)c.inArray = function(a, b) {
        return ya.call(b, a)
    };
    T = c(s);
    if (s.addEventListener)L = function() {
        s.removeEventListener("DOMContentLoaded", L, false);
        c.ready()
    }; else if (s.attachEvent)L = function() {
        if (s.readyState === "complete") {
            s.detachEvent("onreadystatechange", L);
            c.ready()
        }
    };
    (function() {
        c.support = {};
        var a = s.documentElement,b = s.createElement("script"),d = s.createElement("div"),f = "script" + J();
        d.style.display = "none";
        d.innerHTML = "   <link/><table></table><a href='/a' style='color:red;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
        var e = d.getElementsByTagName("*"),j = d.getElementsByTagName("a")[0];
        if (!(!e || !e.length || !j)) {
            c.support = {leadingWhitespace:d.firstChild.nodeType === 3,tbody:!d.getElementsByTagName("tbody").length,htmlSerialize:!!d.getElementsByTagName("link").length,style:/red/.test(j.getAttribute("style")),hrefNormalized:j.getAttribute("href") === "/a",opacity:/^0.55$/.test(j.style.opacity),cssFloat:!!j.style.cssFloat,checkOn:d.getElementsByTagName("input")[0].value === "on",optSelected:s.createElement("select").appendChild(s.createElement("option")).selected,
                parentNode:d.removeChild(d.appendChild(s.createElement("div"))).parentNode === null,deleteExpando:true,checkClone:false,scriptEval:false,noCloneEvent:true,boxModel:null};
            b.type = "text/javascript";
            try {
                b.appendChild(s.createTextNode("window." + f + "=1;"))
            } catch(i) {
            }
            a.insertBefore(b, a.firstChild);
            if (A[f]) {
                c.support.scriptEval = true;
                delete A[f]
            }
            try {
                delete b.test
            } catch(o) {
                c.support.deleteExpando = false
            }
            a.removeChild(b);
            if (d.attachEvent && d.fireEvent) {
                d.attachEvent("onclick", function k() {
                    c.support.noCloneEvent =
                            false;
                    d.detachEvent("onclick", k)
                });
                d.cloneNode(true).fireEvent("onclick")
            }
            d = s.createElement("div");
            d.innerHTML = "<input type='radio' name='radiotest' checked='checked'/>";
            a = s.createDocumentFragment();
            a.appendChild(d.firstChild);
            c.support.checkClone = a.cloneNode(true).cloneNode(true).lastChild.checked;
            c(function() {
                var k = s.createElement("div");
                k.style.width = k.style.paddingLeft = "1px";
                s.body.appendChild(k);
                c.boxModel = c.support.boxModel = k.offsetWidth === 2;
                s.body.removeChild(k).style.display = "none"
            });
            a = function(k) {
                var n =
                        s.createElement("div");
                k = "on" + k;
                var r = k in n;
                if (!r) {
                    n.setAttribute(k, "return;");
                    r = typeof n[k] === "function"
                }
                return r
            };
            c.support.submitBubbles = a("submit");
            c.support.changeBubbles = a("change");
            a = b = d = e = j = null
        }
    })();
    c.props = {"for":"htmlFor","class":"className",readonly:"readOnly",maxlength:"maxLength",cellspacing:"cellSpacing",rowspan:"rowSpan",colspan:"colSpan",tabindex:"tabIndex",usemap:"useMap",frameborder:"frameBorder"};
    var G = "jQuery" + J(),Ya = 0,za = {};
    c.extend({cache:{},expando:G,noData:{embed:true,object:true,
        applet:true},data:function(a, b, d) {
        if (!(a.nodeName && c.noData[a.nodeName.toLowerCase()])) {
            a = a == A ? za : a;
            var f = a[G],e = c.cache;
            if (!f && typeof b === "string" && d === w)return null;
            f || (f = ++Ya);
            if (typeof b === "object") {
                a[G] = f;
                e[f] = c.extend(true, {}, b)
            } else if (!e[f]) {
                a[G] = f;
                e[f] = {}
            }
            a = e[f];
            if (d !== w)a[b] = d;
            return typeof b === "string" ? a[b] : a
        }
    },removeData:function(a, b) {
        if (!(a.nodeName && c.noData[a.nodeName.toLowerCase()])) {
            a = a == A ? za : a;
            var d = a[G],f = c.cache,e = f[d];
            if (b) {
                if (e) {
                    delete e[b];
                    c.isEmptyObject(e) && c.removeData(a)
                }
            } else {
                if (c.support.deleteExpando)delete a[c.expando];
                else a.removeAttribute && a.removeAttribute(c.expando);
                delete f[d]
            }
        }
    }});
    c.fn.extend({data:function(a, b) {
        if (typeof a === "undefined" && this.length)return c.data(this[0]); else if (typeof a === "object")return this.each(function() {
            c.data(this, a)
        });
        var d = a.split(".");
        d[1] = d[1] ? "." + d[1] : "";
        if (b === w) {
            var f = this.triggerHandler("getData" + d[1] + "!", [d[0]]);
            if (f === w && this.length)f = c.data(this[0], a);
            return f === w && d[1] ? this.data(d[0]) : f
        } else return this.trigger("setData" + d[1] + "!", [d[0],b]).each(function() {
            c.data(this,
                    a, b)
        })
    },removeData:function(a) {
        return this.each(function() {
            c.removeData(this, a)
        })
    }});
    c.extend({queue:function(a, b, d) {
        if (a) {
            b = (b || "fx") + "queue";
            var f = c.data(a, b);
            if (!d)return f || [];
            if (!f || c.isArray(d))f = c.data(a, b, c.makeArray(d)); else f.push(d);
            return f
        }
    },dequeue:function(a, b) {
        b = b || "fx";
        var d = c.queue(a, b),f = d.shift();
        if (f === "inprogress")f = d.shift();
        if (f) {
            b === "fx" && d.unshift("inprogress");
            f.call(a, function() {
                c.dequeue(a, b)
            })
        }
    }});
    c.fn.extend({queue:function(a, b) {
        if (typeof a !== "string") {
            b = a;
            a = "fx"
        }
        if (b ===
                w)return c.queue(this[0], a);
        return this.each(function() {
            var d = c.queue(this, a, b);
            a === "fx" && d[0] !== "inprogress" && c.dequeue(this, a)
        })
    },dequeue:function(a) {
        return this.each(function() {
            c.dequeue(this, a)
        })
    },delay:function(a, b) {
        a = c.fx ? c.fx.speeds[a] || a : a;
        b = b || "fx";
        return this.queue(b, function() {
            var d = this;
            setTimeout(function() {
                c.dequeue(d, b)
            }, a)
        })
    },clearQueue:function(a) {
        return this.queue(a || "fx", [])
    }});
    var Aa = /[\n\t]/g,ca = /\s+/,Za = /\r/g,$a = /href|src|style/,ab = /(button|input)/i,bb = /(button|input|object|select|textarea)/i,
            cb = /^(a|area)$/i,Ba = /radio|checkbox/;
    c.fn.extend({attr:function(a, b) {
        return X(this, a, b, true, c.attr)
    },removeAttr:function(a) {
        return this.each(function() {
            c.attr(this, a, "");
            this.nodeType === 1 && this.removeAttribute(a)
        })
    },addClass:function(a) {
        if (c.isFunction(a))return this.each(function(n) {
            var r = c(this);
            r.addClass(a.call(this, n, r.attr("class")))
        });
        if (a && typeof a === "string")for (var b = (a || "").split(ca),d = 0,f = this.length; d < f; d++) {
            var e = this[d];
            if (e.nodeType === 1)if (e.className) {
                for (var j = " " + e.className + " ",
                             i = e.className,o = 0,k = b.length; o < k; o++)if (j.indexOf(" " + b[o] + " ") < 0)i += " " + b[o];
                e.className = c.trim(i)
            } else e.className = a
        }
        return this
    },removeClass:function(a) {
        if (c.isFunction(a))return this.each(function(k) {
            var n = c(this);
            n.removeClass(a.call(this, k, n.attr("class")))
        });
        if (a && typeof a === "string" || a === w)for (var b = (a || "").split(ca),d = 0,f = this.length; d < f; d++) {
            var e = this[d];
            if (e.nodeType === 1 && e.className)if (a) {
                for (var j = (" " + e.className + " ").replace(Aa, " "),i = 0,o = b.length; i < o; i++)j = j.replace(" " + b[i] + " ",
                        " ");
                e.className = c.trim(j)
            } else e.className = ""
        }
        return this
    },toggleClass:function(a, b) {
        var d = typeof a,f = typeof b === "boolean";
        if (c.isFunction(a))return this.each(function(e) {
            var j = c(this);
            j.toggleClass(a.call(this, e, j.attr("class"), b), b)
        });
        return this.each(function() {
            if (d === "string")for (var e,j = 0,i = c(this),o = b,k = a.split(ca); e = k[j++];) {
                o = f ? o : !i.hasClass(e);
                i[o ? "addClass" : "removeClass"](e)
            } else if (d === "undefined" || d === "boolean") {
                this.className && c.data(this, "__className__", this.className);
                this.className =
                        this.className || a === false ? "" : c.data(this, "__className__") || ""
            }
        })
    },hasClass:function(a) {
        a = " " + a + " ";
        for (var b = 0,d = this.length; b < d; b++)if ((" " + this[b].className + " ").replace(Aa, " ").indexOf(a) > -1)return true;
        return false
    },val:function(a) {
        if (a === w) {
            var b = this[0];
            if (b) {
                if (c.nodeName(b, "option"))return(b.attributes.value || {}).specified ? b.value : b.text;
                if (c.nodeName(b, "select")) {
                    var d = b.selectedIndex,f = [],e = b.options;
                    b = b.type === "select-one";
                    if (d < 0)return null;
                    var j = b ? d : 0;
                    for (d = b ? d + 1 : e.length; j < d; j++) {
                        var i =
                                e[j];
                        if (i.selected) {
                            a = c(i).val();
                            if (b)return a;
                            f.push(a)
                        }
                    }
                    return f
                }
                if (Ba.test(b.type) && !c.support.checkOn)return b.getAttribute("value") === null ? "on" : b.value;
                return(b.value || "").replace(Za, "")
            }
            return w
        }
        var o = c.isFunction(a);
        return this.each(function(k) {
            var n = c(this),r = a;
            if (this.nodeType === 1) {
                if (o)r = a.call(this, k, n.val());
                if (typeof r === "number")r += "";
                if (c.isArray(r) && Ba.test(this.type))this.checked = c.inArray(n.val(), r) >= 0; else if (c.nodeName(this, "select")) {
                    var u = c.makeArray(r);
                    c("option", this).each(function() {
                        this.selected =
                                c.inArray(c(this).val(), u) >= 0
                    });
                    if (!u.length)this.selectedIndex = -1
                } else this.value = r
            }
        })
    }});
    c.extend({attrFn:{val:true,css:true,html:true,text:true,data:true,width:true,height:true,offset:true},attr:function(a, b, d, f) {
        if (!a || a.nodeType === 3 || a.nodeType === 8)return w;
        if (f && b in c.attrFn)return c(a)[b](d);
        f = a.nodeType !== 1 || !c.isXMLDoc(a);
        var e = d !== w;
        b = f && c.props[b] || b;
        if (a.nodeType === 1) {
            var j = $a.test(b);
            if (b in a && f && !j) {
                if (e) {
                    b === "type" && ab.test(a.nodeName) && a.parentNode && c.error("type property can't be changed");
                    a[b] = d
                }
                if (c.nodeName(a, "form") && a.getAttributeNode(b))return a.getAttributeNode(b).nodeValue;
                if (b === "tabIndex")return(b = a.getAttributeNode("tabIndex")) && b.specified ? b.value : bb.test(a.nodeName) || cb.test(a.nodeName) && a.href ? 0 : w;
                return a[b]
            }
            if (!c.support.style && f && b === "style") {
                if (e)a.style.cssText = "" + d;
                return a.style.cssText
            }
            e && a.setAttribute(b, "" + d);
            a = !c.support.hrefNormalized && f && j ? a.getAttribute(b, 2) : a.getAttribute(b);
            return a === null ? w : a
        }
        return c.style(a, b, d)
    }});
    var O = /\.(.*)$/,db = function(a) {
        return a.replace(/[^\w\s\.\|`]/g,
                function(b) {
                    return"\\" + b
                })
    };
    c.event = {add:function(a, b, d, f) {
        if (!(a.nodeType === 3 || a.nodeType === 8)) {
            if (a.setInterval && a !== A && !a.frameElement)a = A;
            var e,j;
            if (d.handler) {
                e = d;
                d = e.handler
            }
            if (!d.guid)d.guid = c.guid++;
            if (j = c.data(a)) {
                var i = j.events = j.events || {},o = j.handle;
                if (!o)j.handle = o = function() {
                    return typeof c !== "undefined" && !c.event.triggered ? c.event.handle.apply(o.elem, arguments) : w
                };
                o.elem = a;
                b = b.split(" ");
                for (var k,n = 0,r; k = b[n++];) {
                    j = e ? c.extend({}, e) : {handler:d,data:f};
                    if (k.indexOf(".") > -1) {
                        r = k.split(".");
                        k = r.shift();
                        j.namespace = r.slice(0).sort().join(".")
                    } else {
                        r = [];
                        j.namespace = ""
                    }
                    j.type = k;
                    j.guid = d.guid;
                    var u = i[k],z = c.event.special[k] || {};
                    if (!u) {
                        u = i[k] = [];
                        if (!z.setup || z.setup.call(a, f, r, o) === false)if (a.addEventListener)a.addEventListener(k, o, false); else a.attachEvent && a.attachEvent("on" + k, o)
                    }
                    if (z.add) {
                        z.add.call(a, j);
                        if (!j.handler.guid)j.handler.guid = d.guid
                    }
                    u.push(j);
                    c.event.global[k] = true
                }
                a = null
            }
        }
    },global:{},remove:function(a, b, d, f) {
        if (!(a.nodeType === 3 || a.nodeType === 8)) {
            var e,j = 0,i,o,k,n,r,u,z = c.data(a),
                    C = z && z.events;
            if (z && C) {
                if (b && b.type) {
                    d = b.handler;
                    b = b.type
                }
                if (!b || typeof b === "string" && b.charAt(0) === ".") {
                    b = b || "";
                    for (e in C)c.event.remove(a, e + b)
                } else {
                    for (b = b.split(" "); e = b[j++];) {
                        n = e;
                        i = e.indexOf(".") < 0;
                        o = [];
                        if (!i) {
                            o = e.split(".");
                            e = o.shift();
                            k = new RegExp("(^|\\.)" + c.map(o.slice(0).sort(), db).join("\\.(?:.*\\.)?") + "(\\.|$)")
                        }
                        if (r = C[e])if (d) {
                            n = c.event.special[e] || {};
                            for (B = f || 0; B < r.length; B++) {
                                u = r[B];
                                if (d.guid === u.guid) {
                                    if (i || k.test(u.namespace)) {
                                        f == null && r.splice(B--, 1);
                                        n.remove && n.remove.call(a, u)
                                    }
                                    if (f !=
                                            null)break
                                }
                            }
                            if (r.length === 0 || f != null && r.length === 1) {
                                if (!n.teardown || n.teardown.call(a, o) === false)Ca(a, e, z.handle);
                                delete C[e]
                            }
                        } else for (var B = 0; B < r.length; B++) {
                            u = r[B];
                            if (i || k.test(u.namespace)) {
                                c.event.remove(a, n, u.handler, B);
                                r.splice(B--, 1)
                            }
                        }
                    }
                    if (c.isEmptyObject(C)) {
                        if (b = z.handle)b.elem = null;
                        delete z.events;
                        delete z.handle;
                        c.isEmptyObject(z) && c.removeData(a)
                    }
                }
            }
        }
    },trigger:function(a, b, d, f) {
        var e = a.type || a;
        if (!f) {
            a = typeof a === "object" ? a[G] ? a : c.extend(c.Event(e), a) : c.Event(e);
            if (e.indexOf("!") >= 0) {
                a.type =
                        e = e.slice(0, -1);
                a.exclusive = true
            }
            if (!d) {
                a.stopPropagation();
                c.event.global[e] && c.each(c.cache, function() {
                    this.events && this.events[e] && c.event.trigger(a, b, this.handle.elem)
                })
            }
            if (!d || d.nodeType === 3 || d.nodeType === 8)return w;
            a.result = w;
            a.target = d;
            b = c.makeArray(b);
            b.unshift(a)
        }
        a.currentTarget = d;
        (f = c.data(d, "handle")) && f.apply(d, b);
        f = d.parentNode || d.ownerDocument;
        try {
            if (!(d && d.nodeName && c.noData[d.nodeName.toLowerCase()]))if (d["on" + e] && d["on" + e].apply(d, b) === false)a.result = false
        } catch(j) {
        }
        if (!a.isPropagationStopped() &&
                f)c.event.trigger(a, b, f, true); else if (!a.isDefaultPrevented()) {
            f = a.target;
            var i,o = c.nodeName(f, "a") && e === "click",k = c.event.special[e] || {};
            if ((!k._default || k._default.call(d, a) === false) && !o && !(f && f.nodeName && c.noData[f.nodeName.toLowerCase()])) {
                try {
                    if (f[e]) {
                        if (i = f["on" + e])f["on" + e] = null;
                        c.event.triggered = true;
                        f[e]()
                    }
                } catch(n) {
                }
                if (i)f["on" + e] = i;
                c.event.triggered = false
            }
        }
    },handle:function(a) {
        var b,d,f,e;
        a = arguments[0] = c.event.fix(a || A.event);
        a.currentTarget = this;
        b = a.type.indexOf(".") < 0 && !a.exclusive;
        if (!b) {
            d = a.type.split(".");
            a.type = d.shift();
            f = new RegExp("(^|\\.)" + d.slice(0).sort().join("\\.(?:.*\\.)?") + "(\\.|$)")
        }
        e = c.data(this, "events");
        d = e[a.type];
        if (e && d) {
            d = d.slice(0);
            e = 0;
            for (var j = d.length; e < j; e++) {
                var i = d[e];
                if (b || f.test(i.namespace)) {
                    a.handler = i.handler;
                    a.data = i.data;
                    a.handleObj = i;
                    i = i.handler.apply(this, arguments);
                    if (i !== w) {
                        a.result = i;
                        if (i === false) {
                            a.preventDefault();
                            a.stopPropagation()
                        }
                    }
                    if (a.isImmediatePropagationStopped())break
                }
            }
        }
        return a.result
    },props:"altKey attrChange attrName bubbles button cancelable charCode clientX clientY ctrlKey currentTarget data detail eventPhase fromElement handler keyCode layerX layerY metaKey newValue offsetX offsetY originalTarget pageX pageY prevValue relatedNode relatedTarget screenX screenY shiftKey srcElement target toElement view wheelDelta which".split(" "),
        fix:function(a) {
            if (a[G])return a;
            var b = a;
            a = c.Event(b);
            for (var d = this.props.length,f; d;) {
                f = this.props[--d];
                a[f] = b[f]
            }
            if (!a.target)a.target = a.srcElement || s;
            if (a.target.nodeType === 3)a.target = a.target.parentNode;
            if (!a.relatedTarget && a.fromElement)a.relatedTarget = a.fromElement === a.target ? a.toElement : a.fromElement;
            if (a.pageX == null && a.clientX != null) {
                b = s.documentElement;
                d = s.body;
                a.pageX = a.clientX + (b && b.scrollLeft || d && d.scrollLeft || 0) - (b && b.clientLeft || d && d.clientLeft || 0);
                a.pageY = a.clientY + (b && b.scrollTop ||
                        d && d.scrollTop || 0) - (b && b.clientTop || d && d.clientTop || 0)
            }
            if (!a.which && (a.charCode || a.charCode === 0 ? a.charCode : a.keyCode))a.which = a.charCode || a.keyCode;
            if (!a.metaKey && a.ctrlKey)a.metaKey = a.ctrlKey;
            if (!a.which && a.button !== w)a.which = a.button & 1 ? 1 : a.button & 2 ? 3 : a.button & 4 ? 2 : 0;
            return a
        },guid:1E8,proxy:c.proxy,special:{ready:{setup:c.bindReady,teardown:c.noop},live:{add:function(a) {
            c.event.add(this, a.origType, c.extend({}, a, {handler:oa}))
        },remove:function(a) {
            var b = true,d = a.origType.replace(O, "");
            c.each(c.data(this,
                    "events").live || [], function() {
                if (d === this.origType.replace(O, ""))return b = false
            });
            b && c.event.remove(this, a.origType, oa)
        }},beforeunload:{setup:function(a, b, d) {
            if (this.setInterval)this.onbeforeunload = d;
            return false
        },teardown:function(a, b) {
            if (this.onbeforeunload === b)this.onbeforeunload = null
        }}}};
    var Ca = s.removeEventListener ? function(a, b, d) {
        a.removeEventListener(b, d, false)
    } : function(a, b, d) {
        a.detachEvent("on" + b, d)
    };
    c.Event = function(a) {
        if (!this.preventDefault)return new c.Event(a);
        if (a && a.type) {
            this.originalEvent =
                    a;
            this.type = a.type
        } else this.type = a;
        this.timeStamp = J();
        this[G] = true
    };
    c.Event.prototype = {preventDefault:function() {
        this.isDefaultPrevented = Z;
        var a = this.originalEvent;
        if (a) {
            a.preventDefault && a.preventDefault();
            a.returnValue = false
        }
    },stopPropagation:function() {
        this.isPropagationStopped = Z;
        var a = this.originalEvent;
        if (a) {
            a.stopPropagation && a.stopPropagation();
            a.cancelBubble = true
        }
    },stopImmediatePropagation:function() {
        this.isImmediatePropagationStopped = Z;
        this.stopPropagation()
    },isDefaultPrevented:Y,isPropagationStopped:Y,
        isImmediatePropagationStopped:Y};
    var Da = function(a) {
        var b = a.relatedTarget;
        try {
            for (; b && b !== this;)b = b.parentNode;
            if (b !== this) {
                a.type = a.data;
                c.event.handle.apply(this, arguments)
            }
        } catch(d) {
        }
    },Ea = function(a) {
        a.type = a.data;
        c.event.handle.apply(this, arguments)
    };
    c.each({mouseenter:"mouseover",mouseleave:"mouseout"}, function(a, b) {
        c.event.special[a] = {setup:function(d) {
            c.event.add(this, b, d && d.selector ? Ea : Da, a)
        },teardown:function(d) {
            c.event.remove(this, b, d && d.selector ? Ea : Da)
        }}
    });
    if (!c.support.submitBubbles)c.event.special.submit =
    {setup:function() {
        if (this.nodeName.toLowerCase() !== "form") {
            c.event.add(this, "click.specialSubmit", function(a) {
                var b = a.target,d = b.type;
                if ((d === "submit" || d === "image") && c(b).closest("form").length)return na("submit", this, arguments)
            });
            c.event.add(this, "keypress.specialSubmit", function(a) {
                var b = a.target,d = b.type;
                if ((d === "text" || d === "password") && c(b).closest("form").length && a.keyCode === 13)return na("submit", this, arguments)
            })
        } else return false
    },teardown:function() {
        c.event.remove(this, ".specialSubmit")
    }};
    if (!c.support.changeBubbles) {
        var da = /textarea|input|select/i,ea,Fa = function(a) {
            var b = a.type,d = a.value;
            if (b === "radio" || b === "checkbox")d = a.checked; else if (b === "select-multiple")d = a.selectedIndex > -1 ? c.map(a.options,
                    function(f) {
                        return f.selected
                    }).join("-") : ""; else if (a.nodeName.toLowerCase() === "select")d = a.selectedIndex;
            return d
        },fa = function(a, b) {
            var d = a.target,f,e;
            if (!(!da.test(d.nodeName) || d.readOnly)) {
                f = c.data(d, "_change_data");
                e = Fa(d);
                if (a.type !== "focusout" || d.type !== "radio")c.data(d, "_change_data",
                        e);
                if (!(f === w || e === f))if (f != null || e) {
                    a.type = "change";
                    return c.event.trigger(a, b, d)
                }
            }
        };
        c.event.special.change = {filters:{focusout:fa,click:function(a) {
            var b = a.target,d = b.type;
            if (d === "radio" || d === "checkbox" || b.nodeName.toLowerCase() === "select")return fa.call(this, a)
        },keydown:function(a) {
            var b = a.target,d = b.type;
            if (a.keyCode === 13 && b.nodeName.toLowerCase() !== "textarea" || a.keyCode === 32 && (d === "checkbox" || d === "radio") || d === "select-multiple")return fa.call(this, a)
        },beforeactivate:function(a) {
            a = a.target;
            c.data(a,
                    "_change_data", Fa(a))
        }},setup:function() {
            if (this.type === "file")return false;
            for (var a in ea)c.event.add(this, a + ".specialChange", ea[a]);
            return da.test(this.nodeName)
        },teardown:function() {
            c.event.remove(this, ".specialChange");
            return da.test(this.nodeName)
        }};
        ea = c.event.special.change.filters
    }
    s.addEventListener && c.each({focus:"focusin",blur:"focusout"}, function(a, b) {
        function d(f) {
            f = c.event.fix(f);
            f.type = b;
            return c.event.handle.call(this, f)
        }

        c.event.special[b] = {setup:function() {
            this.addEventListener(a,
                    d, true)
        },teardown:function() {
            this.removeEventListener(a, d, true)
        }}
    });
    c.each(["bind","one"], function(a, b) {
        c.fn[b] = function(d, f, e) {
            if (typeof d === "object") {
                for (var j in d)this[b](j, f, d[j], e);
                return this
            }
            if (c.isFunction(f)) {
                e = f;
                f = w
            }
            var i = b === "one" ? c.proxy(e, function(k) {
                c(this).unbind(k, i);
                return e.apply(this, arguments)
            }) : e;
            if (d === "unload" && b !== "one")this.one(d, f, e); else {
                j = 0;
                for (var o = this.length; j < o; j++)c.event.add(this[j], d, i, f)
            }
            return this
        }
    });
    c.fn.extend({unbind:function(a, b) {
        if (typeof a === "object" &&
                !a.preventDefault)for (var d in a)this.unbind(d, a[d]); else {
            d = 0;
            for (var f = this.length; d < f; d++)c.event.remove(this[d], a, b)
        }
        return this
    },delegate:function(a, b, d, f) {
        return this.live(b, d, f, a)
    },undelegate:function(a, b, d) {
        return arguments.length === 0 ? this.unbind("live") : this.die(b, null, d, a)
    },trigger:function(a, b) {
        return this.each(function() {
            c.event.trigger(a, b, this)
        })
    },triggerHandler:function(a, b) {
        if (this[0]) {
            a = c.Event(a);
            a.preventDefault();
            a.stopPropagation();
            c.event.trigger(a, b, this[0]);
            return a.result
        }
    },
        toggle:function(a) {
            for (var b = arguments,d = 1; d < b.length;)c.proxy(a, b[d++]);
            return this.click(c.proxy(a, function(f) {
                var e = (c.data(this, "lastToggle" + a.guid) || 0) % d;
                c.data(this, "lastToggle" + a.guid, e + 1);
                f.preventDefault();
                return b[e].apply(this, arguments) || false
            }))
        },hover:function(a, b) {
            return this.mouseenter(a).mouseleave(b || a)
        }});
    var Ga = {focus:"focusin",blur:"focusout",mouseenter:"mouseover",mouseleave:"mouseout"};
    c.each(["live","die"], function(a, b) {
        c.fn[b] = function(d, f, e, j) {
            var i,o = 0,k,n,r = j || this.selector,
                    u = j ? this : c(this.context);
            if (c.isFunction(f)) {
                e = f;
                f = w
            }
            for (d = (d || "").split(" "); (i = d[o++]) != null;) {
                j = O.exec(i);
                k = "";
                if (j) {
                    k = j[0];
                    i = i.replace(O, "")
                }
                if (i === "hover")d.push("mouseenter" + k, "mouseleave" + k); else {
                    n = i;
                    if (i === "focus" || i === "blur") {
                        d.push(Ga[i] + k);
                        i += k
                    } else i = (Ga[i] || i) + k;
                    b === "live" ? u.each(function() {
                        c.event.add(this, pa(i, r), {data:f,selector:r,handler:e,origType:i,origHandler:e,preType:n})
                    }) : u.unbind(pa(i, r), e)
                }
            }
            return this
        }
    });
    c.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error".split(" "),
            function(a, b) {
                c.fn[b] = function(d) {
                    return d ? this.bind(b, d) : this.trigger(b)
                };
                if (c.attrFn)c.attrFn[b] = true
            });
    A.attachEvent && !A.addEventListener && A.attachEvent("onunload", function() {
        for (var a in c.cache)if (c.cache[a].handle)try {
            c.event.remove(c.cache[a].handle.elem)
        } catch(b) {
        }
    });
    (function() {
        function a(g) {
            for (var h = "",l,m = 0; g[m]; m++) {
                l = g[m];
                if (l.nodeType === 3 || l.nodeType === 4)h += l.nodeValue; else if (l.nodeType !== 8)h += a(l.childNodes)
            }
            return h
        }

        function b(g, h, l, m, q, p) {
            q = 0;
            for (var v = m.length; q < v; q++) {
                var t = m[q];
                if (t) {
                    t = t[g];
                    for (var y = false; t;) {
                        if (t.sizcache === l) {
                            y = m[t.sizset];
                            break
                        }
                        if (t.nodeType === 1 && !p) {
                            t.sizcache = l;
                            t.sizset = q
                        }
                        if (t.nodeName.toLowerCase() === h) {
                            y = t;
                            break
                        }
                        t = t[g]
                    }
                    m[q] = y
                }
            }
        }

        function d(g, h, l, m, q, p) {
            q = 0;
            for (var v = m.length; q < v; q++) {
                var t = m[q];
                if (t) {
                    t = t[g];
                    for (var y = false; t;) {
                        if (t.sizcache === l) {
                            y = m[t.sizset];
                            break
                        }
                        if (t.nodeType === 1) {
                            if (!p) {
                                t.sizcache = l;
                                t.sizset = q
                            }
                            if (typeof h !== "string") {
                                if (t === h) {
                                    y = true;
                                    break
                                }
                            } else if (k.filter(h, [t]).length > 0) {
                                y = t;
                                break
                            }
                        }
                        t = t[g]
                    }
                    m[q] = y
                }
            }
        }

        var f = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^[\]]*\]|['"][^'"]*['"]|[^[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
                e = 0,j = Object.prototype.toString,i = false,o = true;
        [0,0].sort(function() {
            o = false;
            return 0
        });
        var k = function(g, h, l, m) {
            l = l || [];
            var q = h = h || s;
            if (h.nodeType !== 1 && h.nodeType !== 9)return[];
            if (!g || typeof g !== "string")return l;
            for (var p = [],v,t,y,S,H = true,M = x(h),I = g; (f.exec(""),v = f.exec(I)) !== null;) {
                I = v[3];
                p.push(v[1]);
                if (v[2]) {
                    S = v[3];
                    break
                }
            }
            if (p.length > 1 && r.exec(g))if (p.length === 2 && n.relative[p[0]])t = ga(p[0] + p[1], h); else for (t = n.relative[p[0]] ? [h] : k(p.shift(), h); p.length;) {
                g = p.shift();
                if (n.relative[g])g += p.shift();
                t = ga(g, t)
            } else {
                if (!m && p.length > 1 && h.nodeType === 9 && !M && n.match.ID.test(p[0]) && !n.match.ID.test(p[p.length - 1])) {
                    v = k.find(p.shift(), h, M);
                    h = v.expr ? k.filter(v.expr, v.set)[0] : v.set[0]
                }
                if (h) {
                    v = m ? {expr:p.pop(),set:z(m)} : k.find(p.pop(), p.length === 1 && (p[0] === "~" || p[0] === "+") && h.parentNode ? h.parentNode : h, M);
                    t = v.expr ? k.filter(v.expr, v.set) : v.set;
                    if (p.length > 0)y = z(t); else H = false;
                    for (; p.length;) {
                        var D = p.pop();
                        v = D;
                        if (n.relative[D])v = p.pop(); else D = "";
                        if (v == null)v = h;
                        n.relative[D](y, v, M)
                    }
                } else y = []
            }
            y || (y = t);
            y || k.error(D ||
                    g);
            if (j.call(y) === "[object Array]")if (H)if (h && h.nodeType === 1)for (g = 0; y[g] != null; g++) {
                if (y[g] && (y[g] === true || y[g].nodeType === 1 && E(h, y[g])))l.push(t[g])
            } else for (g = 0; y[g] != null; g++)y[g] && y[g].nodeType === 1 && l.push(t[g]); else l.push.apply(l, y); else z(y, l);
            if (S) {
                k(S, q, l, m);
                k.uniqueSort(l)
            }
            return l
        };
        k.uniqueSort = function(g) {
            if (B) {
                i = o;
                g.sort(B);
                if (i)for (var h = 1; h < g.length; h++)g[h] === g[h - 1] && g.splice(h--, 1)
            }
            return g
        };
        k.matches = function(g, h) {
            return k(g, null, null, h)
        };
        k.find = function(g, h, l) {
            var m,q;
            if (!g)return[];
            for (var p = 0,v = n.order.length; p < v; p++) {
                var t = n.order[p];
                if (q = n.leftMatch[t].exec(g)) {
                    var y = q[1];
                    q.splice(1, 1);
                    if (y.substr(y.length - 1) !== "\\") {
                        q[1] = (q[1] || "").replace(/\\/g, "");
                        m = n.find[t](q, h, l);
                        if (m != null) {
                            g = g.replace(n.match[t], "");
                            break
                        }
                    }
                }
            }
            m || (m = h.getElementsByTagName("*"));
            return{set:m,expr:g}
        };
        k.filter = function(g, h, l, m) {
            for (var q = g,p = [],v = h,t,y,S = h && h[0] && x(h[0]); g && h.length;) {
                for (var H in n.filter)if ((t = n.leftMatch[H].exec(g)) != null && t[2]) {
                    var M = n.filter[H],I,D;
                    D = t[1];
                    y = false;
                    t.splice(1, 1);
                    if (D.substr(D.length -
                            1) !== "\\") {
                        if (v === p)p = [];
                        if (n.preFilter[H])if (t = n.preFilter[H](t, v, l, p, m, S)) {
                            if (t === true)continue
                        } else y = I = true;
                        if (t)for (var U = 0; (D = v[U]) != null; U++)if (D) {
                            I = M(D, t, U, v);
                            var Ha = m ^ !!I;
                            if (l && I != null)if (Ha)y = true; else v[U] = false; else if (Ha) {
                                p.push(D);
                                y = true
                            }
                        }
                        if (I !== w) {
                            l || (v = p);
                            g = g.replace(n.match[H], "");
                            if (!y)return[];
                            break
                        }
                    }
                }
                if (g === q)if (y == null)k.error(g); else break;
                q = g
            }
            return v
        };
        k.error = function(g) {
            throw"Syntax error, unrecognized expression: " + g;
        };
        var n = k.selectors = {order:["ID","NAME","TAG"],match:{ID:/#((?:[\w\u00c0-\uFFFF-]|\\.)+)/,
            CLASS:/\.((?:[\w\u00c0-\uFFFF-]|\\.)+)/,NAME:/\[name=['"]*((?:[\w\u00c0-\uFFFF-]|\\.)+)['"]*\]/,ATTR:/\[\s*((?:[\w\u00c0-\uFFFF-]|\\.)+)\s*(?:(\S?=)\s*(['"]*)(.*?)\3|)\s*\]/,TAG:/^((?:[\w\u00c0-\uFFFF\*-]|\\.)+)/,CHILD:/:(only|nth|last|first)-child(?:\((even|odd|[\dn+-]*)\))?/,POS:/:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^-]|$)/,PSEUDO:/:((?:[\w\u00c0-\uFFFF-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/},leftMatch:{},attrMap:{"class":"className","for":"htmlFor"},attrHandle:{href:function(g) {
            return g.getAttribute("href")
        }},
            relative:{"+":function(g, h) {
                var l = typeof h === "string",m = l && !/\W/.test(h);
                l = l && !m;
                if (m)h = h.toLowerCase();
                m = 0;
                for (var q = g.length,p; m < q; m++)if (p = g[m]) {
                    for (; (p = p.previousSibling) && p.nodeType !== 1;);
                    g[m] = l || p && p.nodeName.toLowerCase() === h ? p || false : p === h
                }
                l && k.filter(h, g, true)
            },">":function(g, h) {
                var l = typeof h === "string";
                if (l && !/\W/.test(h)) {
                    h = h.toLowerCase();
                    for (var m = 0,q = g.length; m < q; m++) {
                        var p = g[m];
                        if (p) {
                            l = p.parentNode;
                            g[m] = l.nodeName.toLowerCase() === h ? l : false
                        }
                    }
                } else {
                    m = 0;
                    for (q = g.length; m < q; m++)if (p = g[m])g[m] =
                            l ? p.parentNode : p.parentNode === h;
                    l && k.filter(h, g, true)
                }
            },"":function(g, h, l) {
                var m = e++,q = d;
                if (typeof h === "string" && !/\W/.test(h)) {
                    var p = h = h.toLowerCase();
                    q = b
                }
                q("parentNode", h, m, g, p, l)
            },"~":function(g, h, l) {
                var m = e++,q = d;
                if (typeof h === "string" && !/\W/.test(h)) {
                    var p = h = h.toLowerCase();
                    q = b
                }
                q("previousSibling", h, m, g, p, l)
            }},find:{ID:function(g, h, l) {
                if (typeof h.getElementById !== "undefined" && !l)return(g = h.getElementById(g[1])) ? [g] : []
            },NAME:function(g, h) {
                if (typeof h.getElementsByName !== "undefined") {
                    var l = [];
                    h = h.getElementsByName(g[1]);
                    for (var m = 0,q = h.length; m < q; m++)h[m].getAttribute("name") === g[1] && l.push(h[m]);
                    return l.length === 0 ? null : l
                }
            },TAG:function(g, h) {
                return h.getElementsByTagName(g[1])
            }},preFilter:{CLASS:function(g, h, l, m, q, p) {
                g = " " + g[1].replace(/\\/g, "") + " ";
                if (p)return g;
                p = 0;
                for (var v; (v = h[p]) != null; p++)if (v)if (q ^ (v.className && (" " + v.className + " ").replace(/[\t\n]/g, " ").indexOf(g) >= 0))l || m.push(v); else if (l)h[p] = false;
                return false
            },ID:function(g) {
                return g[1].replace(/\\/g, "")
            },TAG:function(g) {
                return g[1].toLowerCase()
            },
                CHILD:function(g) {
                    if (g[1] === "nth") {
                        var h = /(-?)(\d*)n((?:\+|-)?\d*)/.exec(g[2] === "even" && "2n" || g[2] === "odd" && "2n+1" || !/\D/.test(g[2]) && "0n+" + g[2] || g[2]);
                        g[2] = h[1] + (h[2] || 1) - 0;
                        g[3] = h[3] - 0
                    }
                    g[0] = e++;
                    return g
                },ATTR:function(g, h, l, m, q, p) {
                    h = g[1].replace(/\\/g, "");
                    if (!p && n.attrMap[h])g[1] = n.attrMap[h];
                    if (g[2] === "~=")g[4] = " " + g[4] + " ";
                    return g
                },PSEUDO:function(g, h, l, m, q) {
                    if (g[1] === "not")if ((f.exec(g[3]) || "").length > 1 || /^\w/.test(g[3]))g[3] = k(g[3], null, null, h); else {
                        g = k.filter(g[3], h, l, true ^ q);
                        l || m.push.apply(m,
                                g);
                        return false
                    } else if (n.match.POS.test(g[0]) || n.match.CHILD.test(g[0]))return true;
                    return g
                },POS:function(g) {
                    g.unshift(true);
                    return g
                }},filters:{enabled:function(g) {
                return g.disabled === false && g.type !== "hidden"
            },disabled:function(g) {
                return g.disabled === true
            },checked:function(g) {
                return g.checked === true
            },selected:function(g) {
                return g.selected === true
            },parent:function(g) {
                return!!g.firstChild
            },empty:function(g) {
                return!g.firstChild
            },has:function(g, h, l) {
                return!!k(l[3], g).length
            },header:function(g) {
                return/h\d/i.test(g.nodeName)
            },
                text:function(g) {
                    return"text" === g.type
                },radio:function(g) {
                    return"radio" === g.type
                },checkbox:function(g) {
                    return"checkbox" === g.type
                },file:function(g) {
                    return"file" === g.type
                },password:function(g) {
                    return"password" === g.type
                },submit:function(g) {
                    return"submit" === g.type
                },image:function(g) {
                    return"image" === g.type
                },reset:function(g) {
                    return"reset" === g.type
                },button:function(g) {
                    return"button" === g.type || g.nodeName.toLowerCase() === "button"
                },input:function(g) {
                    return/input|select|textarea|button/i.test(g.nodeName)
                }},
            setFilters:{first:function(g, h) {
                return h === 0
            },last:function(g, h, l, m) {
                return h === m.length - 1
            },even:function(g, h) {
                return h % 2 === 0
            },odd:function(g, h) {
                return h % 2 === 1
            },lt:function(g, h, l) {
                return h < l[3] - 0
            },gt:function(g, h, l) {
                return h > l[3] - 0
            },nth:function(g, h, l) {
                return l[3] - 0 === h
            },eq:function(g, h, l) {
                return l[3] - 0 === h
            }},filter:{PSEUDO:function(g, h, l, m) {
                var q = h[1],p = n.filters[q];
                if (p)return p(g, l, h, m); else if (q === "contains")return(g.textContent || g.innerText || a([g]) || "").indexOf(h[3]) >= 0; else if (q === "not") {
                    h =
                            h[3];
                    l = 0;
                    for (m = h.length; l < m; l++)if (h[l] === g)return false;
                    return true
                } else k.error("Syntax error, unrecognized expression: " + q)
            },CHILD:function(g, h) {
                var l = h[1],m = g;
                switch (l) {case "only":case "first":for (; m = m.previousSibling;)if (m.nodeType === 1)return false;if (l === "first")return true;m = g;case "last":for (; m = m.nextSibling;)if (m.nodeType === 1)return false;return true;case "nth":l = h[2];var q = h[3];if (l === 1 && q === 0)return true;h = h[0];var p = g.parentNode;if (p && (p.sizcache !== h || !g.nodeIndex)) {
                    var v = 0;
                    for (m = p.firstChild; m; m =
                            m.nextSibling)if (m.nodeType === 1)m.nodeIndex = ++v;
                    p.sizcache = h
                }g = g.nodeIndex - q;return l === 0 ? g === 0 : g % l === 0 && g / l >= 0
                }
            },ID:function(g, h) {
                return g.nodeType === 1 && g.getAttribute("id") === h
            },TAG:function(g, h) {
                return h === "*" && g.nodeType === 1 || g.nodeName.toLowerCase() === h
            },CLASS:function(g, h) {
                return(" " + (g.className || g.getAttribute("class")) + " ").indexOf(h) > -1
            },ATTR:function(g, h) {
                var l = h[1];
                g = n.attrHandle[l] ? n.attrHandle[l](g) : g[l] != null ? g[l] : g.getAttribute(l);
                l = g + "";
                var m = h[2];
                h = h[4];
                return g == null ? m === "!=" : m ===
                        "=" ? l === h : m === "*=" ? l.indexOf(h) >= 0 : m === "~=" ? (" " + l + " ").indexOf(h) >= 0 : !h ? l && g !== false : m === "!=" ? l !== h : m === "^=" ? l.indexOf(h) === 0 : m === "$=" ? l.substr(l.length - h.length) === h : m === "|=" ? l === h || l.substr(0, h.length + 1) === h + "-" : false
            },POS:function(g, h, l, m) {
                var q = n.setFilters[h[2]];
                if (q)return q(g, l, h, m)
            }}},r = n.match.POS;
        for (var u in n.match) {
            n.match[u] = new RegExp(n.match[u].source + /(?![^\[]*\])(?![^\(]*\))/.source);
            n.leftMatch[u] = new RegExp(/(^(?:.|\r|\n)*?)/.source + n.match[u].source.replace(/\\(\d+)/g, function(g, h) {
                return"\\" + (h - 0 + 1)
            }))
        }
        var z = function(g, h) {
            g = Array.prototype.slice.call(g, 0);
            if (h) {
                h.push.apply(h, g);
                return h
            }
            return g
        };
        try {
            Array.prototype.slice.call(s.documentElement.childNodes, 0)
        } catch(C) {
            z = function(g, h) {
                h = h || [];
                if (j.call(g) === "[object Array]")Array.prototype.push.apply(h, g); else if (typeof g.length === "number")for (var l = 0,m = g.length; l < m; l++)h.push(g[l]); else for (l = 0; g[l]; l++)h.push(g[l]);
                return h
            }
        }
        var B;
        if (s.documentElement.compareDocumentPosition)B = function(g, h) {
            if (!g.compareDocumentPosition ||
                    !h.compareDocumentPosition) {
                if (g == h)i = true;
                return g.compareDocumentPosition ? -1 : 1
            }
            g = g.compareDocumentPosition(h) & 4 ? -1 : g === h ? 0 : 1;
            if (g === 0)i = true;
            return g
        }; else if ("sourceIndex"in s.documentElement)B = function(g, h) {
            if (!g.sourceIndex || !h.sourceIndex) {
                if (g == h)i = true;
                return g.sourceIndex ? -1 : 1
            }
            g = g.sourceIndex - h.sourceIndex;
            if (g === 0)i = true;
            return g
        }; else if (s.createRange)B = function(g, h) {
            if (!g.ownerDocument || !h.ownerDocument) {
                if (g == h)i = true;
                return g.ownerDocument ? -1 : 1
            }
            var l = g.ownerDocument.createRange(),m =
                    h.ownerDocument.createRange();
            l.setStart(g, 0);
            l.setEnd(g, 0);
            m.setStart(h, 0);
            m.setEnd(h, 0);
            g = l.compareBoundaryPoints(Range.START_TO_END, m);
            if (g === 0)i = true;
            return g
        };
        (function() {
            var g = s.createElement("div"),h = "script" + (new Date).getTime();
            g.innerHTML = "<a name='" + h + "'/>";
            var l = s.documentElement;
            l.insertBefore(g, l.firstChild);
            if (s.getElementById(h)) {
                n.find.ID = function(m, q, p) {
                    if (typeof q.getElementById !== "undefined" && !p)return(q = q.getElementById(m[1])) ? q.id === m[1] || typeof q.getAttributeNode !== "undefined" &&
                            q.getAttributeNode("id").nodeValue === m[1] ? [q] : w : []
                };
                n.filter.ID = function(m, q) {
                    var p = typeof m.getAttributeNode !== "undefined" && m.getAttributeNode("id");
                    return m.nodeType === 1 && p && p.nodeValue === q
                }
            }
            l.removeChild(g);
            l = g = null
        })();
        (function() {
            var g = s.createElement("div");
            g.appendChild(s.createComment(""));
            if (g.getElementsByTagName("*").length > 0)n.find.TAG = function(h, l) {
                l = l.getElementsByTagName(h[1]);
                if (h[1] === "*") {
                    h = [];
                    for (var m = 0; l[m]; m++)l[m].nodeType === 1 && h.push(l[m]);
                    l = h
                }
                return l
            };
            g.innerHTML = "<a href='#'></a>";
            if (g.firstChild && typeof g.firstChild.getAttribute !== "undefined" && g.firstChild.getAttribute("href") !== "#")n.attrHandle.href = function(h) {
                return h.getAttribute("href", 2)
            };
            g = null
        })();
        s.querySelectorAll && function() {
            var g = k,h = s.createElement("div");
            h.innerHTML = "<p class='TEST'></p>";
            if (!(h.querySelectorAll && h.querySelectorAll(".TEST").length === 0)) {
                k = function(m, q, p, v) {
                    q = q || s;
                    if (!v && q.nodeType === 9 && !x(q))try {
                        return z(q.querySelectorAll(m), p)
                    } catch(t) {
                    }
                    return g(m, q, p, v)
                };
                for (var l in g)k[l] = g[l];
                h = null
            }
        }();
        (function() {
            var g = s.createElement("div");
            g.innerHTML = "<div class='test e'></div><div class='test'></div>";
            if (!(!g.getElementsByClassName || g.getElementsByClassName("e").length === 0)) {
                g.lastChild.className = "e";
                if (g.getElementsByClassName("e").length !== 1) {
                    n.order.splice(1, 0, "CLASS");
                    n.find.CLASS = function(h, l, m) {
                        if (typeof l.getElementsByClassName !== "undefined" && !m)return l.getElementsByClassName(h[1])
                    };
                    g = null
                }
            }
        })();
        var E = s.compareDocumentPosition ? function(g, h) {
            return!!(g.compareDocumentPosition(h) & 16)
        } :
                function(g, h) {
                    return g !== h && (g.contains ? g.contains(h) : true)
                },x = function(g) {
            return(g = (g ? g.ownerDocument || g : 0).documentElement) ? g.nodeName !== "HTML" : false
        },ga = function(g, h) {
            var l = [],m = "",q;
            for (h = h.nodeType ? [h] : h; q = n.match.PSEUDO.exec(g);) {
                m += q[0];
                g = g.replace(n.match.PSEUDO, "")
            }
            g = n.relative[g] ? g + "*" : g;
            q = 0;
            for (var p = h.length; q < p; q++)k(g, h[q], l);
            return k.filter(m, l)
        };
        c.find = k;
        c.expr = k.selectors;
        c.expr[":"] = c.expr.filters;
        c.unique = k.uniqueSort;
        c.text = a;
        c.isXMLDoc = x;
        c.contains = E
    })();
    var eb = /Until$/,fb = /^(?:parents|prevUntil|prevAll)/,
            gb = /,/;
    R = Array.prototype.slice;
    var Ia = function(a, b, d) {
        if (c.isFunction(b))return c.grep(a, function(e, j) {
            return!!b.call(e, j, e) === d
        }); else if (b.nodeType)return c.grep(a, function(e) {
            return e === b === d
        }); else if (typeof b === "string") {
            var f = c.grep(a, function(e) {
                return e.nodeType === 1
            });
            if (Ua.test(b))return c.filter(b, f, !d); else b = c.filter(b, f)
        }
        return c.grep(a, function(e) {
            return c.inArray(e, b) >= 0 === d
        })
    };
    c.fn.extend({find:function(a) {
        for (var b = this.pushStack("", "find", a),d = 0,f = 0,e = this.length; f < e; f++) {
            d = b.length;
            c.find(a, this[f], b);
            if (f > 0)for (var j = d; j < b.length; j++)for (var i = 0; i < d; i++)if (b[i] === b[j]) {
                b.splice(j--, 1);
                break
            }
        }
        return b
    },has:function(a) {
        var b = c(a);
        return this.filter(function() {
            for (var d = 0,f = b.length; d < f; d++)if (c.contains(this, b[d]))return true
        })
    },not:function(a) {
        return this.pushStack(Ia(this, a, false), "not", a)
    },filter:function(a) {
        return this.pushStack(Ia(this, a, true), "filter", a)
    },is:function(a) {
        return!!a && c.filter(a, this).length > 0
    },closest:function(a, b) {
        if (c.isArray(a)) {
            var d = [],f = this[0],e,j =
            {},i;
            if (f && a.length) {
                e = 0;
                for (var o = a.length; e < o; e++) {
                    i = a[e];
                    j[i] || (j[i] = c.expr.match.POS.test(i) ? c(i, b || this.context) : i)
                }
                for (; f && f.ownerDocument && f !== b;) {
                    for (i in j) {
                        e = j[i];
                        if (e.jquery ? e.index(f) > -1 : c(f).is(e)) {
                            d.push({selector:i,elem:f});
                            delete j[i]
                        }
                    }
                    f = f.parentNode
                }
            }
            return d
        }
        var k = c.expr.match.POS.test(a) ? c(a, b || this.context) : null;
        return this.map(function(n, r) {
            for (; r && r.ownerDocument && r !== b;) {
                if (k ? k.index(r) > -1 : c(r).is(a))return r;
                r = r.parentNode
            }
            return null
        })
    },index:function(a) {
        if (!a || typeof a ===
                "string")return c.inArray(this[0], a ? c(a) : this.parent().children());
        return c.inArray(a.jquery ? a[0] : a, this)
    },add:function(a, b) {
        a = typeof a === "string" ? c(a, b || this.context) : c.makeArray(a);
        b = c.merge(this.get(), a);
        return this.pushStack(qa(a[0]) || qa(b[0]) ? b : c.unique(b))
    },andSelf:function() {
        return this.add(this.prevObject)
    }});
    c.each({parent:function(a) {
        return(a = a.parentNode) && a.nodeType !== 11 ? a : null
    },parents:function(a) {
        return c.dir(a, "parentNode")
    },parentsUntil:function(a, b, d) {
        return c.dir(a, "parentNode",
                d)
    },next:function(a) {
        return c.nth(a, 2, "nextSibling")
    },prev:function(a) {
        return c.nth(a, 2, "previousSibling")
    },nextAll:function(a) {
        return c.dir(a, "nextSibling")
    },prevAll:function(a) {
        return c.dir(a, "previousSibling")
    },nextUntil:function(a, b, d) {
        return c.dir(a, "nextSibling", d)
    },prevUntil:function(a, b, d) {
        return c.dir(a, "previousSibling", d)
    },siblings:function(a) {
        return c.sibling(a.parentNode.firstChild, a)
    },children:function(a) {
        return c.sibling(a.firstChild)
    },contents:function(a) {
        return c.nodeName(a, "iframe") ?
                a.contentDocument || a.contentWindow.document : c.makeArray(a.childNodes)
    }}, function(a, b) {
        c.fn[a] = function(d, f) {
            var e = c.map(this, b, d);
            eb.test(a) || (f = d);
            if (f && typeof f === "string")e = c.filter(f, e);
            e = this.length > 1 ? c.unique(e) : e;
            if ((this.length > 1 || gb.test(f)) && fb.test(a))e = e.reverse();
            return this.pushStack(e, a, R.call(arguments).join(","))
        }
    });
    c.extend({filter:function(a, b, d) {
        if (d)a = ":not(" + a + ")";
        return c.find.matches(a, b)
    },dir:function(a, b, d) {
        var f = [];
        for (a = a[b]; a && a.nodeType !== 9 && (d === w || a.nodeType !== 1 || !c(a).is(d));) {
            a.nodeType ===
                    1 && f.push(a);
            a = a[b]
        }
        return f
    },nth:function(a, b, d) {
        b = b || 1;
        for (var f = 0; a; a = a[d])if (a.nodeType === 1 && ++f === b)break;
        return a
    },sibling:function(a, b) {
        for (var d = []; a; a = a.nextSibling)a.nodeType === 1 && a !== b && d.push(a);
        return d
    }});
    var Ja = / jQuery\d+="(?:\d+|null)"/g,V = /^\s+/,Ka = /(<([\w:]+)[^>]*?)\/>/g,hb = /^(?:area|br|col|embed|hr|img|input|link|meta|param)$/i,La = /<([\w:]+)/,ib = /<tbody/i,jb = /<|&#?\w+;/,ta = /<script|<object|<embed|<option|<style/i,ua = /checked\s*(?:[^=]|=\s*.checked.)/i,Ma = function(a, b, d) {
        return hb.test(d) ?
                a : b + "></" + d + ">"
    },F = {option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]};
    F.optgroup = F.option;
    F.tbody = F.tfoot = F.colgroup = F.caption = F.thead;
    F.th = F.td;
    if (!c.support.htmlSerialize)F._default = [1,"div<div>","</div>"];
    c.fn.extend({text:function(a) {
        if (c.isFunction(a))return this.each(function(b) {
            var d =
                    c(this);
            d.text(a.call(this, b, d.text()))
        });
        if (typeof a !== "object" && a !== w)return this.empty().append((this[0] && this[0].ownerDocument || s).createTextNode(a));
        return c.text(this)
    },wrapAll:function(a) {
        if (c.isFunction(a))return this.each(function(d) {
            c(this).wrapAll(a.call(this, d))
        });
        if (this[0]) {
            var b = c(a, this[0].ownerDocument).eq(0).clone(true);
            this[0].parentNode && b.insertBefore(this[0]);
            b.map(
                    function() {
                        for (var d = this; d.firstChild && d.firstChild.nodeType === 1;)d = d.firstChild;
                        return d
                    }).append(this)
        }
        return this
    },
        wrapInner:function(a) {
            if (c.isFunction(a))return this.each(function(b) {
                c(this).wrapInner(a.call(this, b))
            });
            return this.each(function() {
                var b = c(this),d = b.contents();
                d.length ? d.wrapAll(a) : b.append(a)
            })
        },wrap:function(a) {
            return this.each(function() {
                c(this).wrapAll(a)
            })
        },unwrap:function() {
            return this.parent().each(
                    function() {
                        c.nodeName(this, "body") || c(this).replaceWith(this.childNodes)
                    }).end()
        },append:function() {
            return this.domManip(arguments, true, function(a) {
                this.nodeType === 1 && this.appendChild(a)
            })
        },
        prepend:function() {
            return this.domManip(arguments, true, function(a) {
                this.nodeType === 1 && this.insertBefore(a, this.firstChild)
            })
        },before:function() {
            if (this[0] && this[0].parentNode)return this.domManip(arguments, false, function(b) {
                this.parentNode.insertBefore(b, this)
            }); else if (arguments.length) {
                var a = c(arguments[0]);
                a.push.apply(a, this.toArray());
                return this.pushStack(a, "before", arguments)
            }
        },after:function() {
            if (this[0] && this[0].parentNode)return this.domManip(arguments, false, function(b) {
                this.parentNode.insertBefore(b,
                        this.nextSibling)
            }); else if (arguments.length) {
                var a = this.pushStack(this, "after", arguments);
                a.push.apply(a, c(arguments[0]).toArray());
                return a
            }
        },remove:function(a, b) {
            for (var d = 0,f; (f = this[d]) != null; d++)if (!a || c.filter(a, [f]).length) {
                if (!b && f.nodeType === 1) {
                    c.cleanData(f.getElementsByTagName("*"));
                    c.cleanData([f])
                }
                f.parentNode && f.parentNode.removeChild(f)
            }
            return this
        },empty:function() {
            for (var a = 0,b; (b = this[a]) != null; a++)for (b.nodeType === 1 && c.cleanData(b.getElementsByTagName("*")); b.firstChild;)b.removeChild(b.firstChild);
            return this
        },clone:function(a) {
            var b = this.map(function() {
                if (!c.support.noCloneEvent && !c.isXMLDoc(this)) {
                    var d = this.outerHTML,f = this.ownerDocument;
                    if (!d) {
                        d = f.createElement("div");
                        d.appendChild(this.cloneNode(true));
                        d = d.innerHTML
                    }
                    return c.clean([d.replace(Ja, "").replace(/=([^="'>\s]+\/)>/g, '="$1">').replace(V, "")], f)[0]
                } else return this.cloneNode(true)
            });
            if (a === true) {
                ra(this, b);
                ra(this.find("*"), b.find("*"))
            }
            return b
        },html:function(a) {
            if (a === w)return this[0] && this[0].nodeType === 1 ? this[0].innerHTML.replace(Ja,
                    "") : null; else if (typeof a === "string" && !ta.test(a) && (c.support.leadingWhitespace || !V.test(a)) && !F[(La.exec(a) || ["",""])[1].toLowerCase()]) {
                a = a.replace(Ka, Ma);
                try {
                    for (var b = 0,d = this.length; b < d; b++)if (this[b].nodeType === 1) {
                        c.cleanData(this[b].getElementsByTagName("*"));
                        this[b].innerHTML = a
                    }
                } catch(f) {
                    this.empty().append(a)
                }
            } else c.isFunction(a) ? this.each(function(e) {
                var j = c(this),i = j.html();
                j.empty().append(function() {
                    return a.call(this, e, i)
                })
            }) : this.empty().append(a);
            return this
        },replaceWith:function(a) {
            if (this[0] &&
                    this[0].parentNode) {
                if (c.isFunction(a))return this.each(function(b) {
                    var d = c(this),f = d.html();
                    d.replaceWith(a.call(this, b, f))
                });
                if (typeof a !== "string")a = c(a).detach();
                return this.each(function() {
                    var b = this.nextSibling,d = this.parentNode;
                    c(this).remove();
                    b ? c(b).before(a) : c(d).append(a)
                })
            } else return this.pushStack(c(c.isFunction(a) ? a() : a), "replaceWith", a)
        },detach:function(a) {
            return this.remove(a, true)
        },domManip:function(a, b, d) {
            function f(u) {
                return c.nodeName(u, "table") ? u.getElementsByTagName("tbody")[0] ||
                        u.appendChild(u.ownerDocument.createElement("tbody")) : u
            }

            var e,j,i = a[0],o = [],k;
            if (!c.support.checkClone && arguments.length === 3 && typeof i === "string" && ua.test(i))return this.each(function() {
                c(this).domManip(a, b, d, true)
            });
            if (c.isFunction(i))return this.each(function(u) {
                var z = c(this);
                a[0] = i.call(this, u, b ? z.html() : w);
                z.domManip(a, b, d)
            });
            if (this[0]) {
                e = i && i.parentNode;
                e = c.support.parentNode && e && e.nodeType === 11 && e.childNodes.length === this.length ? {fragment:e} : sa(a, this, o);
                k = e.fragment;
                if (j = k.childNodes.length ===
                        1 ? (k = k.firstChild) : k.firstChild) {
                    b = b && c.nodeName(j, "tr");
                    for (var n = 0,r = this.length; n < r; n++)d.call(b ? f(this[n], j) : this[n], n > 0 || e.cacheable || this.length > 1 ? k.cloneNode(true) : k)
                }
                o.length && c.each(o, Qa)
            }
            return this
        }});
    c.fragments = {};
    c.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"}, function(a, b) {
        c.fn[a] = function(d) {
            var f = [];
            d = c(d);
            var e = this.length === 1 && this[0].parentNode;
            if (e && e.nodeType === 11 && e.childNodes.length === 1 && d.length === 1) {
                d[b](this[0]);
                return this
            } else {
                e = 0;
                for (var j = d.length; e < j; e++) {
                    var i = (e > 0 ? this.clone(true) : this).get();
                    c.fn[b].apply(c(d[e]), i);
                    f = f.concat(i)
                }
                return this.pushStack(f, a, d.selector)
            }
        }
    });
    c.extend({clean:function(a, b, d, f) {
        b = b || s;
        if (typeof b.createElement === "undefined")b = b.ownerDocument || b[0] && b[0].ownerDocument || s;
        for (var e = [],j = 0,i; (i = a[j]) != null; j++) {
            if (typeof i === "number")i += "";
            if (i) {
                if (typeof i === "string" && !jb.test(i))i = b.createTextNode(i); else if (typeof i === "string") {
                    i = i.replace(Ka, Ma);
                    var o = (La.exec(i) || ["",
                        ""])[1].toLowerCase(),k = F[o] || F._default,n = k[0],r = b.createElement("div");
                    for (r.innerHTML = k[1] + i + k[2]; n--;)r = r.lastChild;
                    if (!c.support.tbody) {
                        n = ib.test(i);
                        o = o === "table" && !n ? r.firstChild && r.firstChild.childNodes : k[1] === "<table>" && !n ? r.childNodes : [];
                        for (k = o.length - 1; k >= 0; --k)c.nodeName(o[k], "tbody") && !o[k].childNodes.length && o[k].parentNode.removeChild(o[k])
                    }
                    !c.support.leadingWhitespace && V.test(i) && r.insertBefore(b.createTextNode(V.exec(i)[0]), r.firstChild);
                    i = r.childNodes
                }
                if (i.nodeType)e.push(i); else e =
                        c.merge(e, i)
            }
        }
        if (d)for (j = 0; e[j]; j++)if (f && c.nodeName(e[j], "script") && (!e[j].type || e[j].type.toLowerCase() === "text/javascript"))f.push(e[j].parentNode ? e[j].parentNode.removeChild(e[j]) : e[j]); else {
            e[j].nodeType === 1 && e.splice.apply(e, [j + 1,0].concat(c.makeArray(e[j].getElementsByTagName("script"))));
            d.appendChild(e[j])
        }
        return e
    },cleanData:function(a) {
        for (var b,d,f = c.cache,e = c.event.special,j = c.support.deleteExpando,i = 0,o; (o = a[i]) != null; i++)if (d = o[c.expando]) {
            b = f[d];
            if (b.events)for (var k in b.events)e[k] ?
                    c.event.remove(o, k) : Ca(o, k, b.handle);
            if (j)delete o[c.expando]; else o.removeAttribute && o.removeAttribute(c.expando);
            delete f[d]
        }
    }});
    var kb = /z-?index|font-?weight|opacity|zoom|line-?height/i,Na = /alpha\([^)]*\)/,Oa = /opacity=([^)]*)/,ha = /float/i,ia = /-([a-z])/ig,lb = /([A-Z])/g,mb = /^-?\d+(?:px)?$/i,nb = /^-?\d/,ob = {position:"absolute",visibility:"hidden",display:"block"},pb = ["Left","Right"],qb = ["Top","Bottom"],rb = s.defaultView && s.defaultView.getComputedStyle,Pa = c.support.cssFloat ? "cssFloat" : "styleFloat",ja =
            function(a, b) {
                return b.toUpperCase()
            };
    c.fn.css = function(a, b) {
        return X(this, a, b, true, function(d, f, e) {
            if (e === w)return c.curCSS(d, f);
            if (typeof e === "number" && !kb.test(f))e += "px";
            c.style(d, f, e)
        })
    };
    c.extend({style:function(a, b, d) {
        if (!a || a.nodeType === 3 || a.nodeType === 8)return w;
        if ((b === "width" || b === "height") && parseFloat(d) < 0)d = w;
        var f = a.style || a,e = d !== w;
        if (!c.support.opacity && b === "opacity") {
            if (e) {
                f.zoom = 1;
                b = parseInt(d, 10) + "" === "NaN" ? "" : "alpha(opacity=" + d * 100 + ")";
                a = f.filter || c.curCSS(a, "filter") || "";
                f.filter =
                        Na.test(a) ? a.replace(Na, b) : b
            }
            return f.filter && f.filter.indexOf("opacity=") >= 0 ? parseFloat(Oa.exec(f.filter)[1]) / 100 + "" : ""
        }
        if (ha.test(b))b = Pa;
        b = b.replace(ia, ja);
        if (e)f[b] = d;
        return f[b]
    },css:function(a, b, d, f) {
        if (b === "width" || b === "height") {
            var e,j = b === "width" ? pb : qb;

            function i() {
                e = b === "width" ? a.offsetWidth : a.offsetHeight;
                f !== "border" && c.each(j, function() {
                    f || (e -= parseFloat(c.curCSS(a, "padding" + this, true)) || 0);
                    if (f === "margin")e += parseFloat(c.curCSS(a, "margin" + this, true)) || 0; else e -= parseFloat(c.curCSS(a,
                            "border" + this + "Width", true)) || 0
                })
            }

            a.offsetWidth !== 0 ? i() : c.swap(a, ob, i);
            return Math.max(0, Math.round(e))
        }
        return c.curCSS(a, b, d)
    },curCSS:function(a, b, d) {
        var f,e = a.style;
        if (!c.support.opacity && b === "opacity" && a.currentStyle) {
            f = Oa.test(a.currentStyle.filter || "") ? parseFloat(RegExp.$1) / 100 + "" : "";
            return f === "" ? "1" : f
        }
        if (ha.test(b))b = Pa;
        if (!d && e && e[b])f = e[b]; else if (rb) {
            if (ha.test(b))b = "float";
            b = b.replace(lb, "-$1").toLowerCase();
            e = a.ownerDocument.defaultView;
            if (!e)return null;
            if (a = e.getComputedStyle(a, null))f =
                    a.getPropertyValue(b);
            if (b === "opacity" && f === "")f = "1"
        } else if (a.currentStyle) {
            d = b.replace(ia, ja);
            f = a.currentStyle[b] || a.currentStyle[d];
            if (!mb.test(f) && nb.test(f)) {
                b = e.left;
                var j = a.runtimeStyle.left;
                a.runtimeStyle.left = a.currentStyle.left;
                e.left = d === "fontSize" ? "1em" : f || 0;
                f = e.pixelLeft + "px";
                e.left = b;
                a.runtimeStyle.left = j
            }
        }
        return f
    },swap:function(a, b, d) {
        var f = {};
        for (var e in b) {
            f[e] = a.style[e];
            a.style[e] = b[e]
        }
        d.call(a);
        for (e in b)a.style[e] = f[e]
    }});
    if (c.expr && c.expr.filters) {
        c.expr.filters.hidden = function(a) {
            var b =
                    a.offsetWidth,d = a.offsetHeight,f = a.nodeName.toLowerCase() === "tr";
            return b === 0 && d === 0 && !f ? true : b > 0 && d > 0 && !f ? false : c.curCSS(a, "display") === "none"
        };
        c.expr.filters.visible = function(a) {
            return!c.expr.filters.hidden(a)
        }
    }
    var sb = J(),tb = /<script(.|\s)*?\/script>/gi,ub = /select|textarea/i,vb = /color|date|datetime|email|hidden|month|number|password|range|search|tel|text|time|url|week/i,N = /=\?(&|$)/,ka = /\?/,wb = /(\?|&)_=.*?(&|$)/,xb = /^(\w+:)?\/\/([^\/?#]+)/,yb = /%20/g,zb = c.fn.load;
    c.fn.extend({load:function(a, b, d) {
        if (typeof a !==
                "string")return zb.call(this, a); else if (!this.length)return this;
        var f = a.indexOf(" ");
        if (f >= 0) {
            var e = a.slice(f, a.length);
            a = a.slice(0, f)
        }
        f = "GET";
        if (b)if (c.isFunction(b)) {
            d = b;
            b = null
        } else if (typeof b === "object") {
            b = c.param(b, c.ajaxSettings.traditional);
            f = "POST"
        }
        var j = this;
        c.ajax({url:a,type:f,dataType:"html",data:b,complete:function(i, o) {
            if (o === "success" || o === "notmodified")j.html(e ? c("<div />").append(i.responseText.replace(tb, "")).find(e) : i.responseText);
            d && j.each(d, [i.responseText,o,i])
        }});
        return this
    },
        serialize:function() {
            return c.param(this.serializeArray())
        },serializeArray:function() {
            return this.map(
                    function() {
                        return this.elements ? c.makeArray(this.elements) : this
                    }).filter(
                    function() {
                        return this.name && !this.disabled && (this.checked || ub.test(this.nodeName) || vb.test(this.type))
                    }).map(
                    function(a, b) {
                        a = c(this).val();
                        return a == null ? null : c.isArray(a) ? c.map(a, function(d) {
                            return{name:b.name,value:d}
                        }) : {name:b.name,value:a}
                    }).get()
        }});
    c.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),
            function(a, b) {
                c.fn[b] = function(d) {
                    return this.bind(b, d)
                }
            });
    c.extend({get:function(a, b, d, f) {
        if (c.isFunction(b)) {
            f = f || d;
            d = b;
            b = null
        }
        return c.ajax({type:"GET",url:a,data:b,success:d,dataType:f})
    },getScript:function(a, b) {
        return c.get(a, null, b, "script")
    },getJSON:function(a, b, d) {
        return c.get(a, b, d, "json")
    },post:function(a, b, d, f) {
        if (c.isFunction(b)) {
            f = f || d;
            d = b;
            b = {}
        }
        return c.ajax({type:"POST",url:a,data:b,success:d,dataType:f})
    },ajaxSetup:function(a) {
        c.extend(c.ajaxSettings, a)
    },ajaxSettings:{url:location.href,
        global:true,type:"GET",contentType:"application/x-www-form-urlencoded",processData:true,async:true,xhr:A.XMLHttpRequest && (A.location.protocol !== "file:" || !A.ActiveXObject) ? function() {
            return new A.XMLHttpRequest
        } : function() {
            try {
                return new A.ActiveXObject("Microsoft.XMLHTTP")
            } catch(a) {
            }
        },accepts:{xml:"application/xml, text/xml",html:"text/html",script:"text/javascript, application/javascript",json:"application/json, text/javascript",text:"text/plain",_default:"*/*"}},lastModified:{},etag:{},ajax:function(a) {
        function b() {
            e.success &&
            e.success.call(k, o, i, x);
            e.global && f("ajaxSuccess", [x,e])
        }

        function d() {
            e.complete && e.complete.call(k, x, i);
            e.global && f("ajaxComplete", [x,e]);
            e.global && !--c.active && c.event.trigger("ajaxStop")
        }

        function f(q, p) {
            (e.context ? c(e.context) : c.event).trigger(q, p)
        }

        var e = c.extend(true, {}, c.ajaxSettings, a),j,i,o,k = a && a.context || e,n = e.type.toUpperCase();
        if (e.data && e.processData && typeof e.data !== "string")e.data = c.param(e.data, e.traditional);
        if (e.dataType === "jsonp") {
            if (n === "GET")N.test(e.url) || (e.url += (ka.test(e.url) ?
                    "&" : "?") + (e.jsonp || "callback") + "=?"); else if (!e.data || !N.test(e.data))e.data = (e.data ? e.data + "&" : "") + (e.jsonp || "callback") + "=?";
            e.dataType = "json"
        }
        if (e.dataType === "json" && (e.data && N.test(e.data) || N.test(e.url))) {
            j = e.jsonpCallback || "jsonp" + sb++;
            if (e.data)e.data = (e.data + "").replace(N, "=" + j + "$1");
            e.url = e.url.replace(N, "=" + j + "$1");
            e.dataType = "script";
            A[j] = A[j] || function(q) {
                o = q;
                b();
                d();
                A[j] = w;
                try {
                    delete A[j]
                } catch(p) {
                }
                z && z.removeChild(C)
            }
        }
        if (e.dataType === "script" && e.cache === null)e.cache = false;
        if (e.cache ===
                false && n === "GET") {
            var r = J(),u = e.url.replace(wb, "$1_=" + r + "$2");
            e.url = u + (u === e.url ? (ka.test(e.url) ? "&" : "?") + "_=" + r : "")
        }
        if (e.data && n === "GET")e.url += (ka.test(e.url) ? "&" : "?") + e.data;
        e.global && !c.active++ && c.event.trigger("ajaxStart");
        r = (r = xb.exec(e.url)) && (r[1] && r[1] !== location.protocol || r[2] !== location.host);
        if (e.dataType === "script" && n === "GET" && r) {
            var z = s.getElementsByTagName("head")[0] || s.documentElement,C = s.createElement("script");
            C.src = e.url;
            if (e.scriptCharset)C.charset = e.scriptCharset;
            if (!j) {
                var B =
                        false;
                C.onload = C.onreadystatechange = function() {
                    if (!B && (!this.readyState || this.readyState === "loaded" || this.readyState === "complete")) {
                        B = true;
                        b();
                        d();
                        C.onload = C.onreadystatechange = null;
                        z && C.parentNode && z.removeChild(C)
                    }
                }
            }
            z.insertBefore(C, z.firstChild);
            return w
        }
        var E = false,x = e.xhr();
        if (x) {
            e.username ? x.open(n, e.url, e.async, e.username, e.password) : x.open(n, e.url, e.async);
            try {
                if (e.data || a && a.contentType)x.setRequestHeader("Content-Type", e.contentType);
                if (e.ifModified) {
                    c.lastModified[e.url] && x.setRequestHeader("If-Modified-Since",
                            c.lastModified[e.url]);
                    c.etag[e.url] && x.setRequestHeader("If-None-Match", c.etag[e.url])
                }
                r || x.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                x.setRequestHeader("Accept", e.dataType && e.accepts[e.dataType] ? e.accepts[e.dataType] + ", */*" : e.accepts._default)
            } catch(ga) {
            }
            if (e.beforeSend && e.beforeSend.call(k, x, e) === false) {
                e.global && !--c.active && c.event.trigger("ajaxStop");
                x.abort();
                return false
            }
            e.global && f("ajaxSend", [x,e]);
            var g = x.onreadystatechange = function(q) {
                if (!x || x.readyState === 0 || q === "abort") {
                    E ||
                    d();
                    E = true;
                    if (x)x.onreadystatechange = c.noop
                } else if (!E && x && (x.readyState === 4 || q === "timeout")) {
                    E = true;
                    x.onreadystatechange = c.noop;
                    i = q === "timeout" ? "timeout" : !c.httpSuccess(x) ? "error" : e.ifModified && c.httpNotModified(x, e.url) ? "notmodified" : "success";
                    var p;
                    if (i === "success")try {
                        o = c.httpData(x, e.dataType, e)
                    } catch(v) {
                        i = "parsererror";
                        p = v
                    }
                    if (i === "success" || i === "notmodified")j || b(); else c.handleError(e, x, i, p);
                    d();
                    q === "timeout" && x.abort();
                    if (e.async)x = null
                }
            };
            try {
                var h = x.abort;
                x.abort = function() {
                    x && h.call(x);
                    g("abort")
                }
            } catch(l) {
            }
            e.async && e.timeout > 0 && setTimeout(function() {
                x && !E && g("timeout")
            }, e.timeout);
            try {
                x.send(n === "POST" || n === "PUT" || n === "DELETE" ? e.data : null)
            } catch(m) {
                c.handleError(e, x, null, m);
                d()
            }
            e.async || g();
            return x
        }
    },handleError:function(a, b, d, f) {
        if (a.error)a.error.call(a.context || a, b, d, f);
        if (a.global)(a.context ? c(a.context) : c.event).trigger("ajaxError", [b,a,f])
    },active:0,httpSuccess:function(a) {
        try {
            return!a.status && location.protocol === "file:" || a.status >= 200 && a.status < 300 || a.status === 304 || a.status ===
                    1223 || a.status === 0
        } catch(b) {
        }
        return false
    },httpNotModified:function(a, b) {
        var d = a.getResponseHeader("Last-Modified"),f = a.getResponseHeader("Etag");
        if (d)c.lastModified[b] = d;
        if (f)c.etag[b] = f;
        return a.status === 304 || a.status === 0
    },httpData:function(a, b, d) {
        var f = a.getResponseHeader("content-type") || "",e = b === "xml" || !b && f.indexOf("xml") >= 0;
        a = e ? a.responseXML : a.responseText;
        e && a.documentElement.nodeName === "parsererror" && c.error("parsererror");
        if (d && d.dataFilter)a = d.dataFilter(a, b);
        if (typeof a === "string")if (b ===
                "json" || !b && f.indexOf("json") >= 0)a = c.parseJSON(a); else if (b === "script" || !b && f.indexOf("javascript") >= 0)c.globalEval(a);
        return a
    },param:function(a, b) {
        function d(i, o) {
            if (c.isArray(o))c.each(o, function(k, n) {
                b || /\[\]$/.test(i) ? f(i, n) : d(i + "[" + (typeof n === "object" || c.isArray(n) ? k : "") + "]", n)
            }); else!b && o != null && typeof o === "object" ? c.each(o, function(k, n) {
                d(i + "[" + k + "]", n)
            }) : f(i, o)
        }

        function f(i, o) {
            o = c.isFunction(o) ? o() : o;
            e[e.length] = encodeURIComponent(i) + "=" + encodeURIComponent(o)
        }

        var e = [];
        if (b === w)b = c.ajaxSettings.traditional;
        if (c.isArray(a) || a.jquery)c.each(a, function() {
            f(this.name, this.value)
        }); else for (var j in a)d(j, a[j]);
        return e.join("&").replace(yb, "+")
    }});
    var la = {},Ab = /toggle|show|hide/,Bb = /^([+-]=)?([\d+-.]+)(.*)$/,W,va = [
        ["height","marginTop","marginBottom","paddingTop","paddingBottom"],
        ["width","marginLeft","marginRight","paddingLeft","paddingRight"],
        ["opacity"]
    ];
    c.fn.extend({show:function(a, b) {
        if (a || a === 0)return this.animate(K("show", 3), a, b); else {
            a = 0;
            for (b = this.length; a < b; a++) {
                var d = c.data(this[a], "olddisplay");
                this[a].style.display = d || "";
                if (c.css(this[a], "display") === "none") {
                    d = this[a].nodeName;
                    var f;
                    if (la[d])f = la[d]; else {
                        var e = c("<" + d + " />").appendTo("body");
                        f = e.css("display");
                        if (f === "none")f = "block";
                        e.remove();
                        la[d] = f
                    }
                    c.data(this[a], "olddisplay", f)
                }
            }
            a = 0;
            for (b = this.length; a < b; a++)this[a].style.display = c.data(this[a], "olddisplay") || "";
            return this
        }
    },hide:function(a, b) {
        if (a || a === 0)return this.animate(K("hide", 3), a, b); else {
            a = 0;
            for (b = this.length; a < b; a++) {
                var d = c.data(this[a], "olddisplay");
                !d && d !== "none" && c.data(this[a],
                        "olddisplay", c.css(this[a], "display"))
            }
            a = 0;
            for (b = this.length; a < b; a++)this[a].style.display = "none";
            return this
        }
    },_toggle:c.fn.toggle,toggle:function(a, b) {
        var d = typeof a === "boolean";
        if (c.isFunction(a) && c.isFunction(b))this._toggle.apply(this, arguments); else a == null || d ? this.each(function() {
            var f = d ? a : c(this).is(":hidden");
            c(this)[f ? "show" : "hide"]()
        }) : this.animate(K("toggle", 3), a, b);
        return this
    },fadeTo:function(a, b, d) {
        return this.filter(":hidden").css("opacity", 0).show().end().animate({opacity:b}, a, d)
    },
        animate:function(a, b, d, f) {
            var e = c.speed(b, d, f);
            if (c.isEmptyObject(a))return this.each(e.complete);
            return this[e.queue === false ? "each" : "queue"](function() {
                var j = c.extend({}, e),i,o = this.nodeType === 1 && c(this).is(":hidden"),k = this;
                for (i in a) {
                    var n = i.replace(ia, ja);
                    if (i !== n) {
                        a[n] = a[i];
                        delete a[i];
                        i = n
                    }
                    if (a[i] === "hide" && o || a[i] === "show" && !o)return j.complete.call(this);
                    if ((i === "height" || i === "width") && this.style) {
                        j.display = c.css(this, "display");
                        j.overflow = this.style.overflow
                    }
                    if (c.isArray(a[i])) {
                        (j.specialEasing =
                                j.specialEasing || {})[i] = a[i][1];
                        a[i] = a[i][0]
                    }
                }
                if (j.overflow != null)this.style.overflow = "hidden";
                j.curAnim = c.extend({}, a);
                c.each(a, function(r, u) {
                    var z = new c.fx(k, j, r);
                    if (Ab.test(u))z[u === "toggle" ? o ? "show" : "hide" : u](a); else {
                        var C = Bb.exec(u),B = z.cur(true) || 0;
                        if (C) {
                            u = parseFloat(C[2]);
                            var E = C[3] || "px";
                            if (E !== "px") {
                                k.style[r] = (u || 1) + E;
                                B = (u || 1) / z.cur(true) * B;
                                k.style[r] = B + E
                            }
                            if (C[1])u = (C[1] === "-=" ? -1 : 1) * u + B;
                            z.custom(B, u, E)
                        } else z.custom(B, u, "")
                    }
                });
                return true
            })
        },stop:function(a, b) {
            var d = c.timers;
            a && this.queue([]);
            this.each(function() {
                for (var f = d.length - 1; f >= 0; f--)if (d[f].elem === this) {
                    b && d[f](true);
                    d.splice(f, 1)
                }
            });
            b || this.dequeue();
            return this
        }});
    c.each({slideDown:K("show", 1),slideUp:K("hide", 1),slideToggle:K("toggle", 1),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"}}, function(a, b) {
        c.fn[a] = function(d, f) {
            return this.animate(b, d, f)
        }
    });
    c.extend({speed:function(a, b, d) {
        var f = a && typeof a === "object" ? a : {complete:d || !d && b || c.isFunction(a) && a,duration:a,easing:d && b || b && !c.isFunction(b) && b};
        f.duration = c.fx.off ? 0 : typeof f.duration ===
                "number" ? f.duration : c.fx.speeds[f.duration] || c.fx.speeds._default;
        f.old = f.complete;
        f.complete = function() {
            f.queue !== false && c(this).dequeue();
            c.isFunction(f.old) && f.old.call(this)
        };
        return f
    },easing:{linear:function(a, b, d, f) {
        return d + f * a
    },swing:function(a, b, d, f) {
        return(-Math.cos(a * Math.PI) / 2 + 0.5) * f + d
    }},timers:[],fx:function(a, b, d) {
        this.options = b;
        this.elem = a;
        this.prop = d;
        if (!b.orig)b.orig = {}
    }});
    c.fx.prototype = {update:function() {
        this.options.step && this.options.step.call(this.elem, this.now, this);
        (c.fx.step[this.prop] ||
                c.fx.step._default)(this);
        if ((this.prop === "height" || this.prop === "width") && this.elem.style)this.elem.style.display = "block"
    },cur:function(a) {
        if (this.elem[this.prop] != null && (!this.elem.style || this.elem.style[this.prop] == null))return this.elem[this.prop];
        return(a = parseFloat(c.css(this.elem, this.prop, a))) && a > -10000 ? a : parseFloat(c.curCSS(this.elem, this.prop)) || 0
    },custom:function(a, b, d) {
        function f(j) {
            return e.step(j)
        }

        this.startTime = J();
        this.start = a;
        this.end = b;
        this.unit = d || this.unit || "px";
        this.now = this.start;
        this.pos = this.state = 0;
        var e = this;
        f.elem = this.elem;
        if (f() && c.timers.push(f) && !W)W = setInterval(c.fx.tick, 13)
    },show:function() {
        this.options.orig[this.prop] = c.style(this.elem, this.prop);
        this.options.show = true;
        this.custom(this.prop === "width" || this.prop === "height" ? 1 : 0, this.cur());
        c(this.elem).show()
    },hide:function() {
        this.options.orig[this.prop] = c.style(this.elem, this.prop);
        this.options.hide = true;
        this.custom(this.cur(), 0)
    },step:function(a) {
        var b = J(),d = true;
        if (a || b >= this.options.duration + this.startTime) {
            this.now =
                    this.end;
            this.pos = this.state = 1;
            this.update();
            this.options.curAnim[this.prop] = true;
            for (var f in this.options.curAnim)if (this.options.curAnim[f] !== true)d = false;
            if (d) {
                if (this.options.display != null) {
                    this.elem.style.overflow = this.options.overflow;
                    a = c.data(this.elem, "olddisplay");
                    this.elem.style.display = a ? a : this.options.display;
                    if (c.css(this.elem, "display") === "none")this.elem.style.display = "block"
                }
                this.options.hide && c(this.elem).hide();
                if (this.options.hide || this.options.show)for (var e in this.options.curAnim)c.style(this.elem,
                        e, this.options.orig[e]);
                this.options.complete.call(this.elem)
            }
            return false
        } else {
            e = b - this.startTime;
            this.state = e / this.options.duration;
            a = this.options.easing || (c.easing.swing ? "swing" : "linear");
            this.pos = c.easing[this.options.specialEasing && this.options.specialEasing[this.prop] || a](this.state, e, 0, 1, this.options.duration);
            this.now = this.start + (this.end - this.start) * this.pos;
            this.update()
        }
        return true
    }};
    c.extend(c.fx, {tick:function() {
        for (var a = c.timers,b = 0; b < a.length; b++)a[b]() || a.splice(b--, 1);
        a.length ||
        c.fx.stop()
    },stop:function() {
        clearInterval(W);
        W = null
    },speeds:{slow:600,fast:200,_default:400},step:{opacity:function(a) {
        c.style(a.elem, "opacity", a.now)
    },_default:function(a) {
        if (a.elem.style && a.elem.style[a.prop] != null)a.elem.style[a.prop] = (a.prop === "width" || a.prop === "height" ? Math.max(0, a.now) : a.now) + a.unit; else a.elem[a.prop] = a.now
    }}});
    if (c.expr && c.expr.filters)c.expr.filters.animated = function(a) {
        return c.grep(c.timers,
                function(b) {
                    return a === b.elem
                }).length
    };
    c.fn.offset = "getBoundingClientRect"in s.documentElement ?
            function(a) {
                var b = this[0];
                if (a)return this.each(function(e) {
                    c.offset.setOffset(this, a, e)
                });
                if (!b || !b.ownerDocument)return null;
                if (b === b.ownerDocument.body)return c.offset.bodyOffset(b);
                var d = b.getBoundingClientRect(),f = b.ownerDocument;
                b = f.body;
                f = f.documentElement;
                return{top:d.top + (self.pageYOffset || c.support.boxModel && f.scrollTop || b.scrollTop) - (f.clientTop || b.clientTop || 0),left:d.left + (self.pageXOffset || c.support.boxModel && f.scrollLeft || b.scrollLeft) - (f.clientLeft || b.clientLeft || 0)}
            } : function(a) {
                var b =
                        this[0];
                if (a)return this.each(function(r) {
                    c.offset.setOffset(this, a, r)
                });
                if (!b || !b.ownerDocument)return null;
                if (b === b.ownerDocument.body)return c.offset.bodyOffset(b);
                c.offset.initialize();
                var d = b.offsetParent,f = b,e = b.ownerDocument,j,i = e.documentElement,o = e.body;
                f = (e = e.defaultView) ? e.getComputedStyle(b, null) : b.currentStyle;
                for (var k = b.offsetTop,n = b.offsetLeft; (b = b.parentNode) && b !== o && b !== i;) {
                    if (c.offset.supportsFixedPosition && f.position === "fixed")break;
                    j = e ? e.getComputedStyle(b, null) : b.currentStyle;
                    k -= b.scrollTop;
                    n -= b.scrollLeft;
                    if (b === d) {
                        k += b.offsetTop;
                        n += b.offsetLeft;
                        if (c.offset.doesNotAddBorder && !(c.offset.doesAddBorderForTableAndCells && /^t(able|d|h)$/i.test(b.nodeName))) {
                            k += parseFloat(j.borderTopWidth) || 0;
                            n += parseFloat(j.borderLeftWidth) || 0
                        }
                        f = d;
                        d = b.offsetParent
                    }
                    if (c.offset.subtractsBorderForOverflowNotVisible && j.overflow !== "visible") {
                        k += parseFloat(j.borderTopWidth) || 0;
                        n += parseFloat(j.borderLeftWidth) || 0
                    }
                    f = j
                }
                if (f.position === "relative" || f.position === "static") {
                    k += o.offsetTop;
                    n += o.offsetLeft
                }
                if (c.offset.supportsFixedPosition &&
                        f.position === "fixed") {
                    k += Math.max(i.scrollTop, o.scrollTop);
                    n += Math.max(i.scrollLeft, o.scrollLeft)
                }
                return{top:k,left:n}
            };
    c.offset = {initialize:function() {
        var a = s.body,b = s.createElement("div"),d,f,e,j = parseFloat(c.curCSS(a, "marginTop", true)) || 0;
        c.extend(b.style, {position:"absolute",top:0,left:0,margin:0,border:0,width:"1px",height:"1px",visibility:"hidden"});
        b.innerHTML = "<div style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;'><div></div></div><table style='position:absolute;top:0;left:0;margin:0;border:5px solid #000;padding:0;width:1px;height:1px;' cellpadding='0' cellspacing='0'><tr><td></td></tr></table>";
        a.insertBefore(b, a.firstChild);
        d = b.firstChild;
        f = d.firstChild;
        e = d.nextSibling.firstChild.firstChild;
        this.doesNotAddBorder = f.offsetTop !== 5;
        this.doesAddBorderForTableAndCells = e.offsetTop === 5;
        f.style.position = "fixed";
        f.style.top = "20px";
        this.supportsFixedPosition = f.offsetTop === 20 || f.offsetTop === 15;
        f.style.position = f.style.top = "";
        d.style.overflow = "hidden";
        d.style.position = "relative";
        this.subtractsBorderForOverflowNotVisible = f.offsetTop === -5;
        this.doesNotIncludeMarginInBodyOffset = a.offsetTop !== j;
        a.removeChild(b);
        c.offset.initialize = c.noop
    },bodyOffset:function(a) {
        var b = a.offsetTop,d = a.offsetLeft;
        c.offset.initialize();
        if (c.offset.doesNotIncludeMarginInBodyOffset) {
            b += parseFloat(c.curCSS(a, "marginTop", true)) || 0;
            d += parseFloat(c.curCSS(a, "marginLeft", true)) || 0
        }
        return{top:b,left:d}
    },setOffset:function(a, b, d) {
        if (/static/.test(c.curCSS(a, "position")))a.style.position = "relative";
        var f = c(a),e = f.offset(),j = parseInt(c.curCSS(a, "top", true), 10) || 0,i = parseInt(c.curCSS(a, "left", true), 10) || 0;
        if (c.isFunction(b))b = b.call(a,
                d, e);
        d = {top:b.top - e.top + j,left:b.left - e.left + i};
        "using"in b ? b.using.call(a, d) : f.css(d)
    }};
    c.fn.extend({position:function() {
        if (!this[0])return null;
        var a = this[0],b = this.offsetParent(),d = this.offset(),f = /^body|html$/i.test(b[0].nodeName) ? {top:0,left:0} : b.offset();
        d.top -= parseFloat(c.curCSS(a, "marginTop", true)) || 0;
        d.left -= parseFloat(c.curCSS(a, "marginLeft", true)) || 0;
        f.top += parseFloat(c.curCSS(b[0], "borderTopWidth", true)) || 0;
        f.left += parseFloat(c.curCSS(b[0], "borderLeftWidth", true)) || 0;
        return{top:d.top -
                f.top,left:d.left - f.left}
    },offsetParent:function() {
        return this.map(function() {
            for (var a = this.offsetParent || s.body; a && !/^body|html$/i.test(a.nodeName) && c.css(a, "position") === "static";)a = a.offsetParent;
            return a
        })
    }});
    c.each(["Left","Top"], function(a, b) {
        var d = "scroll" + b;
        c.fn[d] = function(f) {
            var e = this[0],j;
            if (!e)return null;
            if (f !== w)return this.each(function() {
                if (j = wa(this))j.scrollTo(!a ? f : c(j).scrollLeft(), a ? f : c(j).scrollTop()); else this[d] = f
            }); else return(j = wa(e)) ? "pageXOffset"in j ? j[a ? "pageYOffset" :
                    "pageXOffset"] : c.support.boxModel && j.document.documentElement[d] || j.document.body[d] : e[d]
        }
    });
    c.each(["Height","Width"], function(a, b) {
        var d = b.toLowerCase();
        c.fn["inner" + b] = function() {
            return this[0] ? c.css(this[0], d, false, "padding") : null
        };
        c.fn["outer" + b] = function(f) {
            return this[0] ? c.css(this[0], d, false, f ? "margin" : "border") : null
        };
        c.fn[d] = function(f) {
            var e = this[0];
            if (!e)return f == null ? null : this;
            if (c.isFunction(f))return this.each(function(j) {
                var i = c(this);
                i[d](f.call(this, j, i[d]()))
            });
            return"scrollTo"in
                    e && e.document ? e.document.compatMode === "CSS1Compat" && e.document.documentElement["client" + b] || e.document.body["client" + b] : e.nodeType === 9 ? Math.max(e.documentElement["client" + b], e.body["scroll" + b], e.documentElement["scroll" + b], e.body["offset" + b], e.documentElement["offset" + b]) : f === w ? c.css(e, d) : this.css(d, typeof f === "string" ? f : f + "px")
        }
    });
    A.jQuery = A.$ = c
})(window);


jQuery(function ($) {
    var csrf_token = $('meta[name=csrf-token]').attr('content'),
            csrf_param = $('meta[name=csrf-param]').attr('content');

    $.fn.extend({
        /**
         * Triggers a custom event on an element and returns the event result
         * this is used to get around not being able to ensure callbacks are placed
         * at the end of the chain.
         *
         * TODO: deprecate with jQuery 1.4.2 release, in favor of subscribing to our
         *       own events and placing ourselves at the end of the chain.
         */
        triggerAndReturn: function (name, data) {
            var event = new $.Event(name);
            this.trigger(event, data);

            return event.result !== false;
        },

        /**
         * Handles execution of remote calls firing overridable events along the way
         */
        callRemote: function () {
            var el = this,
                    method = el.attr('method') || el.attr('data-method') || 'GET',
                    url = el.attr('action') || el.attr('href'),
                    dataType = el.attr('data-type') || 'script';

            if (url === undefined) {
                throw "No URL specified for remote call (action or href must be present).";
            } else {
                if (el.triggerAndReturn('ajax:before')) {
                    var data = el.is('form') ? el.serializeArray() : [];
                    $.ajax({
                        url: url,
                        data: data,
                        dataType: dataType,
                        type: method.toUpperCase(),
                        beforeSend: function (xhr) {
                            el.trigger('ajax:loading', xhr);
                        },
                        success: function (data, status, xhr) {
                            el.trigger('ajax:success', [data, status, xhr]);
                        },
                        complete: function (xhr) {
                            el.trigger('ajax:complete', xhr);
                        },
                        error: function (xhr, status, error) {
                            el.trigger('ajax:failure', [xhr, status, error]);
                        }
                    });
                }

                el.trigger('ajax:after');
            }
        }
    });

    /**
     *  confirmation handler
     */
    $('a[data-confirm],input[data-confirm]').live('click', function () {
        var el = $(this);
        if (el.triggerAndReturn('confirm')) {
            if (!confirm(el.attr('data-confirm'))) {
                return false;
            }
        }
    });


    /**
     * remote handlers
     */
    $('form[data-remote]').live('submit', function (e) {
        $(this).callRemote();
        e.preventDefault();
    });

    $('a[data-remote],input[data-remote]').live('click', function (e) {
        $(this).callRemote();
        e.preventDefault();
    });

    $('a[data-method]:not([data-remote])').live('click', function (e) {
        var link = $(this),
                href = link.attr('href'),
                method = link.attr('data-method'),
                form = $('<form method="post" action="' + href + '"></form>'),
                metadata_input = '<input name="_method" value="' + method + '" type="hidden" />';

        if (csrf_param != null && csrf_token != null) {
            metadata_input += '<input name="' + csrf_param + '" value="' + csrf_token + '" type="hidden" />';
        }

        form.hide()
                .append(metadata_input)
                .appendTo('body');

        e.preventDefault();
        form.submit();
    });

    /**
     * disable-with handlers
     */
    var disable_with_input_selector = 'input[data-disable-with]';
    var disable_with_form_selector = 'form[data-remote]:has(' + disable_with_input_selector + ')';

    $(disable_with_form_selector).live('ajax:before', function () {
        $(this).find(disable_with_input_selector).each(function () {
            var input = $(this);
            input.data('enable-with', input.val())
                    .attr('value', input.attr('data-disable-with'))
                    .attr('disabled', 'disabled');
        });
    });

    $(disable_with_form_selector).live('ajax:complete', function () {
        $(this).find(disable_with_input_selector).each(function () {
            var input = $(this);
            input.removeAttr('disabled')
                    .val(input.data('enable-with'));
        });
    });
});


/*
 * jQuery UI 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI
 */
jQuery.ui || (function(c) {
    var i = c.fn.remove,d = c.browser.mozilla && (parseFloat(c.browser.version) < 1.9);
    c.ui = {version:"1.7.2",plugin:{add:function(k, l, n) {
        var m = c.ui[k].prototype;
        for (var j in n) {
            m.plugins[j] = m.plugins[j] || [];
            m.plugins[j].push([l,n[j]])
        }
    },call:function(j, l, k) {
        var n = j.plugins[l];
        if (!n || !j.element[0].parentNode) {
            return
        }
        for (var m = 0; m < n.length; m++) {
            if (j.options[n[m][0]]) {
                n[m][1].apply(j.element, k)
            }
        }
    }},contains:function(k, j) {
        return document.compareDocumentPosition ? k.compareDocumentPosition(j) & 16 : k !== j && k.contains(j)
    },hasScroll:function(m, k) {
        if (c(m).css("overflow") == "hidden") {
            return false
        }
        var j = (k && k == "left") ? "scrollLeft" : "scrollTop",l = false;
        if (m[j] > 0) {
            return true
        }
        m[j] = 1;
        l = (m[j] > 0);
        m[j] = 0;
        return l
    },isOverAxis:function(k, j, l) {
        return(k > j) && (k < (j + l))
    },isOver:function(o, k, n, m, j, l) {
        return c.ui.isOverAxis(o, n, j) && c.ui.isOverAxis(k, m, l)
    },keyCode:{BACKSPACE:8,CAPS_LOCK:20,COMMA:188,CONTROL:17,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,INSERT:45,LEFT:37,NUMPAD_ADD:107,NUMPAD_DECIMAL:110,NUMPAD_DIVIDE:111,NUMPAD_ENTER:108,NUMPAD_MULTIPLY:106,NUMPAD_SUBTRACT:109,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SHIFT:16,SPACE:32,TAB:9,UP:38}};
    if (d) {
        var f = c.attr,e = c.fn.removeAttr,h = "http://www.w3.org/2005/07/aaa",a = /^aria-/,b = /^wairole:/;
        c.attr = function(k, j, l) {
            var m = l !== undefined;
            return(j == "role" ? (m ? f.call(this, k, j, "wairole:" + l) : (f.apply(this, arguments) || "").replace(b, "")) : (a.test(j) ? (m ? k.setAttributeNS(h, j.replace(a, "aaa:"), l) : f.call(this, k, j.replace(a, "aaa:"))) : f.apply(this, arguments)))
        };
        c.fn.removeAttr = function(j) {
            return(a.test(j) ? this.each(function() {
                this.removeAttributeNS(h, j.replace(a, ""))
            }) : e.call(this, j))
        }
    }
    c.fn.extend({remove:function() {
        c("*", this).add(this).each(function() {
            c(this).triggerHandler("remove")
        });
        return i.apply(this, arguments)
    },enableSelection:function() {
        return this.attr("unselectable", "off").css("MozUserSelect", "").unbind("selectstart.ui")
    },disableSelection:function() {
        return this.attr("unselectable", "on").css("MozUserSelect", "none").bind("selectstart.ui", function() {
            return false
        })
    },scrollParent:function() {
        var j;
        if ((c.browser.msie && (/(static|relative)/).test(this.css("position"))) || (/absolute/).test(this.css("position"))) {
            j = this.parents().filter(
                    function() {
                        return(/(relative|absolute|fixed)/).test(c.curCSS(this, "position", 1)) && (/(auto|scroll)/).test(c.curCSS(this, "overflow", 1) + c.curCSS(this, "overflow-y", 1) + c.curCSS(this, "overflow-x", 1))
                    }).eq(0)
        } else {
            j = this.parents().filter(
                    function() {
                        return(/(auto|scroll)/).test(c.curCSS(this, "overflow", 1) + c.curCSS(this, "overflow-y", 1) + c.curCSS(this, "overflow-x", 1))
                    }).eq(0)
        }
        return(/fixed/).test(this.css("position")) || !j.length ? c(document) : j
    }});
    c.extend(c.expr[":"], {data:function(l, k, j) {
        return !!c.data(l, j[3])
    },focusable:function(k) {
        var l = k.nodeName.toLowerCase(),j = c.attr(k, "tabindex");
        return(/input|select|textarea|button|object/.test(l) ? !k.disabled : "a" == l || "area" == l ? k.href || !isNaN(j) : !isNaN(j)) && !c(k)["area" == l ? "parents" : "closest"](":hidden").length
    },tabbable:function(k) {
        var j = c.attr(k, "tabindex");
        return(isNaN(j) || j >= 0) && c(k).is(":focusable")
    }});
    function g(m, n, o, l) {
        function k(q) {
            var p = c[m][n][q] || [];
            return(typeof p == "string" ? p.split(/,?\s+/) : p)
        }

        var j = k("getter");
        if (l.length == 1 && typeof l[0] == "string") {
            j = j.concat(k("getterSetter"))
        }
        return(c.inArray(o, j) != -1)
    }

    c.widget = function(k, j) {
        var l = k.split(".")[0];
        k = k.split(".")[1];
        c.fn[k] = function(p) {
            var n = (typeof p == "string"),o = Array.prototype.slice.call(arguments, 1);
            if (n && p.substring(0, 1) == "_") {
                return this
            }
            if (n && g(l, k, p, o)) {
                var m = c.data(this[0], k);
                return(m ? m[p].apply(m, o) : undefined)
            }
            return this.each(function() {
                var q = c.data(this, k);
                (!q && !n && c.data(this, k, new c[l][k](this, p))._init());
                (q && n && c.isFunction(q[p]) && q[p].apply(q, o))
            })
        };
        c[l] = c[l] || {};
        c[l][k] = function(o, n) {
            var m = this;
            this.namespace = l;
            this.widgetName = k;
            this.widgetEventPrefix = c[l][k].eventPrefix || k;
            this.widgetBaseClass = l + "-" + k;
            this.options = c.extend({}, c.widget.defaults, c[l][k].defaults, c.metadata && c.metadata.get(o)[k], n);
            this.element = c(o).bind("setData." + k,
                    function(q, p, r) {
                        if (q.target == o) {
                            return m._setData(p, r)
                        }
                    }).bind("getData." + k,
                    function(q, p) {
                        if (q.target == o) {
                            return m._getData(p)
                        }
                    }).bind("remove", function() {
                return m.destroy()
            })
        };
        c[l][k].prototype = c.extend({}, c.widget.prototype, j);
        c[l][k].getterSetter = "option"
    };
    c.widget.prototype = {_init:function() {
    },destroy:function() {
        this.element.removeData(this.widgetName).removeClass(this.widgetBaseClass + "-disabled " + this.namespace + "-state-disabled").removeAttr("aria-disabled")
    },option:function(l, m) {
        var k = l,j = this;
        if (typeof l == "string") {
            if (m === undefined) {
                return this._getData(l)
            }
            k = {};
            k[l] = m
        }
        c.each(k, function(n, o) {
            j._setData(n, o)
        })
    },_getData:function(j) {
        return this.options[j]
    },_setData:function(j, k) {
        this.options[j] = k;
        if (j == "disabled") {
            this.element[k ? "addClass" : "removeClass"](this.widgetBaseClass + "-disabled " + this.namespace + "-state-disabled").attr("aria-disabled", k)
        }
    },enable:function() {
        this._setData("disabled", false)
    },disable:function() {
        this._setData("disabled", true)
    },_trigger:function(l, m, n) {
        var p = this.options[l],j = (l == this.widgetEventPrefix ? l : this.widgetEventPrefix + l);
        m = c.Event(m);
        m.type = j;
        if (m.originalEvent) {
            for (var k = c.event.props.length,o; k;) {
                o = c.event.props[--k];
                m[o] = m.originalEvent[o]
            }
        }
        this.element.trigger(m, n);
        return !(c.isFunction(p) && p.call(this.element[0], m, n) === false || m.isDefaultPrevented())
    }};
    c.widget.defaults = {disabled:false};
    c.ui.mouse = {_mouseInit:function() {
        var j = this;
        this.element.bind("mousedown." + this.widgetName,
                function(k) {
                    return j._mouseDown(k)
                }).bind("click." + this.widgetName, function(k) {
            if (j._preventClickEvent) {
                j._preventClickEvent = false;
                k.stopImmediatePropagation();
                return false
            }
        });
        if (c.browser.msie) {
            this._mouseUnselectable = this.element.attr("unselectable");
            this.element.attr("unselectable", "on")
        }
        this.started = false
    },_mouseDestroy:function() {
        this.element.unbind("." + this.widgetName);
        (c.browser.msie && this.element.attr("unselectable", this._mouseUnselectable))
    },_mouseDown:function(l) {
        l.originalEvent = l.originalEvent || {};
        if (l.originalEvent.mouseHandled) {
            return
        }
        (this._mouseStarted && this._mouseUp(l));
        this._mouseDownEvent = l;
        var k = this,m = (l.which == 1),j = (typeof this.options.cancel == "string" ? c(l.target).parents().add(l.target).filter(this.options.cancel).length : false);
        if (!m || j || !this._mouseCapture(l)) {
            return true
        }
        this.mouseDelayMet = !this.options.delay;
        if (!this.mouseDelayMet) {
            this._mouseDelayTimer = setTimeout(function() {
                k.mouseDelayMet = true
            }, this.options.delay)
        }
        if (this._mouseDistanceMet(l) && this._mouseDelayMet(l)) {
            this._mouseStarted = (this._mouseStart(l) !== false);
            if (!this._mouseStarted) {
                l.preventDefault();
                return true
            }
        }
        this._mouseMoveDelegate = function(n) {
            return k._mouseMove(n)
        };
        this._mouseUpDelegate = function(n) {
            return k._mouseUp(n)
        };
        c(document).bind("mousemove." + this.widgetName, this._mouseMoveDelegate).bind("mouseup." + this.widgetName, this._mouseUpDelegate);
        (c.browser.safari || l.preventDefault());
        l.originalEvent.mouseHandled = true;
        return true
    },_mouseMove:function(j) {
        if (c.browser.msie && !j.button) {
            return this._mouseUp(j)
        }
        if (this._mouseStarted) {
            this._mouseDrag(j);
            return j.preventDefault()
        }
        if (this._mouseDistanceMet(j) && this._mouseDelayMet(j)) {
            this._mouseStarted = (this._mouseStart(this._mouseDownEvent, j) !== false);
            (this._mouseStarted ? this._mouseDrag(j) : this._mouseUp(j))
        }
        return !this._mouseStarted
    },_mouseUp:function(j) {
        c(document).unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate);
        if (this._mouseStarted) {
            this._mouseStarted = false;
            this._preventClickEvent = (j.target == this._mouseDownEvent.target);
            this._mouseStop(j)
        }
        return false
    },_mouseDistanceMet:function(j) {
        return(Math.max(Math.abs(this._mouseDownEvent.pageX - j.pageX), Math.abs(this._mouseDownEvent.pageY - j.pageY)) >= this.options.distance)
    },_mouseDelayMet:function(j) {
        return this.mouseDelayMet
    },_mouseStart:function(j) {
    },_mouseDrag:function(j) {
    },_mouseStop:function(j) {
    },_mouseCapture:function(j) {
        return true
    }};
    c.ui.mouse.defaults = {cancel:null,distance:1,delay:0}
})(jQuery);
;
/*
 * jQuery UI Draggable 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Draggables
 *
 * Depends:
 *	ui.core.js
 */
(function(a) {
    a.widget("ui.draggable", a.extend({}, a.ui.mouse, {_init:function() {
        if (this.options.helper == "original" && !(/^(?:r|a|f)/).test(this.element.css("position"))) {
            this.element[0].style.position = "relative"
        }
        (this.options.addClasses && this.element.addClass("ui-draggable"));
        (this.options.disabled && this.element.addClass("ui-draggable-disabled"));
        this._mouseInit()
    },destroy:function() {
        if (!this.element.data("draggable")) {
            return
        }
        this.element.removeData("draggable").unbind(".draggable").removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled");
        this._mouseDestroy()
    },_mouseCapture:function(b) {
        var c = this.options;
        if (this.helper || c.disabled || a(b.target).is(".ui-resizable-handle")) {
            return false
        }
        this.handle = this._getHandle(b);
        if (!this.handle) {
            return false
        }
        return true
    },_mouseStart:function(b) {
        var c = this.options;
        this.helper = this._createHelper(b);
        this._cacheHelperProportions();
        if (a.ui.ddmanager) {
            a.ui.ddmanager.current = this
        }
        this._cacheMargins();
        this.cssPosition = this.helper.css("position");
        this.scrollParent = this.helper.scrollParent();
        this.offset = this.element.offset();
        this.offset = {top:this.offset.top - this.margins.top,left:this.offset.left - this.margins.left};
        a.extend(this.offset, {click:{left:b.pageX - this.offset.left,top:b.pageY - this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()});
        this.originalPosition = this._generatePosition(b);
        this.originalPageX = b.pageX;
        this.originalPageY = b.pageY;
        if (c.cursorAt) {
            this._adjustOffsetFromHelper(c.cursorAt)
        }
        if (c.containment) {
            this._setContainment()
        }
        this._trigger("start", b);
        this._cacheHelperProportions();
        if (a.ui.ddmanager && !c.dropBehaviour) {
            a.ui.ddmanager.prepareOffsets(this, b)
        }
        this.helper.addClass("ui-draggable-dragging");
        this._mouseDrag(b, true);
        return true
    },_mouseDrag:function(b, d) {
        this.position = this._generatePosition(b);
        this.positionAbs = this._convertPositionTo("absolute");
        if (!d) {
            var c = this._uiHash();
            this._trigger("drag", b, c);
            this.position = c.position
        }
        if (!this.options.axis || this.options.axis != "y") {
            this.helper[0].style.left = this.position.left + "px"
        }
        if (!this.options.axis || this.options.axis != "x") {
            this.helper[0].style.top = this.position.top + "px"
        }
        if (a.ui.ddmanager) {
            a.ui.ddmanager.drag(this, b)
        }
        return false
    },_mouseStop:function(c) {
        var d = false;
        if (a.ui.ddmanager && !this.options.dropBehaviour) {
            d = a.ui.ddmanager.drop(this, c)
        }
        if (this.dropped) {
            d = this.dropped;
            this.dropped = false
        }
        if ((this.options.revert == "invalid" && !d) || (this.options.revert == "valid" && d) || this.options.revert === true || (a.isFunction(this.options.revert) && this.options.revert.call(this.element, d))) {
            var b = this;
            a(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
                b._trigger("stop", c);
                b._clear()
            })
        } else {
            this._trigger("stop", c);
            this._clear()
        }
        return false
    },_getHandle:function(b) {
        var c = !this.options.handle || !a(this.options.handle, this.element).length ? true : false;
        a(this.options.handle, this.element).find("*").andSelf().each(function() {
            if (this == b.target) {
                c = true
            }
        });
        return c
    },_createHelper:function(c) {
        var d = this.options;
        var b = a.isFunction(d.helper) ? a(d.helper.apply(this.element[0], [c])) : (d.helper == "clone" ? this.element.clone() : this.element);
        if (!b.parents("body").length) {
            b.appendTo((d.appendTo == "parent" ? this.element[0].parentNode : d.appendTo))
        }
        if (b[0] != this.element[0] && !(/(fixed|absolute)/).test(b.css("position"))) {
            b.css("position", "absolute")
        }
        return b
    },_adjustOffsetFromHelper:function(b) {
        if (b.left != undefined) {
            this.offset.click.left = b.left + this.margins.left
        }
        if (b.right != undefined) {
            this.offset.click.left = this.helperProportions.width - b.right + this.margins.left
        }
        if (b.top != undefined) {
            this.offset.click.top = b.top + this.margins.top
        }
        if (b.bottom != undefined) {
            this.offset.click.top = this.helperProportions.height - b.bottom + this.margins.top
        }
    },_getParentOffset:function() {
        this.offsetParent = this.helper.offsetParent();
        var b = this.offsetParent.offset();
        if (this.cssPosition == "absolute" && this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) {
            b.left += this.scrollParent.scrollLeft();
            b.top += this.scrollParent.scrollTop()
        }
        if ((this.offsetParent[0] == document.body) || (this.offsetParent[0].tagName && this.offsetParent[0].tagName.toLowerCase() == "html" && a.browser.msie)) {
            b = {top:0,left:0}
        }
        return{top:b.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),left:b.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)}
    },_getRelativeOffset:function() {
        if (this.cssPosition == "relative") {
            var b = this.element.position();
            return{top:b.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),left:b.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()}
        } else {
            return{top:0,left:0}
        }
    },_cacheMargins:function() {
        this.margins = {left:(parseInt(this.element.css("marginLeft"), 10) || 0),top:(parseInt(this.element.css("marginTop"), 10) || 0)}
    },_cacheHelperProportions:function() {
        this.helperProportions = {width:this.helper.outerWidth(),height:this.helper.outerHeight()}
    },_setContainment:function() {
        var e = this.options;
        if (e.containment == "parent") {
            e.containment = this.helper[0].parentNode
        }
        if (e.containment == "document" || e.containment == "window") {
            this.containment = [0 - this.offset.relative.left - this.offset.parent.left,0 - this.offset.relative.top - this.offset.parent.top,a(e.containment == "document" ? document : window).width() - this.helperProportions.width - this.margins.left,(a(e.containment == "document" ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]
        }
        if (!(/^(document|window|parent)$/).test(e.containment) && e.containment.constructor != Array) {
            var c = a(e.containment)[0];
            if (!c) {
                return
            }
            var d = a(e.containment).offset();
            var b = (a(c).css("overflow") != "hidden");
            this.containment = [d.left + (parseInt(a(c).css("borderLeftWidth"), 10) || 0) + (parseInt(a(c).css("paddingLeft"), 10) || 0) - this.margins.left,d.top + (parseInt(a(c).css("borderTopWidth"), 10) || 0) + (parseInt(a(c).css("paddingTop"), 10) || 0) - this.margins.top,d.left + (b ? Math.max(c.scrollWidth, c.offsetWidth) : c.offsetWidth) - (parseInt(a(c).css("borderLeftWidth"), 10) || 0) - (parseInt(a(c).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left,d.top + (b ? Math.max(c.scrollHeight, c.offsetHeight) : c.offsetHeight) - (parseInt(a(c).css("borderTopWidth"), 10) || 0) - (parseInt(a(c).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top]
        } else {
            if (e.containment.constructor == Array) {
                this.containment = e.containment
            }
        }
    },_convertPositionTo:function(f, h) {
        if (!h) {
            h = this.position
        }
        var c = f == "absolute" ? 1 : -1;
        var e = this.options,b = this.cssPosition == "absolute" && !(this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) ? this.offsetParent : this.scrollParent,g = (/(html|body)/i).test(b[0].tagName);
        return{top:(h.top + this.offset.relative.top * c + this.offset.parent.top * c - (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollTop() : (g ? 0 : b.scrollTop())) * c)),left:(h.left + this.offset.relative.left * c + this.offset.parent.left * c - (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollLeft() : g ? 0 : b.scrollLeft()) * c))}
    },_generatePosition:function(e) {
        var h = this.options,b = this.cssPosition == "absolute" && !(this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) ? this.offsetParent : this.scrollParent,i = (/(html|body)/i).test(b[0].tagName);
        if (this.cssPosition == "relative" && !(this.scrollParent[0] != document && this.scrollParent[0] != this.offsetParent[0])) {
            this.offset.relative = this._getRelativeOffset()
        }
        var d = e.pageX;
        var c = e.pageY;
        if (this.originalPosition) {
            if (this.containment) {
                if (e.pageX - this.offset.click.left < this.containment[0]) {
                    d = this.containment[0] + this.offset.click.left
                }
                if (e.pageY - this.offset.click.top < this.containment[1]) {
                    c = this.containment[1] + this.offset.click.top
                }
                if (e.pageX - this.offset.click.left > this.containment[2]) {
                    d = this.containment[2] + this.offset.click.left
                }
                if (e.pageY - this.offset.click.top > this.containment[3]) {
                    c = this.containment[3] + this.offset.click.top
                }
            }
            if (h.grid) {
                var g = this.originalPageY + Math.round((c - this.originalPageY) / h.grid[1]) * h.grid[1];
                c = this.containment ? (!(g - this.offset.click.top < this.containment[1] || g - this.offset.click.top > this.containment[3]) ? g : (!(g - this.offset.click.top < this.containment[1]) ? g - h.grid[1] : g + h.grid[1])) : g;
                var f = this.originalPageX + Math.round((d - this.originalPageX) / h.grid[0]) * h.grid[0];
                d = this.containment ? (!(f - this.offset.click.left < this.containment[0] || f - this.offset.click.left > this.containment[2]) ? f : (!(f - this.offset.click.left < this.containment[0]) ? f - h.grid[0] : f + h.grid[0])) : f
            }
        }
        return{top:(c - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollTop() : (i ? 0 : b.scrollTop())))),left:(d - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollLeft() : i ? 0 : b.scrollLeft())))}
    },_clear:function() {
        this.helper.removeClass("ui-draggable-dragging");
        if (this.helper[0] != this.element[0] && !this.cancelHelperRemoval) {
            this.helper.remove()
        }
        this.helper = null;
        this.cancelHelperRemoval = false
    },_trigger:function(b, c, d) {
        d = d || this._uiHash();
        a.ui.plugin.call(this, b, [c,d]);
        if (b == "drag") {
            this.positionAbs = this._convertPositionTo("absolute")
        }
        return a.widget.prototype._trigger.call(this, b, c, d)
    },plugins:{},_uiHash:function(b) {
        return{helper:this.helper,position:this.position,absolutePosition:this.positionAbs,offset:this.positionAbs}
    }}));
    a.extend(a.ui.draggable, {version:"1.7.2",eventPrefix:"drag",defaults:{addClasses:true,appendTo:"parent",axis:false,cancel:":input,option",connectToSortable:false,containment:false,cursor:"auto",cursorAt:false,delay:0,distance:1,grid:false,handle:false,helper:"original",iframeFix:false,opacity:false,refreshPositions:false,revert:false,revertDuration:500,scope:"default",scroll:true,scrollSensitivity:20,scrollSpeed:20,snap:false,snapMode:"both",snapTolerance:20,stack:false,zIndex:false}});
    a.ui.plugin.add("draggable", "connectToSortable", {start:function(c, e) {
        var d = a(this).data("draggable"),f = d.options,b = a.extend({}, e, {item:d.element});
        d.sortables = [];
        a(f.connectToSortable).each(function() {
            var g = a.data(this, "sortable");
            if (g && !g.options.disabled) {
                d.sortables.push({instance:g,shouldRevert:g.options.revert});
                g._refreshItems();
                g._trigger("activate", c, b)
            }
        })
    },stop:function(c, e) {
        var d = a(this).data("draggable"),b = a.extend({}, e, {item:d.element});
        a.each(d.sortables, function() {
            if (this.instance.isOver) {
                this.instance.isOver = 0;
                d.cancelHelperRemoval = true;
                this.instance.cancelHelperRemoval = false;
                if (this.shouldRevert) {
                    this.instance.options.revert = true
                }
                this.instance._mouseStop(c);
                this.instance.options.helper = this.instance.options._helper;
                if (d.options.helper == "original") {
                    this.instance.currentItem.css({top:"auto",left:"auto"})
                }
            } else {
                this.instance.cancelHelperRemoval = false;
                this.instance._trigger("deactivate", c, b)
            }
        })
    },drag:function(c, f) {
        var e = a(this).data("draggable"),b = this;
        var d = function(i) {
            var n = this.offset.click.top,m = this.offset.click.left;
            var g = this.positionAbs.top,k = this.positionAbs.left;
            var j = i.height,l = i.width;
            var p = i.top,h = i.left;
            return a.ui.isOver(g + n, k + m, p, h, j, l)
        };
        a.each(e.sortables, function(g) {
            this.instance.positionAbs = e.positionAbs;
            this.instance.helperProportions = e.helperProportions;
            this.instance.offset.click = e.offset.click;
            if (this.instance._intersectsWith(this.instance.containerCache)) {
                if (!this.instance.isOver) {
                    this.instance.isOver = 1;
                    this.instance.currentItem = a(b).clone().appendTo(this.instance.element).data("sortable-item", true);
                    this.instance.options._helper = this.instance.options.helper;
                    this.instance.options.helper = function() {
                        return f.helper[0]
                    };
                    c.target = this.instance.currentItem[0];
                    this.instance._mouseCapture(c, true);
                    this.instance._mouseStart(c, true, true);
                    this.instance.offset.click.top = e.offset.click.top;
                    this.instance.offset.click.left = e.offset.click.left;
                    this.instance.offset.parent.left -= e.offset.parent.left - this.instance.offset.parent.left;
                    this.instance.offset.parent.top -= e.offset.parent.top - this.instance.offset.parent.top;
                    e._trigger("toSortable", c);
                    e.dropped = this.instance.element;
                    e.currentItem = e.element;
                    this.instance.fromOutside = e
                }
                if (this.instance.currentItem) {
                    this.instance._mouseDrag(c)
                }
            } else {
                if (this.instance.isOver) {
                    this.instance.isOver = 0;
                    this.instance.cancelHelperRemoval = true;
                    this.instance.options.revert = false;
                    this.instance._trigger("out", c, this.instance._uiHash(this.instance));
                    this.instance._mouseStop(c, true);
                    this.instance.options.helper = this.instance.options._helper;
                    this.instance.currentItem.remove();
                    if (this.instance.placeholder) {
                        this.instance.placeholder.remove()
                    }
                    e._trigger("fromSortable", c);
                    e.dropped = false
                }
            }
        })
    }});
    a.ui.plugin.add("draggable", "cursor", {start:function(c, d) {
        var b = a("body"),e = a(this).data("draggable").options;
        if (b.css("cursor")) {
            e._cursor = b.css("cursor")
        }
        b.css("cursor", e.cursor)
    },stop:function(b, c) {
        var d = a(this).data("draggable").options;
        if (d._cursor) {
            a("body").css("cursor", d._cursor)
        }
    }});
    a.ui.plugin.add("draggable", "iframeFix", {start:function(b, c) {
        var d = a(this).data("draggable").options;
        a(d.iframeFix === true ? "iframe" : d.iframeFix).each(function() {
            a('<div class="ui-draggable-iframeFix" style="background: #fff;"></div>').css({width:this.offsetWidth + "px",height:this.offsetHeight + "px",position:"absolute",opacity:"0.001",zIndex:1000}).css(a(this).offset()).appendTo("body")
        })
    },stop:function(b, c) {
        a("div.ui-draggable-iframeFix").each(function() {
            this.parentNode.removeChild(this)
        })
    }});
    a.ui.plugin.add("draggable", "opacity", {start:function(c, d) {
        var b = a(d.helper),e = a(this).data("draggable").options;
        if (b.css("opacity")) {
            e._opacity = b.css("opacity")
        }
        b.css("opacity", e.opacity)
    },stop:function(b, c) {
        var d = a(this).data("draggable").options;
        if (d._opacity) {
            a(c.helper).css("opacity", d._opacity)
        }
    }});
    a.ui.plugin.add("draggable", "scroll", {start:function(c, d) {
        var b = a(this).data("draggable");
        if (b.scrollParent[0] != document && b.scrollParent[0].tagName != "HTML") {
            b.overflowOffset = b.scrollParent.offset()
        }
    },drag:function(d, e) {
        var c = a(this).data("draggable"),f = c.options,b = false;
        if (c.scrollParent[0] != document && c.scrollParent[0].tagName != "HTML") {
            if (!f.axis || f.axis != "x") {
                if ((c.overflowOffset.top + c.scrollParent[0].offsetHeight) - d.pageY < f.scrollSensitivity) {
                    c.scrollParent[0].scrollTop = b = c.scrollParent[0].scrollTop + f.scrollSpeed
                } else {
                    if (d.pageY - c.overflowOffset.top < f.scrollSensitivity) {
                        c.scrollParent[0].scrollTop = b = c.scrollParent[0].scrollTop - f.scrollSpeed
                    }
                }
            }
            if (!f.axis || f.axis != "y") {
                if ((c.overflowOffset.left + c.scrollParent[0].offsetWidth) - d.pageX < f.scrollSensitivity) {
                    c.scrollParent[0].scrollLeft = b = c.scrollParent[0].scrollLeft + f.scrollSpeed
                } else {
                    if (d.pageX - c.overflowOffset.left < f.scrollSensitivity) {
                        c.scrollParent[0].scrollLeft = b = c.scrollParent[0].scrollLeft - f.scrollSpeed
                    }
                }
            }
        } else {
            if (!f.axis || f.axis != "x") {
                if (d.pageY - a(document).scrollTop() < f.scrollSensitivity) {
                    b = a(document).scrollTop(a(document).scrollTop() - f.scrollSpeed)
                } else {
                    if (a(window).height() - (d.pageY - a(document).scrollTop()) < f.scrollSensitivity) {
                        b = a(document).scrollTop(a(document).scrollTop() + f.scrollSpeed)
                    }
                }
            }
            if (!f.axis || f.axis != "y") {
                if (d.pageX - a(document).scrollLeft() < f.scrollSensitivity) {
                    b = a(document).scrollLeft(a(document).scrollLeft() - f.scrollSpeed)
                } else {
                    if (a(window).width() - (d.pageX - a(document).scrollLeft()) < f.scrollSensitivity) {
                        b = a(document).scrollLeft(a(document).scrollLeft() + f.scrollSpeed)
                    }
                }
            }
        }
        if (b !== false && a.ui.ddmanager && !f.dropBehaviour) {
            a.ui.ddmanager.prepareOffsets(c, d)
        }
    }});
    a.ui.plugin.add("draggable", "snap", {start:function(c, d) {
        var b = a(this).data("draggable"),e = b.options;
        b.snapElements = [];
        a(e.snap.constructor != String ? (e.snap.items || ":data(draggable)") : e.snap).each(function() {
            var g = a(this);
            var f = g.offset();
            if (this != b.element[0]) {
                b.snapElements.push({item:this,width:g.outerWidth(),height:g.outerHeight(),top:f.top,left:f.left})
            }
        })
    },drag:function(u, p) {
        var g = a(this).data("draggable"),q = g.options;
        var y = q.snapTolerance;
        var x = p.offset.left,w = x + g.helperProportions.width,f = p.offset.top,e = f + g.helperProportions.height;
        for (var v = g.snapElements.length - 1; v >= 0; v--) {
            var s = g.snapElements[v].left,n = s + g.snapElements[v].width,m = g.snapElements[v].top,A = m + g.snapElements[v].height;
            if (!((s - y < x && x < n + y && m - y < f && f < A + y) || (s - y < x && x < n + y && m - y < e && e < A + y) || (s - y < w && w < n + y && m - y < f && f < A + y) || (s - y < w && w < n + y && m - y < e && e < A + y))) {
                if (g.snapElements[v].snapping) {
                    (g.options.snap.release && g.options.snap.release.call(g.element, u, a.extend(g._uiHash(), {snapItem:g.snapElements[v].item})))
                }
                g.snapElements[v].snapping = false;
                continue
            }
            if (q.snapMode != "inner") {
                var c = Math.abs(m - e) <= y;
                var z = Math.abs(A - f) <= y;
                var j = Math.abs(s - w) <= y;
                var k = Math.abs(n - x) <= y;
                if (c) {
                    p.position.top = g._convertPositionTo("relative", {top:m - g.helperProportions.height,left:0}).top - g.margins.top
                }
                if (z) {
                    p.position.top = g._convertPositionTo("relative", {top:A,left:0}).top - g.margins.top
                }
                if (j) {
                    p.position.left = g._convertPositionTo("relative", {top:0,left:s - g.helperProportions.width}).left - g.margins.left
                }
                if (k) {
                    p.position.left = g._convertPositionTo("relative", {top:0,left:n}).left - g.margins.left
                }
            }
            var h = (c || z || j || k);
            if (q.snapMode != "outer") {
                var c = Math.abs(m - f) <= y;
                var z = Math.abs(A - e) <= y;
                var j = Math.abs(s - x) <= y;
                var k = Math.abs(n - w) <= y;
                if (c) {
                    p.position.top = g._convertPositionTo("relative", {top:m,left:0}).top - g.margins.top
                }
                if (z) {
                    p.position.top = g._convertPositionTo("relative", {top:A - g.helperProportions.height,left:0}).top - g.margins.top
                }
                if (j) {
                    p.position.left = g._convertPositionTo("relative", {top:0,left:s}).left - g.margins.left
                }
                if (k) {
                    p.position.left = g._convertPositionTo("relative", {top:0,left:n - g.helperProportions.width}).left - g.margins.left
                }
            }
            if (!g.snapElements[v].snapping && (c || z || j || k || h)) {
                (g.options.snap.snap && g.options.snap.snap.call(g.element, u, a.extend(g._uiHash(), {snapItem:g.snapElements[v].item})))
            }
            g.snapElements[v].snapping = (c || z || j || k || h)
        }
    }});
    a.ui.plugin.add("draggable", "stack", {start:function(b, c) {
        var e = a(this).data("draggable").options;
        var d = a.makeArray(a(e.stack.group)).sort(function(g, f) {
            return(parseInt(a(g).css("zIndex"), 10) || e.stack.min) - (parseInt(a(f).css("zIndex"), 10) || e.stack.min)
        });
        a(d).each(function(f) {
            this.style.zIndex = e.stack.min + f
        });
        this[0].style.zIndex = e.stack.min + d.length
    }});
    a.ui.plugin.add("draggable", "zIndex", {start:function(c, d) {
        var b = a(d.helper),e = a(this).data("draggable").options;
        if (b.css("zIndex")) {
            e._zIndex = b.css("zIndex")
        }
        b.css("zIndex", e.zIndex)
    },stop:function(b, c) {
        var d = a(this).data("draggable").options;
        if (d._zIndex) {
            a(c.helper).css("zIndex", d._zIndex)
        }
    }})
})(jQuery);
;
/*
 * jQuery UI Droppable 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Droppables
 *
 * Depends:
 *	ui.core.js
 *	ui.draggable.js
 */
(function(a) {
    a.widget("ui.droppable", {_init:function() {
        var c = this.options,b = c.accept;
        this.isover = 0;
        this.isout = 1;
        this.options.accept = this.options.accept && a.isFunction(this.options.accept) ? this.options.accept : function(e) {
            return e.is(b)
        };
        this.proportions = {width:this.element[0].offsetWidth,height:this.element[0].offsetHeight};
        a.ui.ddmanager.droppables[this.options.scope] = a.ui.ddmanager.droppables[this.options.scope] || [];
        a.ui.ddmanager.droppables[this.options.scope].push(this);
        (this.options.addClasses && this.element.addClass("ui-droppable"))
    },destroy:function() {
        var b = a.ui.ddmanager.droppables[this.options.scope];
        for (var c = 0; c < b.length; c++) {
            if (b[c] == this) {
                b.splice(c, 1)
            }
        }
        this.element.removeClass("ui-droppable ui-droppable-disabled").removeData("droppable").unbind(".droppable")
    },_setData:function(b, c) {
        if (b == "accept") {
            this.options.accept = c && a.isFunction(c) ? c : function(e) {
                return e.is(c)
            }
        } else {
            a.widget.prototype._setData.apply(this, arguments)
        }
    },_activate:function(c) {
        var b = a.ui.ddmanager.current;
        if (this.options.activeClass) {
            this.element.addClass(this.options.activeClass)
        }
        (b && this._trigger("activate", c, this.ui(b)))
    },_deactivate:function(c) {
        var b = a.ui.ddmanager.current;
        if (this.options.activeClass) {
            this.element.removeClass(this.options.activeClass)
        }
        (b && this._trigger("deactivate", c, this.ui(b)))
    },_over:function(c) {
        var b = a.ui.ddmanager.current;
        if (!b || (b.currentItem || b.element)[0] == this.element[0]) {
            return
        }
        if (this.options.accept.call(this.element[0], (b.currentItem || b.element))) {
            if (this.options.hoverClass) {
                this.element.addClass(this.options.hoverClass)
            }
            this._trigger("over", c, this.ui(b))
        }
    },_out:function(c) {
        var b = a.ui.ddmanager.current;
        if (!b || (b.currentItem || b.element)[0] == this.element[0]) {
            return
        }
        if (this.options.accept.call(this.element[0], (b.currentItem || b.element))) {
            if (this.options.hoverClass) {
                this.element.removeClass(this.options.hoverClass)
            }
            this._trigger("out", c, this.ui(b))
        }
    },_drop:function(c, d) {
        var b = d || a.ui.ddmanager.current;
        if (!b || (b.currentItem || b.element)[0] == this.element[0]) {
            return false
        }
        var e = false;
        this.element.find(":data(droppable)").not(".ui-draggable-dragging").each(function() {
            var f = a.data(this, "droppable");
            if (f.options.greedy && a.ui.intersect(b, a.extend(f, {offset:f.element.offset()}), f.options.tolerance)) {
                e = true;
                return false
            }
        });
        if (e) {
            return false
        }
        if (this.options.accept.call(this.element[0], (b.currentItem || b.element))) {
            if (this.options.activeClass) {
                this.element.removeClass(this.options.activeClass)
            }
            if (this.options.hoverClass) {
                this.element.removeClass(this.options.hoverClass)
            }
            this._trigger("drop", c, this.ui(b));
            return this.element
        }
        return false
    },ui:function(b) {
        return{draggable:(b.currentItem || b.element),helper:b.helper,position:b.position,absolutePosition:b.positionAbs,offset:b.positionAbs}
    }});
    a.extend(a.ui.droppable, {version:"1.7.2",eventPrefix:"drop",defaults:{accept:"*",activeClass:false,addClasses:true,greedy:false,hoverClass:false,scope:"default",tolerance:"intersect"}});
    a.ui.intersect = function(q, j, o) {
        if (!j.offset) {
            return false
        }
        var e = (q.positionAbs || q.position.absolute).left,d = e + q.helperProportions.width,n = (q.positionAbs || q.position.absolute).top,m = n + q.helperProportions.height;
        var g = j.offset.left,c = g + j.proportions.width,p = j.offset.top,k = p + j.proportions.height;
        switch (o) {case"fit":return(g < e && d < c && p < n && m < k);break;case"intersect":return(g < e + (q.helperProportions.width / 2) && d - (q.helperProportions.width / 2) < c && p < n + (q.helperProportions.height / 2) && m - (q.helperProportions.height / 2) < k);break;case"pointer":var h = ((q.positionAbs || q.position.absolute).left + (q.clickOffset || q.offset.click).left),i = ((q.positionAbs || q.position.absolute).top + (q.clickOffset || q.offset.click).top),f = a.ui.isOver(i, h, p, g, j.proportions.height, j.proportions.width);return f;break;case"touch":return((n >= p && n <= k) || (m >= p && m <= k) || (n < p && m > k)) && ((e >= g && e <= c) || (d >= g && d <= c) || (e < g && d > c));break;default:return false;break
        }
    };
    a.ui.ddmanager = {current:null,droppables:{"default":[]},prepareOffsets:function(e, g) {
        var b = a.ui.ddmanager.droppables[e.options.scope];
        var f = g ? g.type : null;
        var h = (e.currentItem || e.element).find(":data(droppable)").andSelf();
        droppablesLoop:for (var d = 0; d < b.length; d++) {
            if (b[d].options.disabled || (e && !b[d].options.accept.call(b[d].element[0], (e.currentItem || e.element)))) {
                continue
            }
            for (var c = 0; c < h.length; c++) {
                if (h[c] == b[d].element[0]) {
                    b[d].proportions.height = 0;
                    continue droppablesLoop
                }
            }
            b[d].visible = b[d].element.css("display") != "none";
            if (!b[d].visible) {
                continue
            }
            b[d].offset = b[d].element.offset();
            b[d].proportions = {width:b[d].element[0].offsetWidth,height:b[d].element[0].offsetHeight};
            if (f == "mousedown") {
                b[d]._activate.call(b[d], g)
            }
        }
    },drop:function(b, c) {
        var d = false;
        a.each(a.ui.ddmanager.droppables[b.options.scope], function() {
            if (!this.options) {
                return
            }
            if (!this.options.disabled && this.visible && a.ui.intersect(b, this, this.options.tolerance)) {
                d = this._drop.call(this, c)
            }
            if (!this.options.disabled && this.visible && this.options.accept.call(this.element[0], (b.currentItem || b.element))) {
                this.isout = 1;
                this.isover = 0;
                this._deactivate.call(this, c)
            }
        });
        return d
    },drag:function(b, c) {
        if (b.options.refreshPositions) {
            a.ui.ddmanager.prepareOffsets(b, c)
        }
        a.each(a.ui.ddmanager.droppables[b.options.scope], function() {
            if (this.options.disabled || this.greedyChild || !this.visible) {
                return
            }
            var e = a.ui.intersect(b, this, this.options.tolerance);
            var g = !e && this.isover == 1 ? "isout" : (e && this.isover == 0 ? "isover" : null);
            if (!g) {
                return
            }
            var f;
            if (this.options.greedy) {
                var d = this.element.parents(":data(droppable):eq(0)");
                if (d.length) {
                    f = a.data(d[0], "droppable");
                    f.greedyChild = (g == "isover" ? 1 : 0)
                }
            }
            if (f && g == "isover") {
                f.isover = 0;
                f.isout = 1;
                f._out.call(f, c)
            }
            this[g] = 1;
            this[g == "isout" ? "isover" : "isout"] = 0;
            this[g == "isover" ? "_over" : "_out"].call(this, c);
            if (f && g == "isout") {
                f.isout = 0;
                f.isover = 1;
                f._over.call(f, c)
            }
        })
    }}
})(jQuery);
;
/*
 * jQuery UI Sortable 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Sortables
 *
 * Depends:
 *	ui.core.js
 */
(function(a) {
    a.widget("ui.sortable", a.extend({}, a.ui.mouse, {_init:function() {
        var b = this.options;
        this.containerCache = {};
        this.element.addClass("ui-sortable");
        this.refresh();
        this.floating = this.items.length ? (/left|right/).test(this.items[0].item.css("float")) : false;
        this.offset = this.element.offset();
        this._mouseInit()
    },destroy:function() {
        this.element.removeClass("ui-sortable ui-sortable-disabled").removeData("sortable").unbind(".sortable");
        this._mouseDestroy();
        for (var b = this.items.length - 1; b >= 0; b--) {
            this.items[b].item.removeData("sortable-item")
        }
    },_mouseCapture:function(e, f) {
        if (this.reverting) {
            return false
        }
        if (this.options.disabled || this.options.type == "static") {
            return false
        }
        this._refreshItems(e);
        var d = null,c = this,b = a(e.target).parents().each(function() {
            if (a.data(this, "sortable-item") == c) {
                d = a(this);
                return false
            }
        });
        if (a.data(e.target, "sortable-item") == c) {
            d = a(e.target)
        }
        if (!d) {
            return false
        }
        if (this.options.handle && !f) {
            var g = false;
            a(this.options.handle, d).find("*").andSelf().each(function() {
                if (this == e.target) {
                    g = true
                }
            });
            if (!g) {
                return false
            }
        }
        this.currentItem = d;
        this._removeCurrentsFromItems();
        return true
    },_mouseStart:function(e, f, b) {
        var g = this.options,c = this;
        this.currentContainer = this;
        this.refreshPositions();
        this.helper = this._createHelper(e);
        this._cacheHelperProportions();
        this._cacheMargins();
        this.scrollParent = this.helper.scrollParent();
        this.offset = this.currentItem.offset();
        this.offset = {top:this.offset.top - this.margins.top,left:this.offset.left - this.margins.left};
        this.helper.css("position", "absolute");
        this.cssPosition = this.helper.css("position");
        a.extend(this.offset, {click:{left:e.pageX - this.offset.left,top:e.pageY - this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()});
        this.originalPosition = this._generatePosition(e);
        this.originalPageX = e.pageX;
        this.originalPageY = e.pageY;
        if (g.cursorAt) {
            this._adjustOffsetFromHelper(g.cursorAt)
        }
        this.domPosition = {prev:this.currentItem.prev()[0],parent:this.currentItem.parent()[0]};
        if (this.helper[0] != this.currentItem[0]) {
            this.currentItem.hide()
        }
        this._createPlaceholder();
        if (g.containment) {
            this._setContainment()
        }
        if (g.cursor) {
            if (a("body").css("cursor")) {
                this._storedCursor = a("body").css("cursor")
            }
            a("body").css("cursor", g.cursor)
        }
        if (g.opacity) {
            if (this.helper.css("opacity")) {
                this._storedOpacity = this.helper.css("opacity")
            }
            this.helper.css("opacity", g.opacity)
        }
        if (g.zIndex) {
            if (this.helper.css("zIndex")) {
                this._storedZIndex = this.helper.css("zIndex")
            }
            this.helper.css("zIndex", g.zIndex)
        }
        if (this.scrollParent[0] != document && this.scrollParent[0].tagName != "HTML") {
            this.overflowOffset = this.scrollParent.offset()
        }
        this._trigger("start", e, this._uiHash());
        if (!this._preserveHelperProportions) {
            this._cacheHelperProportions()
        }
        if (!b) {
            for (var d = this.containers.length - 1; d >= 0; d--) {
                this.containers[d]._trigger("activate", e, c._uiHash(this))
            }
        }
        if (a.ui.ddmanager) {
            a.ui.ddmanager.current = this
        }
        if (a.ui.ddmanager && !g.dropBehaviour) {
            a.ui.ddmanager.prepareOffsets(this, e)
        }
        this.dragging = true;
        this.helper.addClass("ui-sortable-helper");
        this._mouseDrag(e);
        return true
    },_mouseDrag:function(f) {
        this.position = this._generatePosition(f);
        this.positionAbs = this._convertPositionTo("absolute");
        if (!this.lastPositionAbs) {
            this.lastPositionAbs = this.positionAbs
        }
        if (this.options.scroll) {
            var g = this.options,b = false;
            if (this.scrollParent[0] != document && this.scrollParent[0].tagName != "HTML") {
                if ((this.overflowOffset.top + this.scrollParent[0].offsetHeight) - f.pageY < g.scrollSensitivity) {
                    this.scrollParent[0].scrollTop = b = this.scrollParent[0].scrollTop + g.scrollSpeed
                } else {
                    if (f.pageY - this.overflowOffset.top < g.scrollSensitivity) {
                        this.scrollParent[0].scrollTop = b = this.scrollParent[0].scrollTop - g.scrollSpeed
                    }
                }
                if ((this.overflowOffset.left + this.scrollParent[0].offsetWidth) - f.pageX < g.scrollSensitivity) {
                    this.scrollParent[0].scrollLeft = b = this.scrollParent[0].scrollLeft + g.scrollSpeed
                } else {
                    if (f.pageX - this.overflowOffset.left < g.scrollSensitivity) {
                        this.scrollParent[0].scrollLeft = b = this.scrollParent[0].scrollLeft - g.scrollSpeed
                    }
                }
            } else {
                if (f.pageY - a(document).scrollTop() < g.scrollSensitivity) {
                    b = a(document).scrollTop(a(document).scrollTop() - g.scrollSpeed)
                } else {
                    if (a(window).height() - (f.pageY - a(document).scrollTop()) < g.scrollSensitivity) {
                        b = a(document).scrollTop(a(document).scrollTop() + g.scrollSpeed)
                    }
                }
                if (f.pageX - a(document).scrollLeft() < g.scrollSensitivity) {
                    b = a(document).scrollLeft(a(document).scrollLeft() - g.scrollSpeed)
                } else {
                    if (a(window).width() - (f.pageX - a(document).scrollLeft()) < g.scrollSensitivity) {
                        b = a(document).scrollLeft(a(document).scrollLeft() + g.scrollSpeed)
                    }
                }
            }
            if (b !== false && a.ui.ddmanager && !g.dropBehaviour) {
                a.ui.ddmanager.prepareOffsets(this, f)
            }
        }
        this.positionAbs = this._convertPositionTo("absolute");
        if (!this.options.axis || this.options.axis != "y") {
            this.helper[0].style.left = this.position.left + "px"
        }
        if (!this.options.axis || this.options.axis != "x") {
            this.helper[0].style.top = this.position.top + "px"
        }
        for (var d = this.items.length - 1; d >= 0; d--) {
            var e = this.items[d],c = e.item[0],h = this._intersectsWithPointer(e);
            if (!h) {
                continue
            }
            if (c != this.currentItem[0] && this.placeholder[h == 1 ? "next" : "prev"]()[0] != c && !a.ui.contains(this.placeholder[0], c) && (this.options.type == "semi-dynamic" ? !a.ui.contains(this.element[0], c) : true)) {
                this.direction = h == 1 ? "down" : "up";
                if (this.options.tolerance == "pointer" || this._intersectsWithSides(e)) {
                    this._rearrange(f, e)
                } else {
                    break
                }
                this._trigger("change", f, this._uiHash());
                break
            }
        }
        this._contactContainers(f);
        if (a.ui.ddmanager) {
            a.ui.ddmanager.drag(this, f)
        }
        this._trigger("sort", f, this._uiHash());
        this.lastPositionAbs = this.positionAbs;
        return false
    },_mouseStop:function(c, d) {
        if (!c) {
            return
        }
        if (a.ui.ddmanager && !this.options.dropBehaviour) {
            a.ui.ddmanager.drop(this, c)
        }
        if (this.options.revert) {
            var b = this;
            var e = b.placeholder.offset();
            b.reverting = true;
            a(this.helper).animate({left:e.left - this.offset.parent.left - b.margins.left + (this.offsetParent[0] == document.body ? 0 : this.offsetParent[0].scrollLeft),top:e.top - this.offset.parent.top - b.margins.top + (this.offsetParent[0] == document.body ? 0 : this.offsetParent[0].scrollTop)}, parseInt(this.options.revert, 10) || 500, function() {
                b._clear(c)
            })
        } else {
            this._clear(c, d)
        }
        return false
    },cancel:function() {
        var b = this;
        if (this.dragging) {
            this._mouseUp();
            if (this.options.helper == "original") {
                this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper")
            } else {
                this.currentItem.show()
            }
            for (var c = this.containers.length - 1; c >= 0; c--) {
                this.containers[c]._trigger("deactivate", null, b._uiHash(this));
                if (this.containers[c].containerCache.over) {
                    this.containers[c]._trigger("out", null, b._uiHash(this));
                    this.containers[c].containerCache.over = 0
                }
            }
        }
        if (this.placeholder[0].parentNode) {
            this.placeholder[0].parentNode.removeChild(this.placeholder[0])
        }
        if (this.options.helper != "original" && this.helper && this.helper[0].parentNode) {
            this.helper.remove()
        }
        a.extend(this, {helper:null,dragging:false,reverting:false,_noFinalSort:null});
        if (this.domPosition.prev) {
            a(this.domPosition.prev).after(this.currentItem)
        } else {
            a(this.domPosition.parent).prepend(this.currentItem)
        }
        return true
    },serialize:function(d) {
        var b = this._getItemsAsjQuery(d && d.connected);
        var c = [];
        d = d || {};
        a(b).each(function() {
            var e = (a(d.item || this).attr(d.attribute || "id") || "").match(d.expression || (/(.+)[-=_](.+)/));
            if (e) {
                c.push((d.key || e[1] + "[]") + "=" + (d.key && d.expression ? e[1] : e[2]))
            }
        });
        return c.join("&")
    },toArray:function(d) {
        var b = this._getItemsAsjQuery(d && d.connected);
        var c = [];
        d = d || {};
        b.each(function() {
            c.push(a(d.item || this).attr(d.attribute || "id") || "")
        });
        return c
    },_intersectsWith:function(m) {
        var e = this.positionAbs.left,d = e + this.helperProportions.width,k = this.positionAbs.top,j = k + this.helperProportions.height;
        var f = m.left,c = f + m.width,n = m.top,i = n + m.height;
        var o = this.offset.click.top,h = this.offset.click.left;
        var g = (k + o) > n && (k + o) < i && (e + h) > f && (e + h) < c;
        if (this.options.tolerance == "pointer" || this.options.forcePointerForContainers || (this.options.tolerance != "pointer" && this.helperProportions[this.floating ? "width" : "height"] > m[this.floating ? "width" : "height"])) {
            return g
        } else {
            return(f < e + (this.helperProportions.width / 2) && d - (this.helperProportions.width / 2) < c && n < k + (this.helperProportions.height / 2) && j - (this.helperProportions.height / 2) < i)
        }
    },_intersectsWithPointer:function(d) {
        var e = a.ui.isOverAxis(this.positionAbs.top + this.offset.click.top, d.top, d.height),c = a.ui.isOverAxis(this.positionAbs.left + this.offset.click.left, d.left, d.width),g = e && c,b = this._getDragVerticalDirection(),f = this._getDragHorizontalDirection();
        if (!g) {
            return false
        }
        return this.floating ? (((f && f == "right") || b == "down") ? 2 : 1) : (b && (b == "down" ? 2 : 1))
    },_intersectsWithSides:function(e) {
        var c = a.ui.isOverAxis(this.positionAbs.top + this.offset.click.top, e.top + (e.height / 2), e.height),d = a.ui.isOverAxis(this.positionAbs.left + this.offset.click.left, e.left + (e.width / 2), e.width),b = this._getDragVerticalDirection(),f = this._getDragHorizontalDirection();
        if (this.floating && f) {
            return((f == "right" && d) || (f == "left" && !d))
        } else {
            return b && ((b == "down" && c) || (b == "up" && !c))
        }
    },_getDragVerticalDirection:function() {
        var b = this.positionAbs.top - this.lastPositionAbs.top;
        return b != 0 && (b > 0 ? "down" : "up")
    },_getDragHorizontalDirection:function() {
        var b = this.positionAbs.left - this.lastPositionAbs.left;
        return b != 0 && (b > 0 ? "right" : "left")
    },refresh:function(b) {
        this._refreshItems(b);
        this.refreshPositions()
    },_connectWith:function() {
        var b = this.options;
        return b.connectWith.constructor == String ? [b.connectWith] : b.connectWith
    },_getItemsAsjQuery:function(b) {
        var l = this;
        var g = [];
        var e = [];
        var h = this._connectWith();
        if (h && b) {
            for (var d = h.length - 1; d >= 0; d--) {
                var k = a(h[d]);
                for (var c = k.length - 1; c >= 0; c--) {
                    var f = a.data(k[c], "sortable");
                    if (f && f != this && !f.options.disabled) {
                        e.push([a.isFunction(f.options.items) ? f.options.items.call(f.element) : a(f.options.items, f.element).not(".ui-sortable-helper"),f])
                    }
                }
            }
        }
        e.push([a.isFunction(this.options.items) ? this.options.items.call(this.element, null, {options:this.options,item:this.currentItem}) : a(this.options.items, this.element).not(".ui-sortable-helper"),this]);
        for (var d = e.length - 1; d >= 0; d--) {
            e[d][0].each(function() {
                g.push(this)
            })
        }
        return a(g)
    },_removeCurrentsFromItems:function() {
        var d = this.currentItem.find(":data(sortable-item)");
        for (var c = 0; c < this.items.length; c++) {
            for (var b = 0; b < d.length; b++) {
                if (d[b] == this.items[c].item[0]) {
                    this.items.splice(c, 1)
                }
            }
        }
    },_refreshItems:function(b) {
        this.items = [];
        this.containers = [this];
        var h = this.items;
        var p = this;
        var f = [
            [a.isFunction(this.options.items) ? this.options.items.call(this.element[0], b, {item:this.currentItem}) : a(this.options.items, this.element),this]
        ];
        var l = this._connectWith();
        if (l) {
            for (var e = l.length - 1; e >= 0; e--) {
                var m = a(l[e]);
                for (var d = m.length - 1; d >= 0; d--) {
                    var g = a.data(m[d], "sortable");
                    if (g && g != this && !g.options.disabled) {
                        f.push([a.isFunction(g.options.items) ? g.options.items.call(g.element[0], b, {item:this.currentItem}) : a(g.options.items, g.element),g]);
                        this.containers.push(g)
                    }
                }
            }
        }
        for (var e = f.length - 1; e >= 0; e--) {
            var k = f[e][1];
            var c = f[e][0];
            for (var d = 0,n = c.length; d < n; d++) {
                var o = a(c[d]);
                o.data("sortable-item", k);
                h.push({item:o,instance:k,width:0,height:0,left:0,top:0})
            }
        }
    },refreshPositions:function(b) {
        if (this.offsetParent && this.helper) {
            this.offset.parent = this._getParentOffset()
        }
        for (var d = this.items.length - 1; d >= 0; d--) {
            var e = this.items[d];
            if (e.instance != this.currentContainer && this.currentContainer && e.item[0] != this.currentItem[0]) {
                continue
            }
            var c = this.options.toleranceElement ? a(this.options.toleranceElement, e.item) : e.item;
            if (!b) {
                e.width = c.outerWidth();
                e.height = c.outerHeight()
            }
            var f = c.offset();
            e.left = f.left;
            e.top = f.top
        }
        if (this.options.custom && this.options.custom.refreshContainers) {
            this.options.custom.refreshContainers.call(this)
        } else {
            for (var d = this.containers.length - 1; d >= 0; d--) {
                var f = this.containers[d].element.offset();
                this.containers[d].containerCache.left = f.left;
                this.containers[d].containerCache.top = f.top;
                this.containers[d].containerCache.width = this.containers[d].element.outerWidth();
                this.containers[d].containerCache.height = this.containers[d].element.outerHeight()
            }
        }
    },_createPlaceholder:function(d) {
        var b = d || this,e = b.options;
        if (!e.placeholder || e.placeholder.constructor == String) {
            var c = e.placeholder;
            e.placeholder = {element:function() {
                var f = a(document.createElement(b.currentItem[0].nodeName)).addClass(c || b.currentItem[0].className + " ui-sortable-placeholder").removeClass("ui-sortable-helper")[0];
                if (!c) {
                    f.style.visibility = "hidden"
                }
                return f
            },update:function(f, g) {
                if (c && !e.forcePlaceholderSize) {
                    return
                }
                if (!g.height()) {
                    g.height(b.currentItem.innerHeight() - parseInt(b.currentItem.css("paddingTop") || 0, 10) - parseInt(b.currentItem.css("paddingBottom") || 0, 10))
                }
                if (!g.width()) {
                    g.width(b.currentItem.innerWidth() - parseInt(b.currentItem.css("paddingLeft") || 0, 10) - parseInt(b.currentItem.css("paddingRight") || 0, 10))
                }
            }}
        }
        b.placeholder = a(e.placeholder.element.call(b.element, b.currentItem));
        b.currentItem.after(b.placeholder);
        e.placeholder.update(b, b.placeholder)
    },_contactContainers:function(d) {
        for (var c = this.containers.length - 1; c >= 0; c--) {
            if (this._intersectsWith(this.containers[c].containerCache)) {
                if (!this.containers[c].containerCache.over) {
                    if (this.currentContainer != this.containers[c]) {
                        var h = 10000;
                        var g = null;
                        var e = this.positionAbs[this.containers[c].floating ? "left" : "top"];
                        for (var b = this.items.length - 1; b >= 0; b--) {
                            if (!a.ui.contains(this.containers[c].element[0], this.items[b].item[0])) {
                                continue
                            }
                            var f = this.items[b][this.containers[c].floating ? "left" : "top"];
                            if (Math.abs(f - e) < h) {
                                h = Math.abs(f - e);
                                g = this.items[b]
                            }
                        }
                        if (!g && !this.options.dropOnEmpty) {
                            continue
                        }
                        this.currentContainer = this.containers[c];
                        g ? this._rearrange(d, g, null, true) : this._rearrange(d, null, this.containers[c].element, true);
                        this._trigger("change", d, this._uiHash());
                        this.containers[c]._trigger("change", d, this._uiHash(this));
                        this.options.placeholder.update(this.currentContainer, this.placeholder)
                    }
                    this.containers[c]._trigger("over", d, this._uiHash(this));
                    this.containers[c].containerCache.over = 1
                }
            } else {
                if (this.containers[c].containerCache.over) {
                    this.containers[c]._trigger("out", d, this._uiHash(this));
                    this.containers[c].containerCache.over = 0
                }
            }
        }
    },_createHelper:function(c) {
        var d = this.options;
        var b = a.isFunction(d.helper) ? a(d.helper.apply(this.element[0], [c,this.currentItem])) : (d.helper == "clone" ? this.currentItem.clone() : this.currentItem);
        if (!b.parents("body").length) {
            a(d.appendTo != "parent" ? d.appendTo : this.currentItem[0].parentNode)[0].appendChild(b[0])
        }
        if (b[0] == this.currentItem[0]) {
            this._storedCSS = {width:this.currentItem[0].style.width,height:this.currentItem[0].style.height,position:this.currentItem.css("position"),top:this.currentItem.css("top"),left:this.currentItem.css("left")}
        }
        if (b[0].style.width == "" || d.forceHelperSize) {
            b.width(this.currentItem.width())
        }
        if (b[0].style.height == "" || d.forceHelperSize) {
            b.height(this.currentItem.height())
        }
        return b
    },_adjustOffsetFromHelper:function(b) {
        if (b.left != undefined) {
            this.offset.click.left = b.left + this.margins.left
        }
        if (b.right != undefined) {
            this.offset.click.left = this.helperProportions.width - b.right + this.margins.left
        }
        if (b.top != undefined) {
            this.offset.click.top = b.top + this.margins.top
        }
        if (b.bottom != undefined) {
            this.offset.click.top = this.helperProportions.height - b.bottom + this.margins.top
        }
    },_getParentOffset:function() {
        this.offsetParent = this.helper.offsetParent();
        var b = this.offsetParent.offset();
        if (this.cssPosition == "absolute" && this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) {
            b.left += this.scrollParent.scrollLeft();
            b.top += this.scrollParent.scrollTop()
        }
        if ((this.offsetParent[0] == document.body) || (this.offsetParent[0].tagName && this.offsetParent[0].tagName.toLowerCase() == "html" && a.browser.msie)) {
            b = {top:0,left:0}
        }
        return{top:b.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),left:b.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)}
    },_getRelativeOffset:function() {
        if (this.cssPosition == "relative") {
            var b = this.currentItem.position();
            return{top:b.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),left:b.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()}
        } else {
            return{top:0,left:0}
        }
    },_cacheMargins:function() {
        this.margins = {left:(parseInt(this.currentItem.css("marginLeft"), 10) || 0),top:(parseInt(this.currentItem.css("marginTop"), 10) || 0)}
    },_cacheHelperProportions:function() {
        this.helperProportions = {width:this.helper.outerWidth(),height:this.helper.outerHeight()}
    },_setContainment:function() {
        var e = this.options;
        if (e.containment == "parent") {
            e.containment = this.helper[0].parentNode
        }
        if (e.containment == "document" || e.containment == "window") {
            this.containment = [0 - this.offset.relative.left - this.offset.parent.left,0 - this.offset.relative.top - this.offset.parent.top,a(e.containment == "document" ? document : window).width() - this.helperProportions.width - this.margins.left,(a(e.containment == "document" ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]
        }
        if (!(/^(document|window|parent)$/).test(e.containment)) {
            var c = a(e.containment)[0];
            var d = a(e.containment).offset();
            var b = (a(c).css("overflow") != "hidden");
            this.containment = [d.left + (parseInt(a(c).css("borderLeftWidth"), 10) || 0) + (parseInt(a(c).css("paddingLeft"), 10) || 0) - this.margins.left,d.top + (parseInt(a(c).css("borderTopWidth"), 10) || 0) + (parseInt(a(c).css("paddingTop"), 10) || 0) - this.margins.top,d.left + (b ? Math.max(c.scrollWidth, c.offsetWidth) : c.offsetWidth) - (parseInt(a(c).css("borderLeftWidth"), 10) || 0) - (parseInt(a(c).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left,d.top + (b ? Math.max(c.scrollHeight, c.offsetHeight) : c.offsetHeight) - (parseInt(a(c).css("borderTopWidth"), 10) || 0) - (parseInt(a(c).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top]
        }
    },_convertPositionTo:function(f, h) {
        if (!h) {
            h = this.position
        }
        var c = f == "absolute" ? 1 : -1;
        var e = this.options,b = this.cssPosition == "absolute" && !(this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) ? this.offsetParent : this.scrollParent,g = (/(html|body)/i).test(b[0].tagName);
        return{top:(h.top + this.offset.relative.top * c + this.offset.parent.top * c - (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollTop() : (g ? 0 : b.scrollTop())) * c)),left:(h.left + this.offset.relative.left * c + this.offset.parent.left * c - (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollLeft() : g ? 0 : b.scrollLeft()) * c))}
    },_generatePosition:function(e) {
        var h = this.options,b = this.cssPosition == "absolute" && !(this.scrollParent[0] != document && a.ui.contains(this.scrollParent[0], this.offsetParent[0])) ? this.offsetParent : this.scrollParent,i = (/(html|body)/i).test(b[0].tagName);
        if (this.cssPosition == "relative" && !(this.scrollParent[0] != document && this.scrollParent[0] != this.offsetParent[0])) {
            this.offset.relative = this._getRelativeOffset()
        }
        var d = e.pageX;
        var c = e.pageY;
        if (this.originalPosition) {
            if (this.containment) {
                if (e.pageX - this.offset.click.left < this.containment[0]) {
                    d = this.containment[0] + this.offset.click.left
                }
                if (e.pageY - this.offset.click.top < this.containment[1]) {
                    c = this.containment[1] + this.offset.click.top
                }
                if (e.pageX - this.offset.click.left > this.containment[2]) {
                    d = this.containment[2] + this.offset.click.left
                }
                if (e.pageY - this.offset.click.top > this.containment[3]) {
                    c = this.containment[3] + this.offset.click.top
                }
            }
            if (h.grid) {
                var g = this.originalPageY + Math.round((c - this.originalPageY) / h.grid[1]) * h.grid[1];
                c = this.containment ? (!(g - this.offset.click.top < this.containment[1] || g - this.offset.click.top > this.containment[3]) ? g : (!(g - this.offset.click.top < this.containment[1]) ? g - h.grid[1] : g + h.grid[1])) : g;
                var f = this.originalPageX + Math.round((d - this.originalPageX) / h.grid[0]) * h.grid[0];
                d = this.containment ? (!(f - this.offset.click.left < this.containment[0] || f - this.offset.click.left > this.containment[2]) ? f : (!(f - this.offset.click.left < this.containment[0]) ? f - h.grid[0] : f + h.grid[0])) : f
            }
        }
        return{top:(c - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollTop() : (i ? 0 : b.scrollTop())))),left:(d - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + (a.browser.safari && this.cssPosition == "fixed" ? 0 : (this.cssPosition == "fixed" ? -this.scrollParent.scrollLeft() : i ? 0 : b.scrollLeft())))}
    },_rearrange:function(g, f, c, e) {
        c ? c[0].appendChild(this.placeholder[0]) : f.item[0].parentNode.insertBefore(this.placeholder[0], (this.direction == "down" ? f.item[0] : f.item[0].nextSibling));
        this.counter = this.counter ? ++this.counter : 1;
        var d = this,b = this.counter;
        window.setTimeout(function() {
            if (b == d.counter) {
                d.refreshPositions(!e)
            }
        }, 0)
    },_clear:function(d, e) {
        this.reverting = false;
        var f = [],b = this;
        if (!this._noFinalSort && this.currentItem[0].parentNode) {
            this.placeholder.before(this.currentItem)
        }
        this._noFinalSort = null;
        if (this.helper[0] == this.currentItem[0]) {
            for (var c in this._storedCSS) {
                if (this._storedCSS[c] == "auto" || this._storedCSS[c] == "static") {
                    this._storedCSS[c] = ""
                }
            }
            this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper")
        } else {
            this.currentItem.show()
        }
        if (this.fromOutside && !e) {
            f.push(function(g) {
                this._trigger("receive", g, this._uiHash(this.fromOutside))
            })
        }
        if ((this.fromOutside || this.domPosition.prev != this.currentItem.prev().not(".ui-sortable-helper")[0] || this.domPosition.parent != this.currentItem.parent()[0]) && !e) {
            f.push(function(g) {
                this._trigger("update", g, this._uiHash())
            })
        }
        if (!a.ui.contains(this.element[0], this.currentItem[0])) {
            if (!e) {
                f.push(function(g) {
                    this._trigger("remove", g, this._uiHash())
                })
            }
            for (var c = this.containers.length - 1; c >= 0; c--) {
                if (a.ui.contains(this.containers[c].element[0], this.currentItem[0]) && !e) {
                    f.push((function(g) {
                        return function(h) {
                            g._trigger("receive", h, this._uiHash(this))
                        }
                    }).call(this, this.containers[c]));
                    f.push((function(g) {
                        return function(h) {
                            g._trigger("update", h, this._uiHash(this))
                        }
                    }).call(this, this.containers[c]))
                }
            }
        }
        for (var c = this.containers.length - 1; c >= 0; c--) {
            if (!e) {
                f.push((function(g) {
                    return function(h) {
                        g._trigger("deactivate", h, this._uiHash(this))
                    }
                }).call(this, this.containers[c]))
            }
            if (this.containers[c].containerCache.over) {
                f.push((function(g) {
                    return function(h) {
                        g._trigger("out", h, this._uiHash(this))
                    }
                }).call(this, this.containers[c]));
                this.containers[c].containerCache.over = 0
            }
        }
        if (this._storedCursor) {
            a("body").css("cursor", this._storedCursor)
        }
        if (this._storedOpacity) {
            this.helper.css("opacity", this._storedOpacity)
        }
        if (this._storedZIndex) {
            this.helper.css("zIndex", this._storedZIndex == "auto" ? "" : this._storedZIndex)
        }
        this.dragging = false;
        if (this.cancelHelperRemoval) {
            if (!e) {
                this._trigger("beforeStop", d, this._uiHash());
                for (var c = 0; c < f.length; c++) {
                    f[c].call(this, d)
                }
                this._trigger("stop", d, this._uiHash())
            }
            return false
        }
        if (!e) {
            this._trigger("beforeStop", d, this._uiHash())
        }
        this.placeholder[0].parentNode.removeChild(this.placeholder[0]);
        if (this.helper[0] != this.currentItem[0]) {
            this.helper.remove()
        }
        this.helper = null;
        if (!e) {
            for (var c = 0; c < f.length; c++) {
                f[c].call(this, d)
            }
            this._trigger("stop", d, this._uiHash())
        }
        this.fromOutside = false;
        return true
    },_trigger:function() {
        if (a.widget.prototype._trigger.apply(this, arguments) === false) {
            this.cancel()
        }
    },_uiHash:function(c) {
        var b = c || this;
        return{helper:b.helper,placeholder:b.placeholder || a([]),position:b.position,absolutePosition:b.positionAbs,offset:b.positionAbs,item:b.currentItem,sender:c ? c.element : null}
    }}));
    a.extend(a.ui.sortable, {getter:"serialize toArray",version:"1.7.2",eventPrefix:"sort",defaults:{appendTo:"parent",axis:false,cancel:":input,option",connectWith:false,containment:false,cursor:"auto",cursorAt:false,delay:0,distance:1,dropOnEmpty:true,forcePlaceholderSize:false,forceHelperSize:false,grid:false,handle:false,helper:"original",items:"> *",opacity:false,placeholder:false,revert:false,scroll:true,scrollSensitivity:20,scrollSpeed:20,scope:"default",tolerance:"intersect",zIndex:1000}})
})(jQuery);
;
/*
 * jQuery UI Effects 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/
 */
jQuery.effects || (function(d) {
    d.effects = {version:"1.7.2",save:function(g, h) {
        for (var f = 0; f < h.length; f++) {
            if (h[f] !== null) {
                g.data("ec.storage." + h[f], g[0].style[h[f]])
            }
        }
    },restore:function(g, h) {
        for (var f = 0; f < h.length; f++) {
            if (h[f] !== null) {
                g.css(h[f], g.data("ec.storage." + h[f]))
            }
        }
    },setMode:function(f, g) {
        if (g == "toggle") {
            g = f.is(":hidden") ? "show" : "hide"
        }
        return g
    },getBaseline:function(g, h) {
        var i,f;
        switch (g[0]) {case"top":i = 0;break;case"middle":i = 0.5;break;case"bottom":i = 1;break;default:i = g[0] / h.height
        }
        switch (g[1]) {case"left":f = 0;break;case"center":f = 0.5;break;case"right":f = 1;break;default:f = g[1] / h.width
        }
        return{x:f,y:i}
    },createWrapper:function(f) {
        if (f.parent().is(".ui-effects-wrapper")) {
            return f.parent()
        }
        var g = {width:f.outerWidth(true),height:f.outerHeight(true),"float":f.css("float")};
        f.wrap('<div class="ui-effects-wrapper" style="font-size:100%;background:transparent;border:none;margin:0;padding:0"></div>');
        var j = f.parent();
        if (f.css("position") == "static") {
            j.css({position:"relative"});
            f.css({position:"relative"})
        } else {
            var i = f.css("top");
            if (isNaN(parseInt(i, 10))) {
                i = "auto"
            }
            var h = f.css("left");
            if (isNaN(parseInt(h, 10))) {
                h = "auto"
            }
            j.css({position:f.css("position"),top:i,left:h,zIndex:f.css("z-index")}).show();
            f.css({position:"relative",top:0,left:0})
        }
        j.css(g);
        return j
    },removeWrapper:function(f) {
        if (f.parent().is(".ui-effects-wrapper")) {
            return f.parent().replaceWith(f)
        }
        return f
    },setTransition:function(g, i, f, h) {
        h = h || {};
        d.each(i, function(k, j) {
            unit = g.cssUnit(j);
            if (unit[0] > 0) {
                h[j] = unit[0] * f + unit[1]
            }
        });
        return h
    },animateClass:function(h, i, k, j) {
        var f = (typeof k == "function" ? k : (j ? j : null));
        var g = (typeof k == "string" ? k : null);
        return this.each(function() {
            var q = {};
            var o = d(this);
            var p = o.attr("style") || "";
            if (typeof p == "object") {
                p = p.cssText
            }
            if (h.toggle) {
                o.hasClass(h.toggle) ? h.remove = h.toggle : h.add = h.toggle
            }
            var l = d.extend({}, (document.defaultView ? document.defaultView.getComputedStyle(this, null) : this.currentStyle));
            if (h.add) {
                o.addClass(h.add)
            }
            if (h.remove) {
                o.removeClass(h.remove)
            }
            var m = d.extend({}, (document.defaultView ? document.defaultView.getComputedStyle(this, null) : this.currentStyle));
            if (h.add) {
                o.removeClass(h.add)
            }
            if (h.remove) {
                o.addClass(h.remove)
            }
            for (var r in m) {
                if (typeof m[r] != "function" && m[r] && r.indexOf("Moz") == -1 && r.indexOf("length") == -1 && m[r] != l[r] && (r.match(/color/i) || (!r.match(/color/i) && !isNaN(parseInt(m[r], 10)))) && (l.position != "static" || (l.position == "static" && !r.match(/left|top|bottom|right/)))) {
                    q[r] = m[r]
                }
            }
            o.animate(q, i, g, function() {
                if (typeof d(this).attr("style") == "object") {
                    d(this).attr("style")["cssText"] = "";
                    d(this).attr("style")["cssText"] = p
                } else {
                    d(this).attr("style", p)
                }
                if (h.add) {
                    d(this).addClass(h.add)
                }
                if (h.remove) {
                    d(this).removeClass(h.remove)
                }
                if (f) {
                    f.apply(this, arguments)
                }
            })
        })
    }};
    function c(g, f) {
        var i = g[1] && g[1].constructor == Object ? g[1] : {};
        if (f) {
            i.mode = f
        }
        var h = g[1] && g[1].constructor != Object ? g[1] : (i.duration ? i.duration : g[2]);
        h = d.fx.off ? 0 : typeof h === "number" ? h : d.fx.speeds[h] || d.fx.speeds._default;
        var j = i.callback || (d.isFunction(g[1]) && g[1]) || (d.isFunction(g[2]) && g[2]) || (d.isFunction(g[3]) && g[3]);
        return[g[0],i,h,j]
    }

    d.fn.extend({_show:d.fn.show,_hide:d.fn.hide,__toggle:d.fn.toggle,_addClass:d.fn.addClass,_removeClass:d.fn.removeClass,_toggleClass:d.fn.toggleClass,effect:function(g, f, h, i) {
        return d.effects[g] ? d.effects[g].call(this, {method:g,options:f || {},duration:h,callback:i}) : null
    },show:function() {
        if (!arguments[0] || (arguments[0].constructor == Number || (/(slow|normal|fast)/).test(arguments[0]))) {
            return this._show.apply(this, arguments)
        } else {
            return this.effect.apply(this, c(arguments, "show"))
        }
    },hide:function() {
        if (!arguments[0] || (arguments[0].constructor == Number || (/(slow|normal|fast)/).test(arguments[0]))) {
            return this._hide.apply(this, arguments)
        } else {
            return this.effect.apply(this, c(arguments, "hide"))
        }
    },toggle:function() {
        if (!arguments[0] || (arguments[0].constructor == Number || (/(slow|normal|fast)/).test(arguments[0])) || (d.isFunction(arguments[0]) || typeof arguments[0] == "boolean")) {
            return this.__toggle.apply(this, arguments)
        } else {
            return this.effect.apply(this, c(arguments, "toggle"))
        }
    },addClass:function(g, f, i, h) {
        return f ? d.effects.animateClass.apply(this, [
            {add:g},
            f,
            i,
            h
        ]) : this._addClass(g)
    },removeClass:function(g, f, i, h) {
        return f ? d.effects.animateClass.apply(this, [
            {remove:g},
            f,
            i,
            h
        ]) : this._removeClass(g)
    },toggleClass:function(g, f, i, h) {
        return((typeof f !== "boolean") && f) ? d.effects.animateClass.apply(this, [
            {toggle:g},
            f,
            i,
            h
        ]) : this._toggleClass(g, f)
    },morph:function(f, h, g, j, i) {
        return d.effects.animateClass.apply(this, [
            {add:h,remove:f},
            g,
            j,
            i
        ])
    },switchClass:function() {
        return this.morph.apply(this, arguments)
    },cssUnit:function(f) {
        var g = this.css(f),h = [];
        d.each(["em","px","%","pt"], function(j, k) {
            if (g.indexOf(k) > 0) {
                h = [parseFloat(g),k]
            }
        });
        return h
    }});
    d.each(["backgroundColor","borderBottomColor","borderLeftColor","borderRightColor","borderTopColor","color","outlineColor"], function(g, f) {
        d.fx.step[f] = function(h) {
            if (h.state == 0) {
                h.start = e(h.elem, f);
                h.end = b(h.end)
            }
            h.elem.style[f] = "rgb(" + [Math.max(Math.min(parseInt((h.pos * (h.end[0] - h.start[0])) + h.start[0], 10), 255), 0),Math.max(Math.min(parseInt((h.pos * (h.end[1] - h.start[1])) + h.start[1], 10), 255), 0),Math.max(Math.min(parseInt((h.pos * (h.end[2] - h.start[2])) + h.start[2], 10), 255), 0)].join(",") + ")"
        }
    });
    function b(g) {
        var f;
        if (g && g.constructor == Array && g.length == 3) {
            return g
        }
        if (f = /rgb\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*\)/.exec(g)) {
            return[parseInt(f[1], 10),parseInt(f[2], 10),parseInt(f[3], 10)]
        }
        if (f = /rgb\(\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*,\s*([0-9]+(?:\.[0-9]+)?)\%\s*\)/.exec(g)) {
            return[parseFloat(f[1]) * 2.55,parseFloat(f[2]) * 2.55,parseFloat(f[3]) * 2.55]
        }
        if (f = /#([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec(g)) {
            return[parseInt(f[1], 16),parseInt(f[2], 16),parseInt(f[3], 16)]
        }
        if (f = /#([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/.exec(g)) {
            return[parseInt(f[1] + f[1], 16),parseInt(f[2] + f[2], 16),parseInt(f[3] + f[3], 16)]
        }
        if (f = /rgba\(0, 0, 0, 0\)/.exec(g)) {
            return a.transparent
        }
        return a[d.trim(g).toLowerCase()]
    }

    function e(h, f) {
        var g;
        do{
            g = d.curCSS(h, f);
            if (g != "" && g != "transparent" || d.nodeName(h, "body")) {
                break
            }
            f = "backgroundColor"
        } while (h = h.parentNode);
        return b(g)
    }

    var a = {aqua:[0,255,255],azure:[240,255,255],beige:[245,245,220],black:[0,0,0],blue:[0,0,255],brown:[165,42,42],cyan:[0,255,255],darkblue:[0,0,139],darkcyan:[0,139,139],darkgrey:[169,169,169],darkgreen:[0,100,0],darkkhaki:[189,183,107],darkmagenta:[139,0,139],darkolivegreen:[85,107,47],darkorange:[255,140,0],darkorchid:[153,50,204],darkred:[139,0,0],darksalmon:[233,150,122],darkviolet:[148,0,211],fuchsia:[255,0,255],gold:[255,215,0],green:[0,128,0],indigo:[75,0,130],khaki:[240,230,140],lightblue:[173,216,230],lightcyan:[224,255,255],lightgreen:[144,238,144],lightgrey:[211,211,211],lightpink:[255,182,193],lightyellow:[255,255,224],lime:[0,255,0],magenta:[255,0,255],maroon:[128,0,0],navy:[0,0,128],olive:[128,128,0],orange:[255,165,0],pink:[255,192,203],purple:[128,0,128],violet:[128,0,128],red:[255,0,0],silver:[192,192,192],white:[255,255,255],yellow:[255,255,0],transparent:[255,255,255]};
    d.easing.jswing = d.easing.swing;
    d.extend(d.easing, {def:"easeOutQuad",swing:function(g, h, f, j, i) {
        return d.easing[d.easing.def](g, h, f, j, i)
    },easeInQuad:function(g, h, f, j, i) {
        return j * (h /= i) * h + f
    },easeOutQuad:function(g, h, f, j, i) {
        return -j * (h /= i) * (h - 2) + f
    },easeInOutQuad:function(g, h, f, j, i) {
        if ((h /= i / 2) < 1) {
            return j / 2 * h * h + f
        }
        return -j / 2 * ((--h) * (h - 2) - 1) + f
    },easeInCubic:function(g, h, f, j, i) {
        return j * (h /= i) * h * h + f
    },easeOutCubic:function(g, h, f, j, i) {
        return j * ((h = h / i - 1) * h * h + 1) + f
    },easeInOutCubic:function(g, h, f, j, i) {
        if ((h /= i / 2) < 1) {
            return j / 2 * h * h * h + f
        }
        return j / 2 * ((h -= 2) * h * h + 2) + f
    },easeInQuart:function(g, h, f, j, i) {
        return j * (h /= i) * h * h * h + f
    },easeOutQuart:function(g, h, f, j, i) {
        return -j * ((h = h / i - 1) * h * h * h - 1) + f
    },easeInOutQuart:function(g, h, f, j, i) {
        if ((h /= i / 2) < 1) {
            return j / 2 * h * h * h * h + f
        }
        return -j / 2 * ((h -= 2) * h * h * h - 2) + f
    },easeInQuint:function(g, h, f, j, i) {
        return j * (h /= i) * h * h * h * h + f
    },easeOutQuint:function(g, h, f, j, i) {
        return j * ((h = h / i - 1) * h * h * h * h + 1) + f
    },easeInOutQuint:function(g, h, f, j, i) {
        if ((h /= i / 2) < 1) {
            return j / 2 * h * h * h * h * h + f
        }
        return j / 2 * ((h -= 2) * h * h * h * h + 2) + f
    },easeInSine:function(g, h, f, j, i) {
        return -j * Math.cos(h / i * (Math.PI / 2)) + j + f
    },easeOutSine:function(g, h, f, j, i) {
        return j * Math.sin(h / i * (Math.PI / 2)) + f
    },easeInOutSine:function(g, h, f, j, i) {
        return -j / 2 * (Math.cos(Math.PI * h / i) - 1) + f
    },easeInExpo:function(g, h, f, j, i) {
        return(h == 0) ? f : j * Math.pow(2, 10 * (h / i - 1)) + f
    },easeOutExpo:function(g, h, f, j, i) {
        return(h == i) ? f + j : j * (-Math.pow(2, -10 * h / i) + 1) + f
    },easeInOutExpo:function(g, h, f, j, i) {
        if (h == 0) {
            return f
        }
        if (h == i) {
            return f + j
        }
        if ((h /= i / 2) < 1) {
            return j / 2 * Math.pow(2, 10 * (h - 1)) + f
        }
        return j / 2 * (-Math.pow(2, -10 * --h) + 2) + f
    },easeInCirc:function(g, h, f, j, i) {
        return -j * (Math.sqrt(1 - (h /= i) * h) - 1) + f
    },easeOutCirc:function(g, h, f, j, i) {
        return j * Math.sqrt(1 - (h = h / i - 1) * h) + f
    },easeInOutCirc:function(g, h, f, j, i) {
        if ((h /= i / 2) < 1) {
            return -j / 2 * (Math.sqrt(1 - h * h) - 1) + f
        }
        return j / 2 * (Math.sqrt(1 - (h -= 2) * h) + 1) + f
    },easeInElastic:function(g, i, f, m, l) {
        var j = 1.70158;
        var k = 0;
        var h = m;
        if (i == 0) {
            return f
        }
        if ((i /= l) == 1) {
            return f + m
        }
        if (!k) {
            k = l * 0.3
        }
        if (h < Math.abs(m)) {
            h = m;
            var j = k / 4
        } else {
            var j = k / (2 * Math.PI) * Math.asin(m / h)
        }
        return -(h * Math.pow(2, 10 * (i -= 1)) * Math.sin((i * l - j) * (2 * Math.PI) / k)) + f
    },easeOutElastic:function(g, i, f, m, l) {
        var j = 1.70158;
        var k = 0;
        var h = m;
        if (i == 0) {
            return f
        }
        if ((i /= l) == 1) {
            return f + m
        }
        if (!k) {
            k = l * 0.3
        }
        if (h < Math.abs(m)) {
            h = m;
            var j = k / 4
        } else {
            var j = k / (2 * Math.PI) * Math.asin(m / h)
        }
        return h * Math.pow(2, -10 * i) * Math.sin((i * l - j) * (2 * Math.PI) / k) + m + f
    },easeInOutElastic:function(g, i, f, m, l) {
        var j = 1.70158;
        var k = 0;
        var h = m;
        if (i == 0) {
            return f
        }
        if ((i /= l / 2) == 2) {
            return f + m
        }
        if (!k) {
            k = l * (0.3 * 1.5)
        }
        if (h < Math.abs(m)) {
            h = m;
            var j = k / 4
        } else {
            var j = k / (2 * Math.PI) * Math.asin(m / h)
        }
        if (i < 1) {
            return -0.5 * (h * Math.pow(2, 10 * (i -= 1)) * Math.sin((i * l - j) * (2 * Math.PI) / k)) + f
        }
        return h * Math.pow(2, -10 * (i -= 1)) * Math.sin((i * l - j) * (2 * Math.PI) / k) * 0.5 + m + f
    },easeInBack:function(g, h, f, k, j, i) {
        if (i == undefined) {
            i = 1.70158
        }
        return k * (h /= j) * h * ((i + 1) * h - i) + f
    },easeOutBack:function(g, h, f, k, j, i) {
        if (i == undefined) {
            i = 1.70158
        }
        return k * ((h = h / j - 1) * h * ((i + 1) * h + i) + 1) + f
    },easeInOutBack:function(g, h, f, k, j, i) {
        if (i == undefined) {
            i = 1.70158
        }
        if ((h /= j / 2) < 1) {
            return k / 2 * (h * h * (((i *= (1.525)) + 1) * h - i)) + f
        }
        return k / 2 * ((h -= 2) * h * (((i *= (1.525)) + 1) * h + i) + 2) + f
    },easeInBounce:function(g, h, f, j, i) {
        return j - d.easing.easeOutBounce(g, i - h, 0, j, i) + f
    },easeOutBounce:function(g, h, f, j, i) {
        if ((h /= i) < (1 / 2.75)) {
            return j * (7.5625 * h * h) + f
        } else {
            if (h < (2 / 2.75)) {
                return j * (7.5625 * (h -= (1.5 / 2.75)) * h + 0.75) + f
            } else {
                if (h < (2.5 / 2.75)) {
                    return j * (7.5625 * (h -= (2.25 / 2.75)) * h + 0.9375) + f
                } else {
                    return j * (7.5625 * (h -= (2.625 / 2.75)) * h + 0.984375) + f
                }
            }
        }
    },easeInOutBounce:function(g, h, f, j, i) {
        if (h < i / 2) {
            return d.easing.easeInBounce(g, h * 2, 0, j, i) * 0.5 + f
        }
        return d.easing.easeOutBounce(g, h * 2 - i, 0, j, i) * 0.5 + j * 0.5 + f
    }})
})(jQuery);
;
/*
 * jQuery UI Effects Blind 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Blind
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.blind = function(b) {
        return this.queue(function() {
            var d = a(this),c = ["position","top","left"];
            var h = a.effects.setMode(d, b.options.mode || "hide");
            var g = b.options.direction || "vertical";
            a.effects.save(d, c);
            d.show();
            var j = a.effects.createWrapper(d).css({overflow:"hidden"});
            var e = (g == "vertical") ? "height" : "width";
            var i = (g == "vertical") ? j.height() : j.width();
            if (h == "show") {
                j.css(e, 0)
            }
            var f = {};
            f[e] = h == "show" ? i : 0;
            j.animate(f, b.duration, b.options.easing, function() {
                if (h == "hide") {
                    d.hide()
                }
                a.effects.restore(d, c);
                a.effects.removeWrapper(d);
                if (b.callback) {
                    b.callback.apply(d[0], arguments)
                }
                d.dequeue()
            })
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Bounce 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Bounce
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.bounce = function(b) {
        return this.queue(function() {
            var e = a(this),l = ["position","top","left"];
            var k = a.effects.setMode(e, b.options.mode || "effect");
            var n = b.options.direction || "up";
            var c = b.options.distance || 20;
            var d = b.options.times || 5;
            var g = b.duration || 250;
            if (/show|hide/.test(k)) {
                l.push("opacity")
            }
            a.effects.save(e, l);
            e.show();
            a.effects.createWrapper(e);
            var f = (n == "up" || n == "down") ? "top" : "left";
            var p = (n == "up" || n == "left") ? "pos" : "neg";
            var c = b.options.distance || (f == "top" ? e.outerHeight({margin:true}) / 3 : e.outerWidth({margin:true}) / 3);
            if (k == "show") {
                e.css("opacity", 0).css(f, p == "pos" ? -c : c)
            }
            if (k == "hide") {
                c = c / (d * 2)
            }
            if (k != "hide") {
                d--
            }
            if (k == "show") {
                var h = {opacity:1};
                h[f] = (p == "pos" ? "+=" : "-=") + c;
                e.animate(h, g / 2, b.options.easing);
                c = c / 2;
                d--
            }
            for (var j = 0; j < d; j++) {
                var o = {},m = {};
                o[f] = (p == "pos" ? "-=" : "+=") + c;
                m[f] = (p == "pos" ? "+=" : "-=") + c;
                e.animate(o, g / 2, b.options.easing).animate(m, g / 2, b.options.easing);
                c = (k == "hide") ? c * 2 : c / 2
            }
            if (k == "hide") {
                var h = {opacity:0};
                h[f] = (p == "pos" ? "-=" : "+=") + c;
                e.animate(h, g / 2, b.options.easing, function() {
                    e.hide();
                    a.effects.restore(e, l);
                    a.effects.removeWrapper(e);
                    if (b.callback) {
                        b.callback.apply(this, arguments)
                    }
                })
            } else {
                var o = {},m = {};
                o[f] = (p == "pos" ? "-=" : "+=") + c;
                m[f] = (p == "pos" ? "+=" : "-=") + c;
                e.animate(o, g / 2, b.options.easing).animate(m, g / 2, b.options.easing, function() {
                    a.effects.restore(e, l);
                    a.effects.removeWrapper(e);
                    if (b.callback) {
                        b.callback.apply(this, arguments)
                    }
                })
            }
            e.queue("fx", function() {
                e.dequeue()
            });
            e.dequeue()
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Clip 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Clip
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.clip = function(b) {
        return this.queue(function() {
            var f = a(this),j = ["position","top","left","height","width"];
            var i = a.effects.setMode(f, b.options.mode || "hide");
            var k = b.options.direction || "vertical";
            a.effects.save(f, j);
            f.show();
            var c = a.effects.createWrapper(f).css({overflow:"hidden"});
            var e = f[0].tagName == "IMG" ? c : f;
            var g = {size:(k == "vertical") ? "height" : "width",position:(k == "vertical") ? "top" : "left"};
            var d = (k == "vertical") ? e.height() : e.width();
            if (i == "show") {
                e.css(g.size, 0);
                e.css(g.position, d / 2)
            }
            var h = {};
            h[g.size] = i == "show" ? d : 0;
            h[g.position] = i == "show" ? 0 : d / 2;
            e.animate(h, {queue:false,duration:b.duration,easing:b.options.easing,complete:function() {
                if (i == "hide") {
                    f.hide()
                }
                a.effects.restore(f, j);
                a.effects.removeWrapper(f);
                if (b.callback) {
                    b.callback.apply(f[0], arguments)
                }
                f.dequeue()
            }})
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Drop 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Drop
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.drop = function(b) {
        return this.queue(function() {
            var e = a(this),d = ["position","top","left","opacity"];
            var i = a.effects.setMode(e, b.options.mode || "hide");
            var h = b.options.direction || "left";
            a.effects.save(e, d);
            e.show();
            a.effects.createWrapper(e);
            var f = (h == "up" || h == "down") ? "top" : "left";
            var c = (h == "up" || h == "left") ? "pos" : "neg";
            var j = b.options.distance || (f == "top" ? e.outerHeight({margin:true}) / 2 : e.outerWidth({margin:true}) / 2);
            if (i == "show") {
                e.css("opacity", 0).css(f, c == "pos" ? -j : j)
            }
            var g = {opacity:i == "show" ? 1 : 0};
            g[f] = (i == "show" ? (c == "pos" ? "+=" : "-=") : (c == "pos" ? "-=" : "+=")) + j;
            e.animate(g, {queue:false,duration:b.duration,easing:b.options.easing,complete:function() {
                if (i == "hide") {
                    e.hide()
                }
                a.effects.restore(e, d);
                a.effects.removeWrapper(e);
                if (b.callback) {
                    b.callback.apply(this, arguments)
                }
                e.dequeue()
            }})
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Fold 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Fold
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.fold = function(b) {
        return this.queue(function() {
            var e = a(this),k = ["position","top","left"];
            var h = a.effects.setMode(e, b.options.mode || "hide");
            var o = b.options.size || 15;
            var n = !(!b.options.horizFirst);
            var g = b.duration ? b.duration / 2 : a.fx.speeds._default / 2;
            a.effects.save(e, k);
            e.show();
            var d = a.effects.createWrapper(e).css({overflow:"hidden"});
            var i = ((h == "show") != n);
            var f = i ? ["width","height"] : ["height","width"];
            var c = i ? [d.width(),d.height()] : [d.height(),d.width()];
            var j = /([0-9]+)%/.exec(o);
            if (j) {
                o = parseInt(j[1], 10) / 100 * c[h == "hide" ? 0 : 1]
            }
            if (h == "show") {
                d.css(n ? {height:0,width:o} : {height:o,width:0})
            }
            var m = {},l = {};
            m[f[0]] = h == "show" ? c[0] : o;
            l[f[1]] = h == "show" ? c[1] : 0;
            d.animate(m, g, b.options.easing).animate(l, g, b.options.easing, function() {
                if (h == "hide") {
                    e.hide()
                }
                a.effects.restore(e, k);
                a.effects.removeWrapper(e);
                if (b.callback) {
                    b.callback.apply(e[0], arguments)
                }
                e.dequeue()
            })
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Highlight 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Highlight
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.highlight = function(b) {
        return this.queue(function() {
            var e = a(this),d = ["backgroundImage","backgroundColor","opacity"];
            var h = a.effects.setMode(e, b.options.mode || "show");
            var c = b.options.color || "#ffff99";
            var g = e.css("backgroundColor");
            a.effects.save(e, d);
            e.show();
            e.css({backgroundImage:"none",backgroundColor:c});
            var f = {backgroundColor:g};
            if (h == "hide") {
                f.opacity = 0
            }
            e.animate(f, {queue:false,duration:b.duration,easing:b.options.easing,complete:function() {
                if (h == "hide") {
                    e.hide()
                }
                a.effects.restore(e, d);
                if (h == "show" && a.browser.msie) {
                    this.style.removeAttribute("filter")
                }
                if (b.callback) {
                    b.callback.apply(this, arguments)
                }
                e.dequeue()
            }})
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Pulsate 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Pulsate
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.pulsate = function(b) {
        return this.queue(function() {
            var d = a(this);
            var g = a.effects.setMode(d, b.options.mode || "show");
            var f = b.options.times || 5;
            var e = b.duration ? b.duration / 2 : a.fx.speeds._default / 2;
            if (g == "hide") {
                f--
            }
            if (d.is(":hidden")) {
                d.css("opacity", 0);
                d.show();
                d.animate({opacity:1}, e, b.options.easing);
                f = f - 2
            }
            for (var c = 0; c < f; c++) {
                d.animate({opacity:0}, e, b.options.easing).animate({opacity:1}, e, b.options.easing)
            }
            if (g == "hide") {
                d.animate({opacity:0}, e, b.options.easing, function() {
                    d.hide();
                    if (b.callback) {
                        b.callback.apply(this, arguments)
                    }
                })
            } else {
                d.animate({opacity:0}, e, b.options.easing).animate({opacity:1}, e, b.options.easing, function() {
                    if (b.callback) {
                        b.callback.apply(this, arguments)
                    }
                })
            }
            d.queue("fx", function() {
                d.dequeue()
            });
            d.dequeue()
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Scale 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Scale
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.puff = function(b) {
        return this.queue(function() {
            var f = a(this);
            var c = a.extend(true, {}, b.options);
            var h = a.effects.setMode(f, b.options.mode || "hide");
            var g = parseInt(b.options.percent, 10) || 150;
            c.fade = true;
            var e = {height:f.height(),width:f.width()};
            var d = g / 100;
            f.from = (h == "hide") ? e : {height:e.height * d,width:e.width * d};
            c.from = f.from;
            c.percent = (h == "hide") ? g : 100;
            c.mode = h;
            f.effect("scale", c, b.duration, b.callback);
            f.dequeue()
        })
    };
    a.effects.scale = function(b) {
        return this.queue(function() {
            var g = a(this);
            var d = a.extend(true, {}, b.options);
            var j = a.effects.setMode(g, b.options.mode || "effect");
            var h = parseInt(b.options.percent, 10) || (parseInt(b.options.percent, 10) == 0 ? 0 : (j == "hide" ? 0 : 100));
            var i = b.options.direction || "both";
            var c = b.options.origin;
            if (j != "effect") {
                d.origin = c || ["middle","center"];
                d.restore = true
            }
            var f = {height:g.height(),width:g.width()};
            g.from = b.options.from || (j == "show" ? {height:0,width:0} : f);
            var e = {y:i != "horizontal" ? (h / 100) : 1,x:i != "vertical" ? (h / 100) : 1};
            g.to = {height:f.height * e.y,width:f.width * e.x};
            if (b.options.fade) {
                if (j == "show") {
                    g.from.opacity = 0;
                    g.to.opacity = 1
                }
                if (j == "hide") {
                    g.from.opacity = 1;
                    g.to.opacity = 0
                }
            }
            d.from = g.from;
            d.to = g.to;
            d.mode = j;
            g.effect("size", d, b.duration, b.callback);
            g.dequeue()
        })
    };
    a.effects.size = function(b) {
        return this.queue(function() {
            var c = a(this),n = ["position","top","left","width","height","overflow","opacity"];
            var m = ["position","top","left","overflow","opacity"];
            var j = ["width","height","overflow"];
            var p = ["fontSize"];
            var k = ["borderTopWidth","borderBottomWidth","paddingTop","paddingBottom"];
            var f = ["borderLeftWidth","borderRightWidth","paddingLeft","paddingRight"];
            var g = a.effects.setMode(c, b.options.mode || "effect");
            var i = b.options.restore || false;
            var e = b.options.scale || "both";
            var o = b.options.origin;
            var d = {height:c.height(),width:c.width()};
            c.from = b.options.from || d;
            c.to = b.options.to || d;
            if (o) {
                var h = a.effects.getBaseline(o, d);
                c.from.top = (d.height - c.from.height) * h.y;
                c.from.left = (d.width - c.from.width) * h.x;
                c.to.top = (d.height - c.to.height) * h.y;
                c.to.left = (d.width - c.to.width) * h.x
            }
            var l = {from:{y:c.from.height / d.height,x:c.from.width / d.width},to:{y:c.to.height / d.height,x:c.to.width / d.width}};
            if (e == "box" || e == "both") {
                if (l.from.y != l.to.y) {
                    n = n.concat(k);
                    c.from = a.effects.setTransition(c, k, l.from.y, c.from);
                    c.to = a.effects.setTransition(c, k, l.to.y, c.to)
                }
                if (l.from.x != l.to.x) {
                    n = n.concat(f);
                    c.from = a.effects.setTransition(c, f, l.from.x, c.from);
                    c.to = a.effects.setTransition(c, f, l.to.x, c.to)
                }
            }
            if (e == "content" || e == "both") {
                if (l.from.y != l.to.y) {
                    n = n.concat(p);
                    c.from = a.effects.setTransition(c, p, l.from.y, c.from);
                    c.to = a.effects.setTransition(c, p, l.to.y, c.to)
                }
            }
            a.effects.save(c, i ? n : m);
            c.show();
            a.effects.createWrapper(c);
            c.css("overflow", "hidden").css(c.from);
            if (e == "content" || e == "both") {
                k = k.concat(["marginTop","marginBottom"]).concat(p);
                f = f.concat(["marginLeft","marginRight"]);
                j = n.concat(k).concat(f);
                c.find("*[width]").each(function() {
                    child = a(this);
                    if (i) {
                        a.effects.save(child, j)
                    }
                    var q = {height:child.height(),width:child.width()};
                    child.from = {height:q.height * l.from.y,width:q.width * l.from.x};
                    child.to = {height:q.height * l.to.y,width:q.width * l.to.x};
                    if (l.from.y != l.to.y) {
                        child.from = a.effects.setTransition(child, k, l.from.y, child.from);
                        child.to = a.effects.setTransition(child, k, l.to.y, child.to)
                    }
                    if (l.from.x != l.to.x) {
                        child.from = a.effects.setTransition(child, f, l.from.x, child.from);
                        child.to = a.effects.setTransition(child, f, l.to.x, child.to)
                    }
                    child.css(child.from);
                    child.animate(child.to, b.duration, b.options.easing, function() {
                        if (i) {
                            a.effects.restore(child, j)
                        }
                    })
                })
            }
            c.animate(c.to, {queue:false,duration:b.duration,easing:b.options.easing,complete:function() {
                if (g == "hide") {
                    c.hide()
                }
                a.effects.restore(c, i ? n : m);
                a.effects.removeWrapper(c);
                if (b.callback) {
                    b.callback.apply(this, arguments)
                }
                c.dequeue()
            }})
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Shake 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Shake
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.shake = function(b) {
        return this.queue(function() {
            var e = a(this),l = ["position","top","left"];
            var k = a.effects.setMode(e, b.options.mode || "effect");
            var n = b.options.direction || "left";
            var c = b.options.distance || 20;
            var d = b.options.times || 3;
            var g = b.duration || b.options.duration || 140;
            a.effects.save(e, l);
            e.show();
            a.effects.createWrapper(e);
            var f = (n == "up" || n == "down") ? "top" : "left";
            var p = (n == "up" || n == "left") ? "pos" : "neg";
            var h = {},o = {},m = {};
            h[f] = (p == "pos" ? "-=" : "+=") + c;
            o[f] = (p == "pos" ? "+=" : "-=") + c * 2;
            m[f] = (p == "pos" ? "-=" : "+=") + c * 2;
            e.animate(h, g, b.options.easing);
            for (var j = 1; j < d; j++) {
                e.animate(o, g, b.options.easing).animate(m, g, b.options.easing)
            }
            e.animate(o, g, b.options.easing).animate(h, g / 2, b.options.easing, function() {
                a.effects.restore(e, l);
                a.effects.removeWrapper(e);
                if (b.callback) {
                    b.callback.apply(this, arguments)
                }
            });
            e.queue("fx", function() {
                e.dequeue()
            });
            e.dequeue()
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Slide 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Slide
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.slide = function(b) {
        return this.queue(function() {
            var e = a(this),d = ["position","top","left"];
            var i = a.effects.setMode(e, b.options.mode || "show");
            var h = b.options.direction || "left";
            a.effects.save(e, d);
            e.show();
            a.effects.createWrapper(e).css({overflow:"hidden"});
            var f = (h == "up" || h == "down") ? "top" : "left";
            var c = (h == "up" || h == "left") ? "pos" : "neg";
            var j = b.options.distance || (f == "top" ? e.outerHeight({margin:true}) : e.outerWidth({margin:true}));
            if (i == "show") {
                e.css(f, c == "pos" ? -j : j)
            }
            var g = {};
            g[f] = (i == "show" ? (c == "pos" ? "+=" : "-=") : (c == "pos" ? "-=" : "+=")) + j;
            e.animate(g, {queue:false,duration:b.duration,easing:b.options.easing,complete:function() {
                if (i == "hide") {
                    e.hide()
                }
                a.effects.restore(e, d);
                a.effects.removeWrapper(e);
                if (b.callback) {
                    b.callback.apply(this, arguments)
                }
                e.dequeue()
            }})
        })
    }
})(jQuery);
;
/*
 * jQuery UI Effects Transfer 1.7.2
 *
 * Copyright (c) 2009 AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Transfer
 *
 * Depends:
 *	effects.core.js
 */
(function(a) {
    a.effects.transfer = function(b) {
        return this.queue(function() {
            var f = a(this),h = a(b.options.to),e = h.offset(),g = {top:e.top,left:e.left,height:h.innerHeight(),width:h.innerWidth()},d = f.offset(),c = a('<div class="ui-effects-transfer"></div>').appendTo(document.body).addClass(b.options.className).css({top:d.top,left:d.left,height:f.innerHeight(),width:f.innerWidth(),position:"absolute"}).animate(g, b.duration, b.options.easing, function() {
                c.remove();
                (b.callback && b.callback.apply(f[0], arguments));
                f.dequeue()
            })
        })
    }
})(jQuery);
;


/*
 *	jquery.suggest 1.1 - 2007-08-06
 *	
 *	Uses code and techniques from following libraries:
 *	1. http://www.dyve.net/jquery/?autocomplete
 *	2. http://dev.jquery.com/browser/trunk/plugins/interface/iautocompleter.js	
 *
 *	All the new stuff written by Peter Vulgaris (www.vulgarisoip.com)	
 *	Feel free to do whatever you want with this file
 *
 */

(function($) {
    var defaults = {
        delay: 100,
        resultsClass: 'jquery-suggestion-results',
        selectClass: 'jquery-suggestion-select',
        matchClass: 'jquery-suggestion-match',
        minchars: 2,
        onSelect: function($input, $result) {
            $input.val($result.data('autocomplete:value'));
        },
        maxCacheSize: 65536,
        source: '',
        method: 'get',
        dataType: 'json',
        params: '',
        queryParam: 'q'
    };

    $.suggest = function(input, options) {
        options = $.extend({}, defaults, options);

        var $input = $(input).attr("autocomplete", "off");
        var $results = $('<ul></ul>');

        var timeout = false;		// hold timeout ID for suggestion results to appear	
        var prevLength = 0;			// last recorded length of $input.val()
        var cache = [];				// cache MRU list
        var cacheSize = 0;			// size of cache in chars (bytes?)

        $results.addClass(options.resultsClass).appendTo('body').hide();

        resetPosition();
        $(window)
                .load(resetPosition)// just in case user is changing size of page while loading
                .resize(resetPosition);

        $input.blur(function() {
            setTimeout(function() {
                $results.hide()
            }, 200);
        });

        // help IE users if possible
        if ($results.bgiframe) $results.bgiframe();

        // I really hate browser detection, but I don't see any other way
        if ($.browser.mozilla)
            $input.keypress(processKey);    // onkeypress repeats arrow keys in Mozilla/Opera
        else
            $input.keydown(processKey);		// onkeydown repeats arrow keys in IE/Safari

        function resetPosition() {
            // requires jquery.dimension plugin
            var offset = $input.offset();
            $results.css({
                top: (offset.top + input.offsetHeight) + 'px',
                left: offset.left + 'px'
            });
        }

        function processKey(e) {
            // handling up/down/escape requires results to be visible
            // handling enter/tab requires that AND a result to be selected
            if ((/27$|38$|40$/.test(e.keyCode) && $results.is(':visible')) ||
                    (/^13$|^9$/.test(e.keyCode) && getCurrentResult())) {

                if (e.preventDefault)
                    e.preventDefault();
                if (e.stopPropagation)
                    e.stopPropagation();

                e.cancelBubble = true;
                e.returnValue = false;

                switch (e.keyCode) {
                    case 38: // up
                        prevResult();
                        break;
                    case 40: // down
                        nextResult();
                        break;
                    case 9:  // tab
                    case 13: // return
                        selectCurrentResult();
                        break;
                    case 27: //	escape
                        $results.hide();
                        break;
                }
            }
            else if ($input.val().length != prevLength) {
                if (timeout)
                    clearTimeout(timeout);
                timeout = setTimeout(suggest, options.delay);
                prevLength = $input.val().length;
            }
        }

        function suggest() {
            var q = $.trim($input.val());

            if (q.length >= options.minchars) {
                cached = checkCache(q);
                if (cached) {
                    displayItems(cached['items']);
                }
                else {
                    var params = options.queryParam + '=' + q + (options.params.length ? '&' + options.params : '');
                    $.ajax({
                        type: options.method,
                        url: options.source,
                        dataType: options.dataType,
                        data: params,
                        success: function(data) {
                            $results.hide();

                            displayItems(data);
                            addToCache(q, data);
                        },
                        error: function(xmlhttp, text) {
                            $results.hide();
                            alert(text);
                        }
                    });
                }
            }
            else {
                $results.hide();
            }
        }

        function checkCache(q) {
            for (var i = 0; i < cache.length; i++)
                if (cache[i]['q'] == q) {
                    cache.unshift(cache.splice(i, 1)[0]);
                    return cache[0];
                }
            return false;
        }

        function addToCache(q, items) {
            var size = 0;
            $.each(items, function() {
                ++size;
            });

            while (cache.length && (cacheSize + size > options.maxCacheSize)) {
                var cached = cache.pop();
                cacheSize -= cached['size'];
            }

            cache.push({
                q: q,
                size: size,
                items: items
            });
            cacheSize += size;
        }

        function displayItems(items) {
            if (!items)
                return;
            var empty = true;
            $results.empty();
            $.each(items, function(value, display) {
                var $item = $('<li></li>').html(display).data('autocomplete:value', value);
                $results.append($item);
                empty = false;
            });

            if (empty) {
                $results.hide();
                return;
            }

            resetPosition();
            $results
                    .width($input.width())
                    .show()
                    .children('li')
                    .mouseover(function() {
                $results.children('li').removeClass(options.selectClass);
                $(this).addClass(options.selectClass);
            })
                    .click(function(e) {
                e.preventDefault();
                e.stopPropagation();
                selectCurrentResult();
            });
        }

        function parseTxt(txt, q) {
            var items = [];
            var tokens = txt.split(options.delimiter);

            // parse returned data for non-empty items
            for (var i = 0; i < tokens.length; i++) {
                var token = $.trim(tokens[i]);
                if (token) {
                    token = token.replace(
                            new RegExp(q, 'ig'),
                            function(q) {
                                return '<span class="' + options.matchClass + '">' + q + '</span>'
                            }
                            );
                    items[items.length] = token;
                }
            }
            return items;
        }

        function getCurrentResult() {
            if (!$results.is(':visible'))
                return false;

            var $currentResult = $results.children('li.' + options.selectClass);
            if (!$currentResult.length)
                $currentResult = false;

            return $currentResult;
        }

        function selectCurrentResult() {
            $currentResult = getCurrentResult();

            if ($currentResult) {
                options.onSelect.call(this, $input, $currentResult);
                $results.hide();
            }
        }

        function nextResult() {
            $currentResult = getCurrentResult();

            if ($currentResult)
                $currentResult
                        .removeClass(options.selectClass)
                        .next()
                        .addClass(options.selectClass);
            else
                $results.children('li:first-child').addClass(options.selectClass);
        }

        function prevResult() {
            $currentResult = getCurrentResult();

            if ($currentResult)
                $currentResult
                        .removeClass(options.selectClass)
                        .prev()
                        .addClass(options.selectClass);
            else
                $results.children('li:last-child').addClass(options.selectClass);
        }
    }

    $.fn.suggest = function(source, options) {
        if (!source)
            return;
        options.source = source;
        this.each(function() {
            new $.suggest(this, options);
        });
        return this;
    };
})(jQuery);


/*
 * jQuery Plugin: Tokenizing Autocomplete Text Entry
 * Version 1.1
 *
 * Copyright (c) 2009 James Smith (http://loopj.com)
 * Licensed jointly under the GPL and MIT licenses,
 * choose which one suits your project best!
 *
 */

(function($) {

    $.fn.tokenInput = function (url, options) {
        var settings = $.extend({
            url: url,
            hintText: "Type in a search term",
            noResultsText: "No results",
            searchingText: "Searching...",
            searchDelay: 300,
            prePopulateFromInput: false,
            minChars: 1,
            tokenLimit: null,
            jsonContainer: null,
            method: "GET",
            contentType: "json",
            queryParam: "q",
            onResult: null
        }, options);

        settings.classes = $.extend({
            tokenList: "token-input-list",
            token: "token-input-token",
            tokenDelete: "token-input-delete-token",
            selectedToken: "token-input-selected-token",
            highlightedToken: "token-input-highlighted-token",
            dropdown: "token-input-dropdown",
            dropdownItem: "token-input-dropdown-item",
            dropdownItem2: "token-input-dropdown-item2",
            selectedDropdownItem: "token-input-selected-dropdown-item",
            inputToken: "token-input-input-token"
        }, options.classes);

        return this.each(function () {
            var list = new $.TokenList(this, settings);
        });
    };

    $.TokenList = function (input, settings) {
        //
        // Variables
        //

        // Input box position "enum"
        var POSITION = {
            BEFORE: 0,
            AFTER: 1,
            END: 2
        };

        // Keys "enum"
        var KEY = {
            BACKSPACE: 8,
            TAB: 9,
            RETURN: 13,
            ESC: 27,
            LEFT: 37,
            UP: 38,
            RIGHT: 39,
            DOWN: 40,
            COMMA: 188
        };

        // Save the tokens
        var saved_tokens = [];

        // Keep track of the number of tokens in the list
        var token_count = 0;

        // Basic cache to save on db hits
        var cache = new $.TokenList.Cache();

        // Keep track of the timeout
        var timeout;

        // Create a new text input an attach keyup events
        var input_box = $("<input type=\"text\">")
                .css({
                         outline: "none"
                     })
                .focus(function () {
            if (settings.tokenLimit == null || settings.tokenLimit != token_count) {
                show_dropdown_hint();
            }
        })
                .blur(function () {
            hide_dropdown();
        })
                .keydown(function (event) {
            var previous_token;
            var next_token;

            switch (event.keyCode) {
                case KEY.LEFT:
                case KEY.RIGHT:
                case KEY.UP:
                case KEY.DOWN:
                    if (!$(this).val()) {
                        previous_token = input_token.prev();
                        next_token = input_token.next();

                        if ((previous_token.length && previous_token.get(0) === selected_token) || (next_token.length && next_token.get(0) === selected_token)) {
                            // Check if there is a previous/next token and it is selected
                            if (event.keyCode == KEY.LEFT || event.keyCode == KEY.UP) {
                                deselect_token($(selected_token), POSITION.BEFORE);
                            } else {
                                deselect_token($(selected_token), POSITION.AFTER);
                            }
                        } else if ((event.keyCode == KEY.LEFT || event.keyCode == KEY.UP) && previous_token.length) {
                            // We are moving left, select the previous token if it exists
                            select_token($(previous_token.get(0)));
                        } else if ((event.keyCode == KEY.RIGHT || event.keyCode == KEY.DOWN) && next_token.length) {
                            // We are moving right, select the next token if it exists
                            select_token($(next_token.get(0)));
                        }
                    } else {
                        var dropdown_item = null;

                        if (event.keyCode == KEY.DOWN || event.keyCode == KEY.RIGHT) {
                            dropdown_item = $(selected_dropdown_item).next();
                        } else {
                            dropdown_item = $(selected_dropdown_item).prev();
                        }

                        if (dropdown_item.length) {
                            select_dropdown_item(dropdown_item);
                        }
                        return false;
                    }
                    break;

                case KEY.BACKSPACE:
                    previous_token = input_token.prev();

                    if (!$(this).val().length) {
                        if (selected_token) {
                            delete_token($(selected_token));
                        } else if (previous_token.length) {
                            select_token($(previous_token.get(0)));
                        }

                        return false;
                    } else if ($(this).val().length == 1) {
                        hide_dropdown();
                    } else {
                        // set a timeout just long enough to let this function finish.
                        setTimeout(function() {
                            do_search(false);
                        }, 5);
                    }
                    break;

                case KEY.TAB:
                case KEY.RETURN:
                case KEY.COMMA:
                    if (selected_dropdown_item) {
                        add_token($(selected_dropdown_item));
                        return false;
                    }
                    break;

                case KEY.ESC:
                    hide_dropdown();
                    return true;

                default:
                    if (is_printable_character(event.keyCode)) {
                        // set a timeout just long enough to let this function finish.
                        setTimeout(function() {
                            do_search(false);
                        }, 5);
                    }
                    break;
            }
        });

        // Keep a reference to the original input box
        var hidden_input = $(input)
                .hide()
                .focus(function () {
            input_box.focus();
        })
                .blur(function () {
            input_box.blur();
        });


        if (settings.prePopulateFromInput) {
            settings.prePopulate = [];
            if (hidden_input.attr('data-names') != undefined) {
                var names = $.parseJSON(hidden_input.attr('data-names'));
            }
            $.each(hidden_input.val().trim().split(','), function(i, val) {
                if (val != '' && names != undefined && names[val] != undefined) {
                    settings.prePopulate.push({ id : val, name : names[val] });
                }
            });
            hidden_input.val(hidden_input.val() + ',');

        }


        // Keep a reference to the selected token and dropdown item
        var selected_token = null;
        var selected_dropdown_item = null;

        // The list to store the token items in
        var token_list = $("<ul />")
                .addClass(settings.classes.tokenList)
                .insertAfter(hidden_input)
                .click(function (event) {
            var li = get_element_from_event(event, "li");
            if (li && li.get(0) != input_token.get(0)) {
                toggle_select_token(li);
                return false;
            } else {
                input_box.focus();

                if (selected_token) {
                    deselect_token($(selected_token), POSITION.END);
                }
            }
        })
                .mouseover(function (event) {
            var li = get_element_from_event(event, "li");
            if (li && selected_token !== this) {
                li.addClass(settings.classes.highlightedToken);
            }
        })
                .mouseout(function (event) {
            var li = get_element_from_event(event, "li");
            if (li && selected_token !== this) {
                li.removeClass(settings.classes.highlightedToken);
            }
        })
                .mousedown(function (event) {
            // Stop user selecting text on tokens
            var li = get_element_from_event(event, "li");
            if (li) {
                return false;
            }
        });


        // The list to store the dropdown items in
        var dropdown = $("<div>")
                .addClass(settings.classes.dropdown)
                .insertAfter(token_list)
                .hide();

        // The token holding the input box
        var input_token = $("<li />")
                .addClass(settings.classes.inputToken)
                .appendTo(token_list)
                .append(input_box);

        init_list();

        //
        // Functions
        //


        // Pre-populate list if items exist
        function init_list() {
            li_data = settings.prePopulate;

            if (li_data && li_data.length) {
                for (var i in li_data) {
                    var this_token = $("<li><p>" + li_data[i].name + "</p> </li>")
                            .addClass(settings.classes.token)
                            .insertBefore(input_token);

                    $("<span>x</span>")
                            .addClass(settings.classes.tokenDelete)
                            .appendTo(this_token)
                            .click(function () {
                        delete_token($(this).parent());
                        return false;
                    });

                    $.data(this_token.get(0), "tokeninput", {"id": li_data[i].id, "name": li_data[i].name});

                    // Clear input box and make sure it keeps focus
                    input_box
                            .val("")
                            .focus();

                    // Don't show the help dropdown, they've got the idea
                    hide_dropdown();

                    // Save this token id
                    var id_string = li_data[i].id + ","

                    // Leave input value alone if using prePopulateFromInput
                    if (!settings.prePopulateFromInput) {
                        hidden_input.val(hidden_input.val() + id_string);
                    }
                }
            }

        }


        function is_printable_character(keycode) {
            if ((keycode >= 48 && keycode <= 90) || // 0-1a-z
                    (keycode >= 96 && keycode <= 111) || // numpad 0-9 + - / * .
                    (keycode >= 186 && keycode <= 192) || // ; = , - . / ^
                    (keycode >= 219 && keycode <= 222)       // ( \ ) '
                    ) {
                return true;
            } else {
                return false;
            }
        }

        // Get an element of a particular type from an event (click/mouseover etc)
        function get_element_from_event(event, element_type) {
            var target = $(event.target);
            var element = null;

            if (target.is(element_type)) {
                element = target;
            } else if (target.parent(element_type).length) {
                element = target.parent(element_type + ":first");
            }

            return element;
        }

        // Inner function to a token to the list
        function insert_token(id, value) {
            var this_token = $("<li><p>" + value + "</p> </li>")
                    .addClass(settings.classes.token)
                    .insertBefore(input_token);

            // The 'delete token' button
            $("<span>x</span>")
                    .addClass(settings.classes.tokenDelete)
                    .appendTo(this_token)
                    .click(function () {
                delete_token($(this).parent());
                return false;
            });

            $.data(this_token.get(0), "tokeninput", {"id": id, "name": value});

            return this_token;
        }

        // Add a token to the token list based on user input
        function add_token(item) {
            var li_data = $.data(item.get(0), "tokeninput");
            var this_token = insert_token(li_data.id, li_data.name);

            // Clear input box and make sure it keeps focus
            input_box
                    .val("")
                    .focus();

            // Don't show the help dropdown, they've got the idea
            hide_dropdown();

            // Save this token id
            var id_string = li_data.id + ","
            hidden_input.val(hidden_input.val() + id_string);

            token_count++;

            if (settings.tokenLimit != null && settings.tokenLimit >= token_count) {
                input_box.hide();
                hide_dropdown();
            }
        }

        // Select a token in the token list
        function select_token(token) {
            token.addClass(settings.classes.selectedToken);
            selected_token = token.get(0);

            // Hide input box
            input_box.val("");

            // Hide dropdown if it is visible (eg if we clicked to select token)
            hide_dropdown();
        }

        // Deselect a token in the token list
        function deselect_token(token, position) {
            token.removeClass(settings.classes.selectedToken);
            selected_token = null;

            if (position == POSITION.BEFORE) {
                input_token.insertBefore(token);
            } else if (position == POSITION.AFTER) {
                input_token.insertAfter(token);
            } else {
                input_token.appendTo(token_list);
            }

            // Show the input box and give it focus again
            input_box.focus();
        }

        // Toggle selection of a token in the token list
        function toggle_select_token(token) {
            if (selected_token == token.get(0)) {
                deselect_token(token, POSITION.END);
            } else {
                if (selected_token) {
                    deselect_token($(selected_token), POSITION.END);
                }
                select_token(token);
            }
        }

        // Delete a token from the token list
        function delete_token(token) {
            // Remove the id from the saved list
            var token_data = $.data(token.get(0), "tokeninput");

            // Delete the token
            token.remove();
            selected_token = null;

            // Show the input box and give it focus again
            input_box.focus();

            // Delete this token's id from hidden input
            var str = hidden_input.val()
            var start = str.indexOf(token_data.id + ",");
            var end = str.indexOf(",", start) + 1;

            if (end >= str.length) {
                hidden_input.val(str.slice(0, start));
            } else {
                hidden_input.val(str.slice(0, start) + str.slice(end, str.length));
            }

            token_count--;

            if (settings.tokenLimit != null) {
                input_box
                        .show()
                        .val("")
                        .focus();
            }
        }

        // Hide and clear the results dropdown
        function hide_dropdown() {
            dropdown.hide().empty();
            selected_dropdown_item = null;
        }

        function show_dropdown_searching() {
            dropdown
                    .html("<p>" + settings.searchingText + "</p>")
                    .show();
        }

        function show_dropdown_hint() {
            dropdown
                    .html("<p>" + settings.hintText + "</p>")
                    .show();
        }

        // Highlight the query part of the search term
        function highlight_term(value, term) {
            return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<b>$1</b>");
        }

        // Populate the results dropdown with some results
        function populate_dropdown(query, results) {
            if (results.length) {
                dropdown.empty();
                var dropdown_ul = $("<ul>")
                        .appendTo(dropdown)
                        .mouseover(function (event) {
                    select_dropdown_item(get_element_from_event(event, "li"));
                })
                        .mousedown(function (event) {
                    add_token(get_element_from_event(event, "li"));
                    return false;
                })
                        .hide();

                for (var i in results) {
                    if (results.hasOwnProperty(i)) {
                        var this_li = $("<li>" + highlight_term(results[i].name, query) + "</li>")
                                .appendTo(dropdown_ul);

                        if (i % 2) {
                            this_li.addClass(settings.classes.dropdownItem);
                        } else {
                            this_li.addClass(settings.classes.dropdownItem2);
                        }

                        if (i == 0) {
                            select_dropdown_item(this_li);
                        }

                        $.data(this_li.get(0), "tokeninput", {"id": results[i].id, "name": results[i].name});
                    }
                }

                dropdown.show();
                dropdown_ul.slideDown("fast");

            } else {
                dropdown
                        .html("<p>" + settings.noResultsText + "</p>")
                        .show();
            }
        }

        // Highlight an item in the results dropdown
        function select_dropdown_item(item) {
            if (item) {
                if (selected_dropdown_item) {
                    deselect_dropdown_item($(selected_dropdown_item));
                }

                item.addClass(settings.classes.selectedDropdownItem);
                selected_dropdown_item = item.get(0);
            }
        }

        // Remove highlighting from an item in the results dropdown
        function deselect_dropdown_item(item) {
            item.removeClass(settings.classes.selectedDropdownItem);
            selected_dropdown_item = null;
        }

        // Do a search and show the "searching" dropdown if the input is longer
        // than settings.minChars
        function do_search(immediate) {
            var query = input_box.val().toLowerCase();

            if (query && query.length) {
                if (selected_token) {
                    deselect_token($(selected_token), POSITION.AFTER);
                }
                if (query.length >= settings.minChars) {
                    show_dropdown_searching();
                    if (immediate) {
                        run_search(query);
                    } else {
                        clearTimeout(timeout);
                        timeout = setTimeout(function() {
                            run_search(query);
                        }, settings.searchDelay);
                    }
                } else {
                    hide_dropdown();
                }
            }
        }

        // Do the actual search
        function run_search(query) {
            var cached_results = cache.get(query);
            if (cached_results) {
                populate_dropdown(query, cached_results);
            } else {
                var queryStringDelimiter = settings.url.indexOf("?") < 0 ? "?" : "&";
                var callback = function(results) {
                    if ($.isFunction(settings.onResult)) {
                        results = settings.onResult.call(this, results);
                    }
                    cache.add(query, settings.jsonContainer ? results[settings.jsonContainer] : results);
                    populate_dropdown(query, settings.jsonContainer ? results[settings.jsonContainer] : results);
                };

                if (settings.method == "POST") {
                    $.post(settings.url + queryStringDelimiter + settings.queryParam + "=" + query, {}, callback, settings.contentType);
                } else {
                    $.get(settings.url + queryStringDelimiter + settings.queryParam + "=" + query, {}, callback, settings.contentType);
                }
            }
        }
    };

// Really basic cache for the results
    $.TokenList.Cache = function (options) {
        var settings = $.extend({
            max_size: 50
        }, options);

        var data = {};
        var size = 0;

        var flush = function () {
            data = {};
            size = 0;
        };

        this.add = function (query, results) {
            if (size > settings.max_size) {
                flush();
            }

            if (!data[query]) {
                size++;
            }

            data[query] = results;
        };

        this.get = function (query) {
            return data[query];
        };
    };

})(jQuery);

/*
 jQuery delayed observer - 0.8
 http://code.google.com/p/jquery-utils/

 (c) Maxime Haineault <haineault@gmail.com>
 http://haineault.com

 MIT License (http://www.opensource.org/licenses/mit-license.php)

 */

(function($) {
    $.extend($.fn, {
        delayedObserver: function(callback, delay, options) {
            return this.each(function() {
                var el = $(this);
                var op = options || {};
                el.data('oldval', el.val())
                        .data('delay', delay || 0.5)
                        .data('condition', op.condition || function() {
                    return ($(this).data('oldval') == $(this).val());
                })
                        .data('callback', callback)
                        [(op.event || 'keyup')](function() {
                    if (el.data('condition').apply(el)) {
                        return;
                    }
                    else {
                        if (el.data('timer')) {
                            clearTimeout(el.data('timer'));
                        }
                        el.data('timer', setTimeout(function() {
                            el.data('callback').apply(el);
                        }, el.data('delay') * 1000));
                        el.data('oldval', el.val());
                    }
                });
            });
        }
    });
})(jQuery);