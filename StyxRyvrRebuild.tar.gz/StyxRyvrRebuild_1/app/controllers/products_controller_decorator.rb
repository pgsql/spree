ProductsController.class_eval do


end