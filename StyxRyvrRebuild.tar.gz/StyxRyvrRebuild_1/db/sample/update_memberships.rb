ProductGroup.all.each {|pg| pg.update_memberships}
